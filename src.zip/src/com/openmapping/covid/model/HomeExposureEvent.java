package com.openmapping.covid.model;

import com.openmapping.covid.display.DaySummary;
import com.openmapping.covid.display.ResultAnalyser;

public class HomeExposureEvent extends ExposureEvent {
	
	public HomeExposureEvent(int day, Person exposer, Person exposed)
	{
		super(day,exposer, exposed);
	}

	public HomeExposureEvent(String[] summary, Factory factory)
	{
		super(summary, factory);
	}

	
	@Override
	public String getFilterKey() {
		return (exposer.getId() + "_" + exposed.getId());
	}

	@Override
	public String getFilterValue(DaySummary daySummary, int filterType) throws Exception {
		
		String result = "";
		
		if (filterType == ResultAnalyser.VENUE_TYPE) result = "home";
		if (filterType == ResultAnalyser.REGION) result = exposer.getHousehold().getRegion();
		
		return result;
	}

	@Override
	public String[] getSummary() {

		String[] summary = new String[3];
		summary[0] = getDayString();
		summary[1] = getExposerId();
		summary[2] = getExposedId();
		
		return summary;
	}

}
