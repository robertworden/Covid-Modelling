package com.openmapping.covid.model;

import java.util.StringTokenizer;
import java.util.Vector;

public class StateTransition {
	
	public DiseaseState getFromState() {return fromState;}
	private DiseaseState fromState;
	
	public DiseaseState getToState() {return toState;}
	private DiseaseState toState;
	
	// string like '3^1 4^2 5^2 6^1' defining a series of 'days^weight'
	private String dayWeightString;
	
	private int weightSum = 0;
	
	// int[] has two parts: [day number, weight]
	private Vector<int[]> dayWeights = new Vector<int[]>();
	
	// Vector [min age, max age, % probability]; should cover all ages to 100
	private Vector<int[]> probabilities = new Vector<int[]>();
	
	public StateTransition (DiseaseState fromState, String[] transitionDayRow) throws Exception
	{
		this.fromState = fromState;
		
		toState = fromState.getFactory().getDiseaseState(transitionDayRow[1]);
		
		dayWeightString = transitionDayRow[2];
		
		setdayWeights();
		
	}
	
	private void setdayWeights() throws Exception
	{
		StringTokenizer st = new StringTokenizer(dayWeightString," ");
		
		while (st.hasMoreTokens()) try
		{
			String wt = st.nextToken();
			StringTokenizer su = new StringTokenizer(wt,"^");
			int[] dw  = new int[2];
			dw[0] = new Integer(su.nextToken()).intValue();
			dw[1] = new Integer(su.nextToken()).intValue();
			dayWeights.add(dw);
			weightSum = weightSum + dw[1];
		}
		catch (Exception ex){Factory.debug("Invalid day weight string: " +  dayWeightString);}
		
	}

	
	/**
	 * 
	 * @param transitionProbRow
	 * @throws Exception
	 */
	public void addProbability(String[] transitionProbRow) throws Exception
	{
		int[] prob = new int[3];
		
		// interpret strings like 'all' (meaning 0-100) or '50-59'
		int[] ages = Factory.getRange(transitionProbRow[2]);
		for (int i = 0; i < 2; i++) prob[i] = ages[i];
		prob[2] = (int)(100.0*(new Double(transitionProbRow[3]).doubleValue()));
		
		probabilities.add(prob);
		
	}
	
	/**
	 * 
	 * @param age
	 * @return
	 * @throws Exception
	 */
	public double getProbabilityAllDays(int age) throws Exception
	{
		double prob = -1.0;
		
		for (int[] p: probabilities)
			if ((age > p[0] - 1) && (age < p[1] + 1)) 
				prob = new Double(p[2]).doubleValue()/100.0;
		
		if (prob < 0.0) throw new Exception("No probability defined for state transition " 
				+ fromState.getCode() + " to " + toState.getCode() + " age " + age);
		
		return prob;
	}
	
	/**
	 * given that this transition happens ,return the conditional probability that it happens
	 * on the given day after onset of the from state.
	 * @return
	 */
	public double getConditionalPerDay(int day)
	{
		double totalWeight = 0.0;
		double thisDayWeight  = 0.0;
		for (int i = 0; i < dayWeights.size();i++)
		{
			int[] dw = dayWeights.get(i);
			totalWeight = totalWeight + dw[1];
			if (dw[0]== day) thisDayWeight = dw[1];
		}
		
		return (thisDayWeight/totalWeight);
	}
	
	public int getRandomDays() throws Exception
	{
		int days = -1;
		double rand = weightSum*Math.random();
		double cum = 0.0;
		boolean found = false;
		for (int[] dw: dayWeights)
		{
			cum = cum + new Double(dw[1]).doubleValue();
			if ((cum > rand - 0.001) && (!found))
			{
				found = true;
				days = dw[0];
			}
		}
		if (days == -1) Factory.debug("Unable to find random duration for transition " + fromState.getCode() + " to " + toState.getCode());
		return days;
	}
	
	/**
	 * 
	 * @return
	 */
	public int makeRandomDays()
	{
		return 1;
	}

}
