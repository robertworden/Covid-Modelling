package com.openmapping.covid.model;

import java.awt.Polygon;
import java.util.StringTokenizer;
import java.util.Vector;

public class Region {
		
	public double getXMin() {return xMin;}
	private double xMin = 10000;

	public double getXMax() {return xMax;}
	private double xMax = -10000;
	
	public double getYMin() {return yMin;}
	private double yMin = 10000;

	public double getYMax() {return yMax;}
	private double yMax = -10000;
	
	public double getDensity() {return density;}
	private double density;
	
	public String getName() {return name;}
	private String name;
	
	public double getArea() {return area;}
	private double area;
	
	public int getPopulation() {return population;}
	private int population;
	
	// polygon on a whole km grid, with all points normalised into the range 0..100.0 with a bit to spare
	public Vector<double[]> getNormalPolygon() {return normalPolygon;}
	private Vector<double[]> normalPolygon = new Vector<double[]>();
	
	// area on the 100*100 map scale, including parts outside the map square
	public double getOuterMapArea() {return outerMapArea;}
	private double outerMapArea;

	// area on the 100*100 map scale, including only parts inside the map square
	public double getInnerMapArea() {return innerMapArea;}
	private double innerMapArea;
	
	// used to randomly generate points in the region on the map, according to the population in the map
	public int getPopulationInMap() {return (int)(population*innerMapArea/outerMapArea);}
	
	//-------------------------------------------------------------------------------------------------
	//                             
	//-------------------------------------------------------------------------------------------------
	
	
	public Region(String[] regionData) throws Exception
	{
		name = regionData[0];
		try
		{
			area = new Double(regionData[1]).doubleValue();
			population = new Integer(regionData[2]).intValue();
			density = new Double(regionData[3]).doubleValue();
			
			String polyData = regionData[4];
			StringTokenizer st = new StringTokenizer(polyData," ");
			while (st.hasMoreTokens())
			{
				String pointData = st.nextToken();
				StringTokenizer su = new StringTokenizer(pointData,"&");
				double[] point = new double[2];
				int dim = 0;
				while (su.hasMoreTokens())
				{
					point[dim] = new Double(su.nextToken()).doubleValue();
					dim++;
				}
				
				if (point[0] > xMax) xMax = point[0];
				if (point[0] < xMin) xMin = point[0];
				if (point[1] > yMax) yMax = point[1];
				if (point[1] < yMin) yMin = point[1];
				
				
				normalPolygon.add(point);
			}
			
			setOuterMapArea();
			setInnerMapArea();
		}
		catch (Exception ex) {throw new Exception("Invalid data for region " + name + ". " + ex.getMessage());}
	}
	
	//----------------------------------------------------------------------------------------------------------
	//                         test whether a point is in the region
	//----------------------------------------------------------------------------------------------------------
	
	/**
	 * whether a grid reference like '3017_6380' is in this region
	 * @param gridRef
	 * @return
	 */
	public boolean inRegion(String gridRef) throws Exception
	{
		double[] point = new double[2];
		boolean inRegion = false;
		try
		{
			StringTokenizer parts = new StringTokenizer(gridRef,"_");
			// 4 digits of each half of a grid reference define a number up to 10,000; region boundaries go up to 100
			point[0] = new Double(parts.nextToken())/100.0;
			point[1] = new Double(parts.nextToken())/100.0;
			inRegion = inRegion(point);
		}
		catch (Exception ex) {throw new Exception("Invalid grid reference '" + gridRef + "'");}
		
		return inRegion;
	}
	
	
	/**
	 * 
	 * @param point in the range 0..100
	 * @return
	 */
	public boolean inRegion(double[] point)
	{
		boolean inRegion = getPolygon().contains(point[0], point[1]);
		return inRegion;		
	}
	
	/**
	 * 
	 * @return polygon of int points on the 0..100 map scale (though some can be off the map)
	 */
	public Polygon getPolygon()
	{
		int sides = normalPolygon.size();
		int[] x = new int[sides];
		int[] y = new int[sides];
		
		for (int s = 0; s < sides;s++)
		{
			x[s] = (int)(normalPolygon.get(s)[0]);
			y[s] = (int)(normalPolygon.get(s)[1]);
		}
		
		return new Polygon(x,y,sides);
	}
	
	
	//----------------------------------------------------------------------------------------------------------
	//                         area in the 100 * 100 map - from normalPolygon
	//----------------------------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @return map area including parts outside the 100*100 region
	 */
	private void setOuterMapArea()
	{
		double area = 0.0;
		
		int  ixMin = (int)xMin;
		int  ixMax = (int)xMax;
		
		for (int ix = ixMin; ix < ixMax; ix++)
		{
			double x = (double)ix;
			Vector<Double> yCuts = yBorders(x);
			
			if (yCuts.size() > 1)
				area = area + maxValue(yCuts) - minValue(yCuts);
		}
		
		outerMapArea =  area;
	}
	
	/**
	 * 
	 * @return map area including parts outside the 100*100 region
	 */
	private void setInnerMapArea()
	{
		double area = 0.0;
		
		int  ixMin = (int)xMin;
		if (ixMin < 0) ixMin = 0;
		int  ixMax = (int)xMax;
		if (ixMax > 100) ixMax = 100;
		
		for (int ix = ixMin; ix < ixMax; ix++)
		{
			double x = (double)ix;
			Vector<Double> yCuts = yBorders(x);

			if (yCuts.size() > 1)
			{
				double maxV = maxValue(yCuts);
				if (maxV > 100.0) maxV = 100.0;
				double minV = minValue(yCuts);
				if (minV < 0.0) minV = 0.0;				
				area = area + maxV - minV;				
			}			
		}		
		innerMapArea = area;
	}
	
	/**
	 * 
	 * @param x
	 * @return all y values for lines in the border that cross the x line
	 */
	private Vector<Double> yBorders(double x)
	{
		Vector<Double> yb = new Vector<Double>();
		
		double[] previous = null;
		for (double[] point: normalPolygon)
		{
			if ((previous != null) && (inInterval(x, previous[0],point[0])))
				yb.add(new Double(point[1]));
			previous = point;
		}
		
		return yb;
	}
	
	/**
	 * 
	 * @param vals
	 * @return
	 */
	private double minValue(Vector<Double> vals)
	{
		double minV = 1000;
		for (Double dv: vals)
			if (dv.doubleValue() < minV) minV = dv.doubleValue();
		return minV;
	}
	
	/**
	 * 
	 * @param vals
	 * @return
	 */
	private double maxValue(Vector<Double> vals)
	{
		double maxV = -1000;
		for (Double dv: vals)
			if (dv.doubleValue() > maxV) maxV = dv.doubleValue();
		return maxV;
	}
	
	/**
	 * 
	 * @param x
	 * @param end
	 * @param other
	 * @return
	 */
	private boolean inInterval(double x, double end, double other)
	{
		boolean interval = false;
		if ((end > x ) && (other < x )) interval = true;
		if ((end < x ) && (other > x )) interval = true;		
		return interval;
	}
	

}
