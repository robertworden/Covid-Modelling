package com.openmapping.covid.model;

import java.util.Hashtable;
import java.util.StringTokenizer;

import com.openmapping.covid.WeightReader;

/**
 * defines a group of people and their frequency of meeting per day
 * @author robert
 *
 */

public class EncounterGroup extends GenericEntity implements ModelEntity{
	
	private String centreGridReference; // grid ref of the centre (in 100*100 km square)
	private String range; // range within which people come, in km
	private String visits; // average number of times per day that a person visits
	private String p_meet; // probability of two people meeting if they both visit on the same day
	private String type; // e.g small food shop
	private String maxSize; // maximum number of people in the group
	private String members; // person ids, separated by spaces
	private String code; // short code - linked to type
	
	public double getVisits() { return new Double(visits).doubleValue();}
	public double getP_Meet() { return new Double(p_meet).doubleValue();}
	public int getNMembers() {StringTokenizer st = new StringTokenizer(members," "); return st.countTokens();}
	public String getCode() {return code;}
	public String getType() {return type;}
	
	public String getMembers() {return members;}
	
	public String getGrid() {return centreGridReference;}
	
	public String getRegion() throws Exception {return factory.regionName(centreGridReference);}
	
	private int maxTries = 1000; // maximum number of tries to populate the group
	
	private double scaling= 100.0; // to convert from grid reference units (0..1) to km
	
	private String[] groupData; // from EncounterGroups.csv
	
	private Hashtable<String,Person> allMembers = new Hashtable<String,Person>();
	public Person getMember(String pid) {return allMembers.get(pid);}
	

	
	public EncounterGroup(WeightReader reader,Factory factory,String[] groupData)
	{
		super(reader,factory);
		this.groupData = groupData;
	}

	/**
	 * 
	 */
	public void makeRandom() throws Exception 
	{
		centreGridReference = factory.makeRandomGridRef();

		code =  groupData[0];
		type = groupData[1];
		// groupData[2] is the number of groups of this type
		maxSize = groupData[3];
		visits = groupData[4]; // string representation of a real
		p_meet = groupData[5];
		range = groupData[6];
				
		makeMembers();
		
	}
	
	/**
	 * 
	 * @throws Exception
	 */
	private void makeMembers() throws Exception
	{
		members = "";
		int found= 0;
		int wanted = new Integer(maxSize).intValue();
		Hashtable<String, String> foundPersons = new Hashtable<String, String>();
		
		for (int i = 0; i < maxTries; i++) if (found < wanted)
		{
			Person nextPerson = factory.getRandomPerson();
			if (foundPersons.get(nextPerson.getId()) == null)
			{
				foundPersons.put(nextPerson.getId(), "1");
				double dist = factory.distance(centreGridReference, nextPerson.getHousehold().getGridReference());
				if (scaling * dist < new Double(range).doubleValue())
				{
					members = members + nextPerson.getId() + " ";
					allMembers.put(nextPerson.getId(), nextPerson);
					found++;
				}
			}
		}
	}


	/**
	 * 
	 */
	public void fromData(String[] row) 
	{
		id = row[0];
		type = row[1];
		centreGridReference = row[2];
		range= row[3];
		visits = row[4];
		p_meet = row[5];
		maxSize = row[6];
		code = row[7];
		members = row[8];
		membersFromString();
	}
	
	/**
	 * populate the members table from the list of members read in from the groups file
	 */
	private void membersFromString()
	{
		allMembers = new Hashtable<String,Person>();
		StringTokenizer st = new StringTokenizer(members, " ");
		while (st.hasMoreTokens())
		{
			String pid = st.nextToken();
			allMembers.put(pid, factory.getPerson(pid));
		}
	}
	
	public String[] headerRow() {return header;}
	private String[] header = {"id","Type","Grid","Range","Visits/person/day","Meetings/visit","Max Size","Code","Members"};

	@Override
	public String[] dataRow() {
		String[] row = new String[9];
		row[0] = id;
		row[1] = type;
		row[2] = centreGridReference;
		row[3] = range;
		row[4] = visits;
		row[5] = p_meet;
		row[6] = maxSize;
		row[7] = code;
		row[8] = members;
		return row;
	}

}
