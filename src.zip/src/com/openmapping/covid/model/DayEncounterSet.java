package com.openmapping.covid.model;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import com.openmapping.covid.SimUtil;
import com.openmapping.covid.WeightReader;

public class DayEncounterSet extends GenericEntity implements ModelEntity{
	
	public static String makeKey(int day) {return("d_" + day);}
	
	private String day;
	private int encounterNumber = 0;
	private int peopleNumber;
	private String encounterList;
	
	public String getDay() {return day;}
	
	public int getEncounterNumber() {return encounterNumber;}
	
	// key = person id; element = Vector of [group id, other person.id, number of encounters], eg ''
	private Hashtable<String, Vector<String[]>> encountersByPerson = new Hashtable<String, Vector<String[]>>();
	
	// get all the encounters for this day for a person. For each encounter, get [group id, other person.id, number of encounters]
	public Vector<String[]> getPersonEncounters(String person_id) 
	{
		Vector<String[]> encs = new Vector<String[]>();
		if (encountersByPerson.get(person_id) != null) encs = encountersByPerson.get(person_id);
		return encs;
	}
	
	//-------------------------------------------------------------------------------------------------
	//                                       constructor
	//-------------------------------------------------------------------------------------------------
	
	public DayEncounterSet(WeightReader reader,Factory factory, String day)
	{
		super(reader,factory);
		this.day = day;
	}
	
	//------------------------------------------------------------------------------------------------
	//                    making random encounters for a day
	//------------------------------------------------------------------------------------------------

	public void makeRandom() throws Exception 
	{
		Vector<String> encountersInGroups = new Vector<String>();
		
		// go over all groups, making random encounters for each group
		for  (Enumeration<EncounterGroup> en = factory.groups.elements();en.hasMoreElements();)
		{
			EncounterGroup group = en.nextElement();
			// make random potential meetings in this group
			String groupMeets = makeGroupMeets(group);
			encountersInGroups.add(groupMeets);
		}
		
		// rearrange the encounters  in a string by person, rather than by group, for writing out
		encounterList = groupByPerson(encountersInGroups);
		
		// store encounters keyed by person (needed for access, not needed for file output)
		makePersonTable();
	}
	
	
	/**
	 * make a random set of all potential encounters in a day between members of an encounter group
	 * @param group
	 * @return
	 */
	private String makeGroupMeets(EncounterGroup group)
	{
		String members = group.getMembers();
		// list of ids of members of the group
		Vector<String> pids = new Vector<String>();
		StringTokenizer st = new StringTokenizer(members, " ");
		while (st.hasMoreTokens()) pids.add(st.nextToken());
		
		// find the list of people visiting here today
		Vector<String> pidsHere = new Vector<String>();
		for (String pid: pids)
			if (group.getVisits() > Math.random()) 
				pidsHere.add(pid);
		
		String meets = group.getId() + "(";
		// iterate over people visiting today
		for (int p1 = 0; p1 < pidsHere.size(); p1++)
		{
			String pid1 = pidsHere.get(p1);
			// iterate over other people visiting today
			for (int p2 = 0; p2 < p1; p2++)
			{
				String pid2 = pidsHere.get(p2);
				// generate a Poisson-distributed number of (potential) meetings between this pair, with mean group.getP_Meet()
				int encs = 0;
				boolean met = true;
				while (met)
				{
					if (group.getP_Meet() > Math.random()) encs++;
					else met  = false;
				}
				// record all pairs that have 1 or more meetings, in strings like 'p_1.p_5.2' separated by ';'
				if (encs > 0) meets = meets + pid1 + "." + pid2 + "." + encs + ";";
			}
		}
		
		meets = meets + ")";
		return meets;
	}
	
	/**
	 * 
	 * @param encountersInGroups
	 * @return
	 */
	private String groupByPerson(Vector<String> encountersInGroups) throws Exception
	{
		String allEncounters = "";
		Hashtable<String,String> personMeets = new Hashtable<String,String>();
		
		for (String groupMeets: encountersInGroups)
		{
			StringTokenizer st = new StringTokenizer(groupMeets,"(;)");
			String groupId = st.nextToken();
			while (st.hasMoreTokens())
			{
				String pairMeet = st.nextToken(); // e.g 'p_68.p_289.4'
				StringTokenizer su = new StringTokenizer(pairMeet,".");
				if (su.countTokens() != 3) throw new Exception("Invalid pair encounter: " + pairMeet);
				String [] pair = new String[2];
				pair[0] = su.nextToken();
				pair[1] = su.nextToken();
				String times = su.nextToken();
				encounterNumber++;
				
				// store every meeting twice - once for each person involved
				for (int sense = 0; sense < 2; sense++)
				{
					String meeterId = pair[sense];
					String meeteeId = pair[1-sense];
					String meetings = personMeets.get(meeterId);
					if (meetings == null) meetings = "";
					meetings = meetings + groupId + "." + meeteeId + "." + times + ";";
					personMeets.put(meeterId, meetings);					
				}
			}
		}
		
		peopleNumber = personMeets.size();
		for (Enumeration<String> en = personMeets.keys();en.hasMoreElements();)
		{
			String meeterId = en.nextElement();
			String meetings = personMeets.get(meeterId);
			allEncounters = allEncounters + meeterId + "(" + meetings + ") ";
		}
		
		return allEncounters;
	}

	//-------------------------------------------------------------------------------------------------
	//                       Checking the distribution of numbers of meetings by person
	//-------------------------------------------------------------------------------------------------
	
	public String meetingHistogramLine(boolean repeatMeetings)
	{
		String line = "";
		
		int[] hist = meetingHistogram(repeatMeetings);		
		for (int i = 0; i < hist.length; i++) line = line + hist[i] + ",";
		
		return line;
	}
	
	/**
	 * for each possible number of meetings up to 40,
	 * return the number of people who had that number of meetings
	 * @param repeatMeetings
	 * If repeatMeetings = true, count more for multiple meetings with the same person in the same encounter group
	 * @return
	 */
	public int[] meetingHistogram(boolean repeatMeetings)
	{
		int[] hist = new int[40];
		Hashtable<Integer,Integer> nMeets = numbersOfMeetings(repeatMeetings);

		for (int n = 0; n < hist.length; n++)
		{
			Integer nPeople = nMeets.get(new Integer(n));
			
			if (nPeople == null) hist[n] = 0;
			else hist[n]  = nPeople.intValue();
		}
		
		return hist;
	}
	
	/**
	 * first Integer = a number of meetings, 0 upwards
	 * second Integer = number of people who have that number of meetings
	 * If repeatMeetings = true, count more for multiple meetings with the same person in the same encounter group
	 * @return
	 */
	public Hashtable<Integer,Integer> numbersOfMeetings(boolean repeatMeetings)
	{
		Hashtable<Integer,Integer> nMeetings = new Hashtable<Integer,Integer>();
		
		for (Enumeration<String> en = factory.getPersons().keys();en.hasMoreElements();)
		{
			String pid = en.nextElement();
			Vector<String[]> meetings = getPersonEncounters(pid);
			Integer count = new Integer(countMeetings(meetings,repeatMeetings));

			Integer peopleCount = nMeetings.get(count);
			if (peopleCount == null) peopleCount = new Integer(1);
			else peopleCount = new Integer(peopleCount.intValue() + 1);
			nMeetings.put(count, peopleCount);
		}
				
		return nMeetings;
	}
	
	/**
	 * 
	 * @return ids of all people who have no meetings today
	 */
	public Hashtable<String,String> getHermits()
	{
		Hashtable<String,String> hermits = new Hashtable<String,String>();
		
		for (Enumeration<String> en = factory.getPersons().keys();en.hasMoreElements();)
		{
			String pid = en.nextElement();
			Vector<String[]> meetings = getPersonEncounters(pid);
			if (meetings.size() == 0) hermits.put(pid, "1");
		}
		
		return hermits;
	}
	
	/**
	 * 
	 * @param otherHermits
	 * @return ids of people with no meetings today who are also in another list of people with no meetings
	 */
	public Hashtable<String,String> getRepeatHermits(Hashtable<String,String> otherHermits)
	{
		Hashtable<String,String> repeaters = new Hashtable<String,String>();
		Hashtable<String,String> ownHermits = getHermits();
		
		for (Enumeration<String> en = ownHermits.keys();en.hasMoreElements();)
		{
			String pid = en.nextElement();
			if (otherHermits.get(pid) != null) repeaters.put(pid, "1");
		}
		
		return repeaters;
	}

	
	/**
	 * 
	 * If repeatMeetings = true, count more for multiple meetings with the same person 
	 * @param meetings
	 * @param repeatMeetings
	 * @return
	 */
	private int countMeetings(Vector<String[]> meetings, boolean repeatMeetings)
	{
		int count = 0;
		if (repeatMeetings)
		{
			for (String[] meeting:meetings)
				count = count + new Integer(meeting[2]).intValue();
		}
		else count  = meetings.size();
		return count;
	}
	

	//-------------------------------------------------------------------------------------------------
	//                                            Input/output
	//-------------------------------------------------------------------------------------------------
	
	public void fromData(String[] row) throws Exception {
		id = row[0];
		day = row[1];
		encounterNumber = SimUtil.makeInteger(row[2]);
		peopleNumber = SimUtil.makeInteger(row[3]);
		encounterList = row[4];		
		makePersonTable();
	}

	public String[] headerRow() {return header;}
	private String[] header = {"id","day","number of encounters","numer of people encountering", "encounters by person"};

	public String[] dataRow() {
		String[] row = new String[5];
		row[0] = id;
		row[1] = day;
		row[2] = new Integer(encounterNumber).toString();
		row[3] = new Integer(peopleNumber).toString();
		row[4] = encounterList;
		return row;
	}
	
	/**
	 * Make a Hashtable of encounters, keyed by person id, from the encounter list for the day
	 */
	private void makePersonTable()
	{
		encountersByPerson = new Hashtable<String, Vector<String[]>>();
		
		StringTokenizer st = new StringTokenizer(encounterList," ");
		while (st.hasMoreTokens())
		{
			String pEnc = st.nextToken();
			Vector<String[]> pMeets = new Vector<String[]>();
			StringTokenizer su = new StringTokenizer(pEnc,"(;)");
			String pid = su.nextToken();
			while (su.hasMoreTokens())
			{
				String oneMeet = su.nextToken();
				StringTokenizer sv = new StringTokenizer(oneMeet,".");
				String[] meet = new String[3];
				int i = 0;
				while (sv.hasMoreTokens())
				{
					meet[i] = sv.nextToken();
					i++;
				}
				pMeets.add(meet);
			}			
			encountersByPerson.put(pid, pMeets);
		}
	}


}
