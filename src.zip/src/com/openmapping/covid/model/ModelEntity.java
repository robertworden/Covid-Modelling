package com.openmapping.covid.model;

public interface ModelEntity {
	
	public void setId(String id);
	
	public String getId();
	
	public void makeRandom() throws Exception;
	
	public void fromData(String[] row) throws Exception;

	public void roundTrip() throws Exception;
	
	public String[] headerRow();

	public String[] dataRow();

}
