package com.openmapping.covid.model;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class DiseaseState {
	
	public String getCode() {return code;}
	private String code;
	
	public String getName() {return name;}
	private String name;
	
	public boolean isInfectious() {return infectious;}
	private boolean infectious;
	
	public String getDescription() {return description;}
	private String description;
	
	/**
	 * integer coordinates drawX and drawY for the disease model tab view
	 * @return
	 */
	public int getDrawX() {return drawX;}
	private int drawX;
		
	public int getDrawY() {return drawY;}
	private int drawY;
	
	public Factory getFactory() {return factory;}
	private Factory factory;
	
	// key = code of to state
	public Hashtable<String,StateTransition> getTransitions() {return transitions;}
	private Hashtable<String,StateTransition> transitions = new Hashtable<String,StateTransition>();
	
	// days after exposure for calculation of state probabilities
	public int getMaxDays() {return maxDays;}
	public static int maxDays = 40;

	//decade for calculation
	public int getMaxDecades() {return maxDecades;}
	public static int maxDecades = 10;
	
	//  currentStateProbability[d1][d2][dec] is the probability that the state started on day d1, and is still the state on d2 
	private double[][][] currentStateProbability = new double[maxDays][maxDays][maxDecades];
	
	public double getCurrentStateProbability(int startDay, int thisDay, int decade)
		{return currentStateProbability[startDay][thisDay][decade];}

	//  arrivedStateProbability[d1][d2][dec] is the probability that the state started on day d1, and is never depleted 
	private double[][][] arrivedStateProbability = new double[maxDays][maxDays][maxDecades];
		
	public double getArrivedStateProbability(int startDay, int thisDay, int decade)
		{return arrivedStateProbability[startDay][thisDay][decade];}
	
	//----------------------------------------------------------------------------------------------
	//                                        constructor
	//----------------------------------------------------------------------------------------------
	
	public DiseaseState(String[] stateData, Factory factory)
	{
		this.factory = factory;
		code = stateData[0];
		name = stateData[1];
		infectious = ("1".equals(stateData[2]));
		drawX = new Integer(stateData[3]).intValue();
		drawY = new Integer(stateData[4]).intValue();
		description = stateData[5];
		
		for (int dStart = 0; dStart < maxDays; dStart++)
			for (int dNow = 0; dNow < maxDays; dNow++) 
				for (int decade= 0; decade < maxDecades; decade++)
				{
					currentStateProbability[dStart][dNow][decade] = 0.0;
					arrivedStateProbability[dStart][dNow][decade] = 0.0;
				}
	}
	
	/**
	 * 
	 * @param transitionProbs
	 * @throws Exception
	 */
	public void makeTransitions(Vector<String[]> transitionProbs, Vector<String[]> transitionDays) throws Exception
	{
		// transitionDays has one line per transition, defining the distribution of days duration
		for (int r = 1; r < transitionDays.size();r++)
		{
			String[] tDayLine = transitionDays.get(r);
			String fromStateCode = tDayLine[0];
			if (getCode().equalsIgnoreCase(fromStateCode)) // from this disease state
			{
				String toStateCode = tDayLine[1];
				StateTransition trans = new StateTransition(this,tDayLine);
				transitions.put(toStateCode, trans);
			}
		}
		
		// transitionProbs may have several lines per transition, defining its probability for different age ranges
		for (int r = 1; r < transitionProbs.size();r++)
		{
			String[] tProbLine = transitionProbs.get(r);
			String fromStateCode = tProbLine[0];
			if (getCode().equalsIgnoreCase(fromStateCode)) // from this disease state
			{
				String toStateCode = tProbLine[1];
				StateTransition toState = transitions.get(toStateCode);
				if (toState == null) throw new Exception("No transition defined for " + tProbLine[0] + " to " + toStateCode);
				toState.addProbability(tProbLine);
			}
		}

	}
	
	public StateChange randomChange(Person per, int startDay) throws Exception
	{
		double rand = Math.random();
		int age = per.getAge();
		
		// pick the next state
		double cum = 0.0;
		boolean found = false;
		StateTransition chosenTransition = null;
		for (Enumeration<StateTransition> en = transitions.elements();en.hasMoreElements();)
		{
			StateTransition trans = en.nextElement();
			cum = cum + trans.getProbabilityAllDays(age);
			if ((cum > rand) && (!found))
			{
				found = true;
				chosenTransition = trans;
			}
		}
		if (chosenTransition == null) Factory.debug("Unable to choose random next state from state " + getCode());
		
		// pick the duration
		int duration = chosenTransition.getRandomDays();
		
		StateChange change = new StateChange(per,getCode(),chosenTransition.getToState().getCode(),startDay,duration);
		return change;
	}
	
	//------------------------------------------------------------------------------------------------
	//                       calculated model of state probabilities by day after exposure
	//------------------------------------------------------------------------------------------------
	
	
	public void addCurrentStateProbability(int startDay, int thisDay, int decade, double prob) throws Exception
	{
			double epsilon = 0.00001;
			double oldVal = currentStateProbability[startDay][thisDay][decade];
			double newVal = oldVal + prob;
			if (newVal < 0.0 - epsilon) Factory.debug("Negative probability " + newVal + " in state " + getCode() + " days " + startDay + " " + thisDay);
			if (newVal > 1.0 + epsilon) Factory.debug("Excessive probability " + newVal + " in state " + getCode() + " days " + startDay + " " + thisDay);
			currentStateProbability[startDay][thisDay][decade] = newVal;
	}

	
	public void moveCurrentProbsForward(int thisDay, int decade) throws Exception
	{
		for (int startDay = 0; startDay < thisDay + 1; startDay++)
		{
			double value = currentStateProbability[startDay][thisDay][decade];
			addCurrentStateProbability(startDay, thisDay + 1, decade, value);
		}
	}

	
	public void moveArrivedProbsForward(int thisDay, int decade) throws Exception
	{
		for (int startDay = 0; startDay < thisDay + 1; startDay++)
		{
			double value = arrivedStateProbability[startDay][thisDay][decade];
			addArrivedStateProbability(startDay, thisDay + 1, decade, value);
		}
	}
	
	public void addArrivedStateProbability(int startDay, int thisDay, int decade, double prob)
	{arrivedStateProbability[startDay][thisDay][decade] = arrivedStateProbability[startDay][thisDay][decade] + prob;}

	
	/**
	 * total probability of a person being in this state on day d after exposure
	 * dpending on their decade
	 * @param day
	 * @return
	 */
	public double getStateProbability(int day, int decade)
	{
		double tProb = 0.0;
		for (int dStart = 0; dStart < day+1; dStart++)
			tProb = tProb + currentStateProbability[dStart][day][decade];
		
		return tProb;		
	}
	
	/**
	 * 
	 * @param day
	 * @return the probability of being in this state day days after exposure,
	 * averaged over all ages
	 * @throws Exception
	 */
	public double getStateProbability(int day) throws Exception
	{
		double tProb = 0.0;		
		for (int decade = 0; decade < maxDecades; decade++)
			tProb = tProb + getStateProbability(day, decade)*factory.getProbability(decade);
		
		return tProb;		
	}
	
	
	/**
	 * 
	 * @param daysAgo
	 * @param decade
	 * @param nextCode
	 * @return the conditional probability, given that this state started daysAgo days ago and is still the state,
	 *  that a transition to the next state will occur today. 
	 *  Depends on the age decade.
	 */
	public double conditionalTransProb(int daysAgo, int decade, String nextCode) throws Exception
	{
		int age = 10*decade;
		double cond = 0.0;
		
		// allowed transitions
		StateTransition trans = transitions.get(nextCode);		
		if (trans != null)
		{
			// total probability of going to this state on any day
			double pTrans = trans.getProbabilityAllDays(age);
			// conditional probability, given that it goes to this state, that it does so on this day
			double pCond = trans.getConditionalPerDay(daysAgo);
			cond = pTrans*pCond;
		}
		
		// probability to stay in this state
		else if (nextCode.equals(getCode()))
		{
			cond = 1.0;
			for (Enumeration<String> en = transitions.keys();en.hasMoreElements();)
			{
				String otherCode = en.nextElement();
				cond = cond - conditionalTransProb(daysAgo, decade, otherCode);
			}
		}
		
		return cond;
	}

}
