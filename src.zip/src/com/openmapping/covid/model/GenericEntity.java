package com.openmapping.covid.model;

import com.openmapping.covid.WeightReader;

public abstract class GenericEntity implements ModelEntity{
	
	protected String id;
	public void setId(String id) {this.id = id;}
	public String getId() {return id;}
	
	protected WeightReader reader;
	
	public Factory getFactory() {return factory;}
	protected Factory factory;
	
	public GenericEntity(WeightReader reader, Factory factory)
	{
		this.reader = reader;
		this.factory = factory;
	}
	
	public abstract void makeRandom() throws Exception;
	
	public abstract void fromData(String[] row) throws Exception;
	
	public abstract String[] headerRow();
	
	public abstract String[] dataRow();

	public void roundTrip() throws Exception
	{
		String[] start = dataRow();
		fromData(start);
		String[] end = dataRow();
		if (start.length != end.length) 
			throw new Exception("Round trip length mismatch in class " + getClass().getName() + start.length + "; " +end.length);
		
		for (int c = 0; c < start.length; c++)
		{
			if ((start[c] == null)||(!(start[c].equals(end[c])))) 
				throw new Exception("Round trip failure in class " + getClass().getName() + " column " + c + "; '"
						 + start[c] + "' becomes  '" + end[c] + "'");
		}
	}
	

}
