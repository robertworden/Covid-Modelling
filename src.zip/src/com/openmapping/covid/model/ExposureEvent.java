package com.openmapping.covid.model;

import com.openmapping.covid.display.Filterable;

public abstract class ExposureEvent implements Filterable {
	
	protected String getDayString() {return new Integer(day).toString();}
	public int getDay() {return day;}
	protected int day;
	
	protected String getExposerId() {return exposer.getId();};
	public Person getExposer() {return exposer;}
	protected Person exposer;
	
	protected String getExposedId() {return exposed.getId();};
	public Person getExposed() {return exposed;}
	protected Person exposed;
	
	public ExposureEvent(int day, Person exposer, Person exposed)
	{
		this.day = day;
		this.exposer = exposer;
		this.exposed = exposed;
	}
	
	public ExposureEvent(String[] summary, Factory factory)
	{
		day = new Integer(summary[0]).intValue();
		exposer = factory.getPerson(summary[1]);
		exposed = factory.getPerson(summary[2]);
	}
	
	public abstract String[] getSummary();
	
	public static ExposureEvent makeExposureEvent(String[] summary, Factory factory)
	{
		ExposureEvent e = null;		
		if (summary.length == 3) e = new HomeExposureEvent(summary,factory);
		if (summary.length == 4) e = new GroupExposureEvent(summary,factory);
		return e;
	}

}
