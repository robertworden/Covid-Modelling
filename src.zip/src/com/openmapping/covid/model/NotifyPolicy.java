package com.openmapping.covid.model;

import java.util.Vector;

import com.openmapping.covid.WeightReader;

public class NotifyPolicy extends Policy{
	
	// the state which initiates contact tracing
	public static String TRACE_STATE = "E"; // test positive
	
	protected String[] allowedPolicyNames()
	{
		String[] names = {"contact trace","strong trace","weak trace"};
		return names;
	}


	/**
	 * 
	 * @param factory
	 * @param reader
	 * @param policyData
	 * @throws Exception
	 */
	public NotifyPolicy(Factory factory, WeightReader reader,  String[] policyData) throws Exception
	{
		super(factory, reader, policyData);
	}
	
	/**
	 * 
	 * @param person
	 */
	public void doNotifyFrom(Person person, int day) throws Exception
	{
		doContactTrace(person,day);
	}
	
	/**
	 * 
	 * @param person
	 */
	private void doContactTrace(Person person, int day) throws Exception
	{
		String todayState = person.getDiseaseState(day);
		String yesterdayState  = "";
		if (day > 0) yesterdayState = person.getDiseaseState(day-1);

		// if the person has made the transition to the trace state
		if ((todayState.equals(TRACE_STATE))  && !(yesterdayState.equals(TRACE_STATE)))
		{
			int daysBack = 0;
			int daysIsolate = 0;
			double adherence = 0;
			try
			{
				// number of days back to look for contacts
				daysBack = new Integer(getParamValue("daysBack")).intValue();
				// number of days people are asked to isolate for
				daysIsolate = new Integer(getParamValue("daysIsolate")).intValue();
				//  percentage of adherence to the traceBack
				adherence = new Double(getParamValue("adherence")).doubleValue();
			}
			catch (Exception ex) {throw new Exception("Invalid notification policy parameters: " + parameterString);} 
			
			// isolate the person who tested positive (or..)
			if (adherence/100.0 > Math.random()) person.isolate(daysIsolate);

			// find the people they have met in the last few days, and isolate them
			for (int d = 0; d < daysBack; d++)
			{
				int earlier = day - d;				
				if (earlier > -1)
				{
					// get all encounters for some earlier day
					String dKey = DayEncounterSet.makeKey(earlier);
					DayEncounterSet thatDay = factory.getDayEncounterSet(dKey);
					
					// get a Vector of [group id, other person.id, number of encounters]
					Vector<String[]> meetings = thatDay.getPersonEncounters(person.getId());
					
					// FIXME we should filter this list by the lockdown policies in force
					
					// notify the people met to isolate for N days - with probability adherence /100
					for (String[] meeting: meetings)
					{
						Person otherPerson = factory.getPerson(meeting[1]);
						if (adherence/100.0  > Math.random()) otherPerson.isolate(daysIsolate);
					}
				}
			}
		}
	}

}
