package com.openmapping.covid.model;

import com.openmapping.covid.WeightReader;

/**
 * a policy determines whether or not a meeting can take place
 * 
 * Each instance of a policy has a policy index, which determines which of a number of methods is applied; 
 * and a number of parameters which may be used by the method to return a probability that the meeting may take place.
 * 
 * When several policy instances apply to the same meeting, their probabilities are multiplied, to test if the meeting will take place
 * 
 * @author robert
 *
 */

public class MeetingPolicy extends Policy {
	
	private Person[] people = new Person[2];
	
	private EncounterGroup group;
	
	protected String[] allowedPolicyNames()
	{
		String[] names = {"isolate","lockdown"};
		return names;
	}

	
	public MeetingPolicy(Factory factory, WeightReader reader,  String[] policyData) throws Exception
	{
		super(factory, reader, policyData);
	}
	
	

	/**
	 * 
	 * @param day
	 * @param meetingData
	 * @return
	 */
	public double getPolicyProbability(String[] meetingData)
	{
		if (policyIndex == 0) return isolateProbability(meetingData);
		if (policyIndex == 1) return lockdownProbability(meetingData);
	
		return 1.0;
	
	}

/**
 * 
 * @param meetingData
 * @return
 */
	private double isolateProbability(String[] meetingData)
	{
		double prob = 1.0;
		return prob;
	}


/**
 * probability of any meeting is reduced by (100 - adherence)/100
 * @param meetingData
 * @return
 */
	private double lockdownProbability(String[] meetingData)
	{
		// 100% effective unless adherence is defined
		double diminish = 0.0;
		
		if (parameter.get("adherence") != null)
		{
			int adherence = new Integer(parameter.get("adherence")).intValue();
			diminish = new Double(100 - adherence).doubleValue()/new Double(100).doubleValue();
		}
		
		return diminish;
	}

}
