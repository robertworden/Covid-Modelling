package com.openmapping.covid.model;

import com.openmapping.covid.display.DaySummary;
import com.openmapping.covid.display.ResultAnalyser;

public class GroupExposureEvent extends ExposureEvent {
	
	protected String getGroupId() {return group.getId();}
	public EncounterGroup getGroup() {return group;}
	private EncounterGroup group;
	
	public GroupExposureEvent(int day, Person exposer, Person exposed, EncounterGroup group)
	{
		super(day, exposer, exposed);
		this.group = group;
	}
	
	public GroupExposureEvent(String[] summary, Factory factory)
	{
		super(summary, factory);
		group = factory.getGroups().get(summary[3]);
	}

	@Override
	public String getFilterKey() {
		return (exposer.getId() + "_" + exposed.getId() + "_" + group.getId());
	}

	@Override
	public String getFilterValue(DaySummary daySummary, int filterType) throws Exception {
		String result = "";
		
		if (filterType == ResultAnalyser.VENUE_TYPE) result = group.getType();
		if (filterType == ResultAnalyser.REGION) result = group.getRegion();
		
		return result;
	}

	@Override
	public String[] getSummary() {

		String[] summary = new String[4];
		summary[0] = getDayString();
		summary[1] = getExposerId();
		summary[2] = getExposedId();
		summary[3] = getGroupId();
		
		return summary;
	}


}
