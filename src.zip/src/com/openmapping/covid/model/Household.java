package com.openmapping.covid.model;

import java.util.Vector;

import com.openmapping.covid.SimUtil;
import com.openmapping.covid.WeightReader;

public class Household extends GenericEntity implements ModelEntity 
{
	
	public int getOccupancy() {return occupancy;}
	private int occupancy;
	
	public String getGridReference() {return gridReference;}
	private String gridReference;
	
	public String getRegion() {return region;}
	private String region;
	
	public Vector<Person> getPeople() {return people;}
	private Vector<Person> people = new Vector<Person>();
	public void addPerson(Person p) {people.add(p);}
	
	public Household(WeightReader reader, Factory factory)
	{
		super(reader,factory);
	}
	
	public void makeRandom() throws Exception
	{
		String occString = reader.makeRandomData("Occupancy")[1];
		occupancy = new Integer(occString).intValue();
		gridReference = factory.makeRandomGridRef();
		region = factory.regionName(gridReference);
	}
	
	public void fromData(String[] row) throws Exception
	{
		id = row[0];
		occupancy = SimUtil.makeInteger(row[1]);
		gridReference = row[2];	
		region = row[3];
	}
	
	public String[] headerRow() {return header;}
	private String[] header = {"id","Occupancy","Grid","Region"};

	
	public String[] dataRow()
	{
		String[] row = new String[4];
		row[0] = getId();
		row[1] = new Integer(occupancy).toString();
		row[2] = gridReference;
		row[3] = region;
		return row;
	}
	

}
