package com.openmapping.covid.model;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import com.openmapping.covid.SimUtil;
import com.openmapping.covid.WeightReader;
import com.openmapping.covid.cMain;
import com.openmapping.covid.display.DaySummary;
import com.openmapping.covid.display.ResultAnalyser;

public class ModelRunner {
	
	private Factory factory;
	private WeightReader reader;
	private ResultAnalyser analyser;
	private cMain main;
	
	public void setAnalyser(ResultAnalyser analyser) {this.analyser = analyser;}
	
	private Vector<String[]> parameters = new Vector<String[]>();
	
	public static String[] states = {"A","B","C","D","E","F","G","H","J","K","L","M","N"};
	
	private Runtime runtime;
	
	private long[] eTime = new long[10];
	private void getTime(int index) {eTime[index] = System.currentTimeMillis();}
	
	/**
	 * Outer Vector = scenarios; middle Vector = runs; inner Vector = days
	 * @return
	 */
	public DaySummary getSummary(int scenario,int run,int day) {return getSummaries(scenario,run).get(day);} 	
	public Vector<DaySummary> getSummaries(int scenario,int run) {return getSummaries(scenario).get(run);} 	
	public Vector<Vector<DaySummary>> getSummaries(int scenario) {return summaries.get(scenario);} // scenario runs from 0 to n-1	
	public Vector<Vector<Vector<DaySummary>>> getSummaries() {return summaries;}

	private Vector<Vector<Vector<DaySummary>>> summaries = new Vector<Vector<Vector<DaySummary>>>();
	
	//--------------------------------------------------------------------------------------------
	//                                   constructor and initialisation
	//--------------------------------------------------------------------------------------------


	
	public ModelRunner(Factory factory,WeightReader reader,cMain main) throws Exception
	{
		this.factory = factory;
		this.reader = reader;
		this.main = main;
		
		parameters = reader.getData("Parameters");
		
		runtime = Runtime.getRuntime();
	}
	
	
	//--------------------------------------------------------------------------------------------
	//                                  running the model
	//--------------------------------------------------------------------------------------------

	
	public void runModel() throws Exception
	{
		//check all peoples' initial disease states and changes
		checkAllDiseaseStates(0);
						
		// Vectors run over scenarios, runs, days
		summaries = new Vector<Vector<Vector<DaySummary>>>();

		// iterate over scenarios
		for (int scen = 0; scen < factory.nScenarios();scen++)
		{
			// Set up this scenario empty - no runs
			summaries.add(new Vector<Vector<DaySummary>>());

			for (int run = 0; run < runs(); run++)
			{
				// set up this run empty - no days
				summaries.get(scen).add(new Vector<DaySummary>());

				// re-initialise all the people
				factory.refreshPersons();
				
				// set up state for day 0
				DaySummary day0 = new DaySummary(factory, reader, scen,run,0);
				day0.setState();
				summaries.get(scen).get(run).add(day0);
				
				// iterate over all days
				DaySummary currentDaySummary = day0;
				boolean cutoff = false;
				int lastRunDay = 0;
				for (int day = 0; day < dayEnd(scen); day++) if (!cutoff)
				{
					String day_id = "d_" + day;
					DayEncounterSet encounters = factory.getDayEncounterSet(day_id);
					if (encounters == null) throw new Exception("No encounters for day " + day);

					getTime(1);					
					currentDaySummary = nextDay(currentDaySummary,encounters,scen,run);
					summaries.get(scen).get(run).add(currentDaySummary);
					
					// do no more days if too many people have been through state B (infected)
					getTime(2);					
					cutoff = testCutoff();
					lastRunDay = day;

					
					// look at performance
					getTime(3);					
					// SimUtil.message("Scenario " + scen + " run " + run + " day " + day + " t2: " + interval(2) + " t3: " + interval(3));
					
				}
				
				// summarise the infection events in the periods of the scenario
				analyser.newPeriodSummaries(scen, run,lastRunDay);
				
			}
			
		}
		
	}
	

	/**
	 * test for cutoff of any run before it would finish, when too many people have passed though an infected state.
	 * Different runs of the same scenario may have different cutoffs
	 * @return
	 */
	private boolean testCutoff() throws Exception
	{
		int cutoffNumber = new Integer(reader.getParameterValue("cutoff")).intValue();
		
		int n = 0;
		for (Enumeration<Person> en = factory.getPersons().elements();en.hasMoreElements();)
			if (en.nextElement().hasBeeninfected()) n++;
		
		return (n > cutoffNumber);
	}
	
	/**
	 * 
	 */
	private void checkAllDiseaseStates(int day) throws Exception
	{
		for (Enumeration<Person> en = factory.getPersons().elements();en.hasMoreElements();)
		{
			Person p = en.nextElement();
			p.checkDiseaseState(day);
		}
	}
	
	
	/**
	 * 
	 * @param today
	 * @param dayEncounters
	 * @return
	 * @throws Exception
	 */
	private DaySummary nextDay(DaySummary today, DayEncounterSet dayEncounters, int scenario, int run) throws Exception
	{
		int day = today.getDay();
		
		int period = getPeriod(scenario, day);
		
		makeAllExposures(scenario, period, today,dayEncounters);
		today.setState();

		advanceAllOneDay(scenario, period, day);
		
		DaySummary tomorrow = new DaySummary(factory, reader, scenario,run, day+ 1);
		tomorrow.setState();
		
		return tomorrow;
	}
	
	/**
	 * advance all people by one day - changing their disease state according to their last transition
	 * @param day
	 * @throws Exception
	 */
	private void advanceAllOneDay(int  scenario, int period, int day) throws Exception
	{
		// apply notify policies to all people
		applyNotifyPolicies(scenario, period,day);
				
		// move everybody on a day
		for (Enumeration<Person> en= factory.getPersons().elements(); en.hasMoreElements();)
		{
			Person p = en.nextElement();
			String pid = p.getId();
			p.advanceOneDay(day);
			p.checkDiseaseState(day + 1);
		}
		
	}
	
	/**
	 * 
	 * @param scenario
	 * @param period
	 * @param day
	 */
	private void applyNotifyPolicies(int scenario, int period, int day) throws Exception
	{
		for (NotifyPolicy policy: factory.getNotifyPolicies(scenario, period))
			for (Enumeration<Person> en = factory.getPersons().elements();en.hasMoreElements();)
			{
				Person person = en.nextElement();
				policy.doNotifyFrom(person,day);
			}
	}

	
	/**
	 * find all infectious people. For each one, find all meetings where they may expose somebody.
	 * @param today
	 * @param dayEncounters
	 */
	private void makeAllExposures(int scenario, int period, DaySummary today, DayEncounterSet dayEncounters) throws Exception
	{
		Vector<String> infectiousPids = today.infectiousPeople();
		int day = today.getDay();
		
		// find all potential meetings of infectious people, in groups or at home
		int totalPotential = 0;
		for (String pid: infectiousPids)
		{
			// for debug 
			Person per = factory.getPerson(pid);
			String a = per.socialHistory();
			String b = per.diseaseHistory();
			
			totalPotential= totalPotential + makeGroupExposures(pid,scenario, period, day, dayEncounters);
			
			makeHomeExposures(pid, day);
		}
		
		// average number of potential meetings per infectious person
		double mean = new Double(totalPotential).doubleValue()/infectiousPids.size();
		mean = mean +1.0;
	
		
	}
	
	/**
	 * retrun number of potential encounters for this person
	 * @param pid
	 * @param day
	 * @param dayEncounters
	 * @throws Exception
	 */
	private int makeGroupExposures(String pid, int scenario, int period, int day, DayEncounterSet dayEncounters) throws Exception
	{
		int encounters = 0;
		// no group encounters if the person is confined or isolated
		if ("F".equals(factory.getPerson(pid).getCurrentSocialState()))
		{
			// potential meetings of infectious people at groups
			Vector<String[]> meetings = dayEncounters.getPersonEncounters(pid);
			encounters = meetings.size();
			for (String[] meetingData: meetings)
			{
				// meetingsData = [group id, other person.id, number of encounters];
				String otherId = meetingData[1];
				String groupId = meetingData[0];
				
				if (exposable(otherId))
				{
					// apply meeting policies to compute the probability that a meeting occurs			
					// Monte Carlo decision that the other person is exposed
					double rand = applyPolicies(scenario,period,meetingData);
					if (rand > Math.random())
						exposeAtGroup(day,pid,otherId,groupId);
				}
			}
		}

		return encounters;
	}
	
	/**
	 * a person can only be exposed to infection if they are not infected - state 'C'
	 * @param pid
	 * @return
	 */
	private boolean exposable(String pid)
	{
		return ("C".equals(factory.getPerson(pid).getCurrentDiseaseState()));
	}

	/**
	 * 
	 * @param pid
	 * @param day
	 * @param dayEncounters
	 * @throws Exception
	 */
	private void makeHomeExposures(String pid, int day) throws Exception
	{
		Person infector = factory.getPerson(pid);
		// no home encounters if the person is isolated
		if (!"I".equals(infector.getCurrentSocialState()))
		{
			 // meetings of infectious people at home
			{
				Household home = infector.getHousehold();
				for (Person exposed: home.getPeople())
				{
					String otherId = exposed.getId();
					if ((otherId!= pid) && (exposable(otherId)))
					  exposed.exposeAtHome(day,pid);
				}
			}
		}

	}

	/**
	 * Find the probability that a meeting takes place and a person is exposed to the virus, given policies in force
	 * @param day
	 * @param meetingData
	 * @return
	 */
	private double applyPolicies(int scenario, int period, String[] meetingData) throws Exception
	{
		double pMeet = exposeProbability(); // probability of exposure, given a meeting
		
		// each policy diminishes the probability of a meeting occurring, multiplicatively
		for (MeetingPolicy  policy: factory.getMeetingPolicies(scenario, period))
		{
			pMeet = pMeet*policy.getPolicyProbability(meetingData);
		}
		return pMeet;
	}

	
	//--------------------------------------------------------------------------------------------
	//                                 simple stuff
	//--------------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param pid
	 * @param gid
	 */
	private void exposeAtGroup(int day, String exposerId,String pid, String gid) throws Exception
	{
		Person exposed =  factory.getPerson(pid);		
		Person exposer =  factory.getPerson(exposerId);	
		EncounterGroup group = factory.getEncounterGroup(gid);
		exposed.exposeAtGroup(day, exposer,group);
	}
	
	
	
	/**
	 * the simulation ends on the last day of the last period, in each scenario
	 * @return
	 */
	public int dayEnd(int scenario)
	{
		int nPeriods = factory.nPeriods(scenario);
		Period last = factory.getPeriod(scenario, nPeriods-1);
		return last.getEndDay();
	}
	
	/**
	 * 
	 * @param day
	 * @return
	 */
	public int getPeriod(int scenario, int day) throws Exception
	{
		int pNo = -1;
		int nPeriods = factory.nPeriods(scenario);
		boolean found = false;
		for (int p = 0; p < nPeriods; p++) if (!found)
		{
			Period pp = factory.getPeriod(scenario, p);
			if (pp.getEndDay() > day - 1)
			{
				pNo = p;
				found = true;
			}
		}
		
		if (pNo == -1) throw new Exception("No period covers day " + day + " of scenario " + scenario);
		return pNo;
	}

	/**
	 * if there is an encounter and one of the people is infectious,
	 * the probability that the other person is exposed
	 * @return
	 * @throws Exception
	 */
	public double exposeProbability() throws Exception
	{
		double prob = 0.0;
		String[] param = param("infect_probability");
		prob =  new Double(param[1]).doubleValue();
		return prob;			
	}
	
	/**
	 * 
	 * @return number of Monte Carlo runs
	 * @throws Exception
	 */
	public int runs() throws Exception
	{
		int runs = 0;
		String[] param = param("runs");
		runs =  new Integer(param[1]).intValue();
		return runs;			
	}
	
	
	/**
	 * 
	 * @param paramName
	 * @return
	 * @throws Exception
	 */
	public String[] param(String paramName) throws Exception
	{
		String[] res = null;
		for (String[] param: parameters)
			if (paramName.equalsIgnoreCase(param[0]))
				res = param;
		
		if (res == null) throw new Exception("No parameter " + paramName);
		return res;
	}
	
	/**
	 * Take the set of people who have state = stateCode on the last day, from the set of people provided.
	 * write a csv table of the number of these people in each state over all days
	 * @param crowd
	 */
	private void writePopulationHistory(String stateCode,Hashtable<String,Person> crowd)
	{
		SimUtil.message("\n\nPopulation history for final state " + stateCode);
		String header = "\nDay";
		for (String state: states) header = header + "," + state;
		SimUtil.message(header);
		
		int days =  crowd.elements().nextElement().getDiseaseStates().size();
		int[][] row = new int[days][states.length];
		for (int c = 0; c < states.length;c++)
			for (int d = 0; d < days;d++) row[d][c] = 0;
		
			for (Enumeration<Person> en = crowd.elements();en.hasMoreElements();)
			{
				Person person = en.nextElement();
				if (("all".equalsIgnoreCase(stateCode))||(person.getCurrentDiseaseState().equals(stateCode)))
				{
					for (int d = 0; d < days; d++)
					{
						String code = person.getDiseaseStates().get(d);
						row[d][stateIndex(code)]++;
					}
				}
			}
			
			for (int d = 0; d < days; d++)
			{
				String line = new Integer(d).toString();
				for (int c = 0; c < states.length; c++)
				{
					line = line + "," + row[d][c];
				}
				SimUtil.message(line);
			}
	}
	
	private int stateIndex(String code)
	{
		return SimUtil.positionInArray(code, states);
	}
	
	

}
