package com.openmapping.covid.model;

import java.util.Hashtable;
import java.util.StringTokenizer;

import com.openmapping.covid.SimUtil;
import com.openmapping.covid.WeightReader;

public abstract class Policy {
		
	protected Factory factory;
	
	protected WeightReader reader;
	
	public String getParamValue(String paramName) {return parameter.get(paramName);}
	protected Hashtable<String,String> parameter = new Hashtable<String,String>();
	
	protected String description;
	
	public int getScenario() {return scenario;}
	protected int scenario;
		
	public int getPeriod() {return period;}
	protected int period;
	
	public String getName() {return policyName;}
	protected String policyName;
	
	protected int getPolicyIndex() {return policyIndex;}
	protected int policyIndex;
	
	protected String parameterString;
	
	abstract protected String[] allowedPolicyNames();
	
	public Policy(Factory factory,WeightReader reader, String[] policyData) throws Exception
	{
		this.factory = factory;
		this.reader = reader;
		
		// use internal representations 0..N-1 of scenario number and period number
		scenario = new Integer(policyData[0]).intValue() - 1;
		period = new Integer(policyData[1]).intValue() -1;
		
		policyName = policyData[2];
		if (!SimUtil.inArray(policyName, allowedPolicyNames())) throw new Exception ("No allowed policy '" + policyName + "'");
		policyIndex = SimUtil.positionInArray(policyName, allowedPolicyNames());
		
		setParameters(policyData[4]);
		
		description = policyData[5];
	}
	
	
	private void setParameters(String pString)
	{
		parameterString = pString;
		StringTokenizer st = new StringTokenizer(pString," ");
		while (st.hasMoreTokens())
		{
			StringTokenizer su = new StringTokenizer(st.nextToken(),"=");
			String paramName = su.nextToken();
			String paramValue = su.nextToken();
			parameter.put(paramName, paramValue);
		}
	}



}
