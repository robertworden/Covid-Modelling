package com.openmapping.covid.model;

/** 
 * An instance of a state transition, tied to a particular person and a particular day
 * 
 * @author robert
 *
 */

public class StateChange {
	
	private Person person;
	
	private DiseaseState fromState; 
	
	/**
	 *  must be the current state of the person, after advanceOneDay
	 * @return
	 */
	public String getFromCode() {return fromState.getCode();}
	
	private DiseaseState toState; 
	
	/**
	 *  the next state the person will go to, after one or more days
	 * @return
	 */
	public String getToCode() {return toState.getCode();}
	
	/**
	 *  the first day on which the person had this state
	 * @return
	 */
	public int getFirstDay() {return firstDay;} 
	private int firstDay;
	
	/**
	 *  duration of the state; one or more days
	 * @return
	 */
	public int getDuration() {return duration;} 
	private int duration;
	
	/**
	 *  last day on which the person will have this state; 
	 *  day on which the transition to toState will take place
	 * @return
	 */
	public int getLastDay() {return firstDay + duration;}
	
	private Factory factory;
	
	//------------------------------------------------------------------------------------------------------------
	//
	//------------------------------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param person
	 * @param fromCode
	 * @param toCode
	 * @param firstDay
	 * @param duration
	 */
	public StateChange(Person person,String fromCode, String toCode, int firstDay, int duration) throws Exception
	{
		this.person = person;
		
		factory = person.getFactory();
		
		fromState = factory.getDiseaseState(fromCode);
		if (fromState == null) Factory.debug("Invalid from state " + fromCode);

		toState = factory.getDiseaseState(toCode);
		if (toState == null) Factory.debug("Invalid to state " + toCode);
		
		this.firstDay = firstDay;
		this.duration = duration;
		
		if (duration < 1) Factory.debug("State change cannot have duration " + duration + " less than one day");
	}
	
	/**
	 * this check should always be correct for any person, after advanceOneDay
	 * @param day
	 * @throws Exception
	 */
	public void checkState(int day) throws Exception
	{
		// check that the from state is the current state of the person
		if (!(person.getCurrentDiseaseState().equals(getFromCode()))) 
			Factory.debug("State change check failed: " + getFromCode() + " is not " + person.getCurrentDiseaseState());
		
		// check that the last day of the from state is tomorrow or later
		if (getLastDay() < day)
			Factory.debug("State change check failed: last day of current state" + getLastDay() + " is less than " + day);
	}

}
