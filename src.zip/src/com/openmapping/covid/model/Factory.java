package com.openmapping.covid.model;

import java.io.File;
import java.io.FileInputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import com.openmapping.covid.SimUtil;
import com.openmapping.covid.WeightReader;

public class Factory {
	
	
	public String getRootFolderPath() {return rootFolderPath;}
	
	private String rootFolderPath;
	
	private String dataFolder() {return (rootFolderPath + "/dataFiles/");}
	
	private WeightReader reader;
		
	public Household getHousehold(String id) {return households.get(id);}
	private Hashtable<String,Household> households = new Hashtable<String,Household>();
	
	public Person getPerson(String id) {return persons.get(id);}
	public Hashtable<String,Person> getPersons() {return persons;}
	protected Hashtable<String,Person> persons = new Hashtable<String,Person>();
	
	public EncounterGroup getEncounterGroup(String id) {return groups.get(id);}
	public Hashtable<String,EncounterGroup> getGroups() {return groups;}
	protected Hashtable<String,EncounterGroup> groups = new Hashtable<String,EncounterGroup>();

	public DayEncounterSet getDayEncounterSet(String id) {return dayEncounterSets.get(id);}
	public Hashtable<String,DayEncounterSet> getDayEncounterSets() {return dayEncounterSets;}
	private Hashtable<String,DayEncounterSet> dayEncounterSets = new Hashtable<String,DayEncounterSet>();
	
	public Vector<Region> getRegions() {return regions;}
	private Vector<Region> regions = new Vector<Region>();
	
	private void emptyPopulation()
	{
		regions = new Vector<Region>();
		households = new Hashtable<String,Household>();
		persons = new Hashtable<String,Person>();
		groups = new Hashtable<String,EncounterGroup>();
		dayEncounterSets = new Hashtable<String,DayEncounterSet>();
	}
	
	public Vector<String[]>  getTransitionProbabilities() { return transitionProbabilities;}  	
	private Vector<String[]> transitionProbabilities;  
	
	public Vector<String[]> getTransitionTimes() {return transitionTimes;}
	private Vector<String[]> transitionTimes;
	
	public DiseaseState getDiseaseState(String code) {return diseaseStates.get(code);}
	public Hashtable<String,DiseaseState> getDiseaseStates() {return diseaseStates;}
	private Hashtable<String,DiseaseState> diseaseStates = new Hashtable<String,DiseaseState>();
	
	// disease state codes, in the order they are read in
	public Vector<String> getDiseaseStateCodes() {return diseaseStateCodes;}
	private Vector<String> diseaseStateCodes = new Vector<String>();
	
	public int nScenarios() {return scenarioNames.size();}
	public String getScenarioName(int s) {return scenarioNames.get(s);}
	private Vector<String> scenarioNames = new Vector<String>();
	public int getScenarioIndex(String sName) {return SimUtil.positionInVector(sName, scenarioNames);}
	
	public int nPeriods(int scenarioNo) {return periods.get(scenarioNo).size();}
	public Period getPeriod(int scenarioNo, int periodNo) {return periods.get(scenarioNo).get(periodNo);}
	public Period getNamedPeriod(int scenarioNo, String label)
	{
		Period per = null;
		for (Period p: periods.get(scenarioNo)) if (p.getLabel().equals(label)) per = p;
		return per;
	}
	private Vector<Vector<Period>> periods = new Vector<Vector<Period>>();
	
	public int nRuns() {return nRuns;}
	private int nRuns = 1;
		
	// meeting policies in force - which may veto encounters, or lower their probability
	private Vector<MeetingPolicy> meetingPolicies = new Vector<MeetingPolicy>();

	// notify policies in force - which may eg notify recent contacts of a person
	private Vector<NotifyPolicy> notifyPolicies = new Vector<NotifyPolicy>();
	
	public Vector<MeetingPolicy> getMeetingPolicies(int scenario, int period)
	{
		Vector<MeetingPolicy> policies = new Vector<MeetingPolicy>();
		for (MeetingPolicy policy: meetingPolicies)
			if ((policy.getScenario() == scenario) && (policy.getPeriod() == period)) policies.add(policy);
		return policies;
	}

	
	public Vector<NotifyPolicy> getNotifyPolicies(int scenario, int period)
	{
		Vector<NotifyPolicy> policies = new Vector<NotifyPolicy>();
		for (NotifyPolicy policy: notifyPolicies)
			if ((policy.getScenario() == scenario) && (policy.getPeriod() == period)) policies.add(policy);
		return policies;
	}
	
	private Runtime runtime;

	
	//------------------------------------------------------------------------------------------------------
	//                           Constructor, and date  needed at the start
	//------------------------------------------------------------------------------------------------------


	public Factory(WeightReader reader, String rootFolderPath) throws Exception
	{
		this.reader = reader;
		this.rootFolderPath = rootFolderPath;
		
		transitionProbabilities = reader.getData("Transitions");
		transitionTimes = reader.getData("TransitionDays");
		
		runtime = Runtime.getRuntime();
		
		makeScenariosAndPeriods(); // periods are needed for drawing lines on graph grids, before the rest of the model
		
		makeDiseaseStates();  // needed to run simulations
		makePolicies();
		
		makeRegions(); // needed for initial map view
	}
	
	/**
	 * make all disease states and state transitions
	 * @throws Exception
	 */
	private void makeDiseaseStates() throws Exception
	{
		Vector<String[]> stateLines = reader.getData("States");
		
		for (int i = 1; i < stateLines.size();i++)
		{
			String[] sLine = stateLines.get(i);
			DiseaseState dis = new DiseaseState(sLine, this);
			diseaseStates.put(dis.getCode(),dis);
			diseaseStateCodes.add(sLine[0]);
		}
		
		Vector<String[]> transitionLines = reader.getData("Transitions");
		Vector<String[]> transitionDays = reader.getData("TransitionDays");
		
		for (Enumeration<DiseaseState> en = diseaseStates.elements();en.hasMoreElements();)
		{
			DiseaseState dis= en.nextElement();
			dis.makeTransitions(transitionLines,transitionDays);
		}
		
		makeStateProbabilities();

	}

	/**
	 * 
	 * @throws Exception
	 */
	private void makeScenariosAndPeriods() throws Exception
	{
		Vector<String[]> parameterLines = reader.getData("Parameters");
		Vector<String[]> periodLines = reader.getData("Periods");
		
		int scenarioNo = 1;
		for (String[] pLine: parameterLines)
		{
			if (pLine[0].equalsIgnoreCase("scenario"))
			{
				if (SimUtil.makeInteger(pLine[1]) != scenarioNo) throw new Exception("Scenario numbers must be ascending");
				scenarioNames.add(pLine[4]);
				periods.add(new Vector<Period>());
				scenarioNo++;
			}
			if (pLine[0].equalsIgnoreCase("runs")) nRuns = SimUtil.makeInteger(pLine[1]);
		}
		
		
		for (int p = 1; p < periodLines.size();p++)
		{
			String[] pLine =  periodLines.get(p);
			Period per = new Period(pLine);
			scenarioNo = new Integer(pLine[0]);
			if (scenarioNo > periods.size()) 
				throw new Exception("Period " + (per.getPeriodIndex() + 1) + " of scenario  " + scenarioNo 
						+ " has no scenario named in the Parameters file");
			periods.get(scenarioNo - 1).add(per);
		}
	}
	
	/**
	 * 
	 * @param policyDefs
	 */
	private void makePolicies() throws Exception
	{
		Vector<String[]> policyDefs = reader.getData("Policies");
		if (policyDefs == null) throw new Exception("No policies file");
		
		for (String[] policyDef: policyDefs)
		{
			String type = policyDef[3];
			if ("type".equalsIgnoreCase(type)) {}  // header row

			else if ("meeting".equalsIgnoreCase(type)) 	
				meetingPolicies.add(new MeetingPolicy(this,reader, policyDef));

			else if ("notify".equalsIgnoreCase(type)) 
				notifyPolicies.add(new NotifyPolicy(this,reader, policyDef));
			
			else throw new Exception("Policy type " + type + " not recognised");
		}
	}

	/**
	 * 
	 * @throws Exception
	 */
	private void makeRegions() throws Exception
	{
		Vector<String[]> regionRows = reader.getData("Regions");
		
		for (int r = 1; r < regionRows.size(); r++)
		{
			Region region = new Region(regionRows.get(r));
			regions.add(region);
			// SimUtil.message(region.getName() + "; " + neat(region.getOuterMapArea()) + " " + neat(region.getInnerMapArea()));
		}
	}

	//------------------------------------------------------------------------------------------------------
	//                Making a population model and some other classes (Period, DiseaseState)
	//------------------------------------------------------------------------------------------------------

	
	/**
	 * 
	 * @throws Exception
	 */
	public void makeModel() throws Exception
	{
		// reset the population model
		emptyPopulation();

		// regions and households
		makePopulation();
		
		// people, with initial disease state and disease transition times for each person
		makePeople();
		
		// encounters for all days
		makeEncounters();
		
		// testHermits();
		// SimUtil.message("\nMemberships\n" + groupMembershipList());
	}
	
	/**
	 * 
	 * @throws Exception
	 */
	private void makePopulation() throws Exception
	{
		makeRegions();
		
		int houses = SimUtil.makeInteger(reader.getParameterValue("households"));
		for (int hid = 0; hid < houses; hid++)
		{
			Household household = new Household(reader,this);
			String idh = "h_" + hid;
			household.setId(idh);
			household.makeRandom();
			households.put(idh,household);
			
		}
	}
	
	
	private void makePeople() throws Exception
	{
		int pid = 0;
		for (Enumeration<Household> en = households.elements();en.hasMoreElements();)
		{
			Household household  = en.nextElement();
			for (int p = 0; p < household.getOccupancy();p++)
			{
				Person person = new Person(reader, this,household);
				String idp = "p_" + pid;
				person.setId(idp);
				pid++;
				person.makeRandom();
				persons.put(idp,person);
			}

		}
	}
	
	private void makeEncounters() throws Exception
	{
		Vector<String[]> allGroupsData = reader.getData("EncounterGroups");
		int groupId = 0;
		double dayEncounters = 0.0;
		
		// iterate over types of group
		for (int i = 1; i < allGroupsData.size(); i++) // miss out header row
		{
			String[] groupData= allGroupsData.get(i);
			double encs = dayEncounters(groupData);
			dayEncounters = dayEncounters + encs;
			SimUtil.message("Encounters per day per 1000 people at " + groupData[1] + "; " + encs);
			
			// groupData[2] is the number of groups of the type per 1000 people. Calculate the number of groups
			int nGroups = (int)(SimUtil.makeReal(groupData[2])*persons.size()/1000.0);
			if (nGroups < 1) nGroups = 1;
			for (int g = 0; g< nGroups; g++)
			{
				EncounterGroup group = new EncounterGroup(reader,this,groupData);
				String idg = "g_" + groupId;
				groupId++;
				group.setId(idg);
				group.makeRandom();
				groups.put(idg, group);				
			}
		}
		
		SimUtil.message("Total encounters per day expected per 1000  people: " + dayEncounters);
		
		
		String nDays = reader.getParameterValue("days");
		int iDays = SimUtil.makeInteger(nDays);	
		int iEncounters = 0;
		for (int iDay = 0; iDay< iDays; iDay++)
		{
			String day = new Integer(iDay).toString();
			DayEncounterSet dSet = new DayEncounterSet(reader, this, day);
			String dKey  = DayEncounterSet.makeKey(iDay);
			dSet.setId(dKey);
			dSet.makeRandom();
			dayEncounterSets.put(dKey, dSet);
			iEncounters = iEncounters + dSet.getEncounterNumber();
		}
		
		SimUtil.message("\nTotal encounters per day created: " + (iEncounters/iDays));
		SimUtil.message("People: "+ persons.size());
		double perPersonPerDay = new Double(iEncounters).doubleValue()/new Double(iDays*persons.size()).doubleValue();
		SimUtil.message("Encounters per day per person: " + perPersonPerDay);
		
		
	}
	
	/**
	 * total encounters per day expected from all groups of the type
	 * The sum over all groups of 0.5*P*(N*V)**2
	 * @param gData
	 * @return
	 */
	private double dayEncounters(String[] gData) throws Exception
	{
		double g = SimUtil.makeReal(gData[2]); // number of groups
		double n = SimUtil.makeReal(gData[3]); // number of people in group
		double v = SimUtil.makeReal(gData[4]); // number of visits per day per person
		double p = SimUtil.makeReal(gData[5]); // number of encounters per pair  both visiting
		return 0.5*g*n*n*v*v*p;
	}
	
	//-----------------------------------------------------------------------------------------------------------------
	//                                   writing the population model to csv files
	//-----------------------------------------------------------------------------------------------------------------

	
	/**
	 * 
	 * @throws Exception
	 */
	public void writeModel() throws Exception
	{
		
		
		// check round trips (to and from csv file rows) for all model entities
		for (Enumeration<Household> en = households.elements();en.hasMoreElements();) en.nextElement().roundTrip();
		for (Enumeration<Person> en = persons.elements();en.hasMoreElements();) en.nextElement().roundTrip();
		for (Enumeration<EncounterGroup> en = groups.elements();en.hasMoreElements();) en.nextElement().roundTrip();
		for (Enumeration<DayEncounterSet> en = dayEncounterSets.elements();en.hasMoreElements();) en.nextElement().roundTrip();

		// write out csv files
		writeEntity("households",households);
		writeEntity("persons",persons);
		writeEntity("groups",groups);
		writeEntity("dayEncounterSets",dayEncounterSets);

	}
	
	/**
	 * 
	 * @param entityName
	 * @param entities
	 * @throws Exception
	 */
	public void writeEntity(String entityName, Hashtable<String,?> entities) throws Exception
	{
		Vector<String[]> csvRows = new Vector<String[]>();
		boolean topRow = true;
		for (Enumeration<String> en = entities.keys();en.hasMoreElements();) 
		{
			String key= en.nextElement();
			Object ent = entities.get(key);
			if (topRow)
			{
				csvRows.add(((ModelEntity)ent).headerRow());
				topRow = false;				
			}
			csvRows.add(((ModelEntity)ent).dataRow());		
		}
		
		String filePath = dataFolder() + entityName + ".csv";
		SimUtil.writeCSVFile(filePath, csvRows);
	}
	
	
	//-----------------------------------------------------------------------------------------------------------------
	//                                   reading the population model from csv files
	//-----------------------------------------------------------------------------------------------------------------


	
	/**
	 * 
	 * @throws Exception
	 */
	public void readModel() throws Exception
	{
		// empty the tables that make the population model
		emptyPopulation();
		
		// make the regions again
		makeRegions();
		
		Vector<String[]> rows;
		
		rows = readEntity("households");
		for (int i = 1; i < rows.size();i++)
		{
			String[] row = rows.get(i);
			Household hh = new Household(reader,this);
			hh.fromData(row);
			households.put(hh.getId(), hh);
		}
		// SimUtil.message("Read " + (rows.size() - 1) + " households");
		
		readPersons();
		// SimUtil.message("Read " + (rows.size() - 1) + " persons");
		
		rows = readEntity("groups");
		for (int i = 1; i < rows.size();i++)
		{
			String[] row = rows.get(i);	
			EncounterGroup ee = new EncounterGroup(reader,this,null);
			ee.fromData(row);
			groups.put(ee.getId(), ee);
		}
		// SimUtil.message("Read " + (rows.size() - 1) + " groups");
		
		rows = readEntity("dayEncounterSets");
		for (int i = 1; i < rows.size(); i++)
		{
			String[] row = rows.get(i);	
			DayEncounterSet dd = new DayEncounterSet(reader,this, null);
			dd.fromData(row);
			dayEncounterSets.put(dd.getId(), dd);
		}

	}
	
	public void readPersons() throws Exception
	{
		persons = new Hashtable<String,Person>();
		Vector<String[]> rows = readEntity("persons");
		for (int i = 1; i < rows.size();i++)
		{
			String[] row = rows.get(i);	
			Person pp = new Person(reader,this,null);
			pp.fromData(row);
			persons.put(pp.getId(), pp);
		}
	}
	
	/**
	 * put all Person objects back to their start state for a new run of the simulation
	 */
	public void refreshPersons() throws Exception
	{
		long memory = runtime.totalMemory() - runtime.freeMemory();
		// SimUtil.message("Memory before gc: " + memory);
		for (Enumeration<String> en = persons.keys();en.hasMoreElements();)
		{
			String key = en.nextElement();
			persons.get(key).refresh();
		}
		runtime.gc();
		memory = runtime.totalMemory() - runtime.freeMemory();
		// SimUtil.message("Memory after gc: " + memory);
	}
	
	/**
	 * 
	 * @param entityName
	 * @param entities
	 * @throws Exception
	 */
	public Vector<String[]> readEntity(String entityName) throws Exception
	{
		String filePath = dataFolder() + entityName + ".csv";
		File csvFile = new File(filePath);
		FileInputStream stream = null;
		try {stream = new FileInputStream(csvFile);}
		catch (Exception ex) {throw new Exception("Cannot find expected data file at path " + filePath);}
		Vector<String[]> rows = SimUtil.getCSVRows(stream);
		return rows;
	}
	
	/**
	 * 
	 * @param entityName
	 * @param entities
	 * @throws Exception
	 */
	public Vector<String> readExplanation(String entityName) throws Exception
	{
		String filePath = dataFolder() + entityName + ".txt";
		File textFile = new File(filePath);

		FileInputStream stream = null;
		Vector<String> rows = null;
		try {stream = new FileInputStream(textFile);rows = SimUtil.getTextLines(stream);}
		catch (Exception ex) {}

		return rows;
	}
	
	//----------------------------------------------------------------------------------------------------------------
	//                                                 miscellaneous
	//----------------------------------------------------------------------------------------------------------------
	
	
	/**
	 * 
	 * @return
	 */
	public Person getRandomPerson() throws Exception
	{
		int size = persons.size() -1;
		int index = (int)(size*Math.random());
		if (index > size) index = size;
		int i = 0;
		for (Enumeration<String> en = persons.keys(); en.hasMoreElements();)
		{
			String id = en.nextElement();
			if (i == index) return persons.get(id);
			i++;
		}
		throw new Exception("Random person not found");
	}
	
	/**
	 * make a random grid reference on the map, in regions according to thier population in the map 
	 * @return
	 * @throws Exception
	 */
	public String makeRandomGridRef() throws Exception
	{
		String gridRef = "";
		// choose a region at random
		Region reg = getRandomRegion();
		
		double xMin = reg.getXMin();
		if (xMin < 0) xMin = 0;
		double xMax = reg.getXMax();
		if (xMax > 100.0) xMax = 100.0;
		double yMin = reg.getYMin();
		if (yMin < 0) yMin = 0;
		double yMax = reg.getYMax();
		if (yMax > 100.0) yMax = 100.0;
				
		boolean found = false;
		
		int tries = 0;
		while (!found)
		{
			// choose a random x value (easting) in the region's outer rectangle and in the map
			double dEast = ((xMin + (xMax- xMin)*Math.random()))/100.0;
			String east = fourAfterPoint(dEast);

			// choose a random y value (northing) in the region's outer rectangle and in the map
			double dNorth = ((yMin + (yMax - yMin)*Math.random()))/100.0;
			String north = fourAfterPoint(dNorth);
			gridRef = east + "_" + north;
			
			// check that this point , in the region's outer rectangle, is really in the region
			found = reg.inRegion(gridRef);
			
			// check for strange overruns
			tries++;
			if (tries > 100) throw new Exception("Too many tries to find a grid reference in " + reg.getName());
		}
		
		return gridRef;
	}
	
	private String fourAfterPoint(double d)
	{
		String val = new Double(d).toString(); 
		StringTokenizer st = new StringTokenizer(val,".");
		st.nextToken();
		String ds = st.nextToken();

		if (ds.length() == 1) ds = ds + "000";
		if (ds.length() == 2) ds = ds + "00";
		if (ds.length() == 3) ds = ds + "0";
		if (ds.length() > 4) ds = ds.substring(0, 4);
		return ds;
	}

	
	/**
	 * pick one region at random, with probability given by its population in the map
	 * @param regions
	 * @return
	 */
	private Region getRandomRegion()
	{
		Region chosen = null;
		double rand = Math.random();

		double  popTotal = 0;
		for (Region region: regions) popTotal = popTotal + region.getPopulationInMap();

		double  popSum = 0;
		boolean found = false;
		for (Region region: regions) if (!found)
		{
			popSum = popSum + region.getPopulationInMap();
			if (popSum > (rand*popTotal)) 
			{
				found = true;
				chosen = region;
			}
		}
		return chosen;
	}
	
	
	/**
	 * distance between two grid references, on a scale 0 to 1
	 * @param grid1
	 * @param grid2
	 * @return
	 */
	public double distance(String grid1, String grid2) throws Exception
	{
		String[] grids = new String[2];// the two grid references
		grids[0] = grid1;
		grids[1] = grid2;

		double[] disp = new double[2]; // displacements in north and east directions
		
		for (int i = 0; i < 2; i++) // iterate over north, east
		{
			double[] pos = new double[2]; // the coordinate of points 1, 2
			for (int g = 0; g < 2; g++)
			{
				int start = 5*g; // first char of north part or east part
				String dValue =  "0." + grids[g].substring(start, start + 4);
				pos[g] = SimUtil.makeReal(dValue);
			}
			disp[i] = pos[1] - pos[0]; // displacement from first to second grid ref
		}
		
		double dist = Math.sqrt(disp[0]*disp[0] + disp[1]*disp[1]);
		return dist;
	}
	
	/**
	 * 
	 * @param gridRef
	 * @return
	 */
	public String regionName(String gridRef) throws Exception
	{
		String name ="no region";
		
		for (Region region: getRegions())
			if (region.inRegion(gridRef)) name = region.getName();
		
		return name;
		
	}
	
	public String getDiseaseCodeFromName(String name) throws Exception
	{
		String code = "";
		
		Vector<String[]> states = reader.getData("States");
		for (String[] state: states)
			if (name.equals(state[1])) code = state[0];
		
		if ("".equals(code)) throw new Exception("No disease state '" + name + "'");
		
		return code;
	}
	
	public static int[] getRange(String ageRange) throws Exception
	{
		int[] range = new int[2];
		if ("all".equalsIgnoreCase(ageRange))
		{
			range[0] = 0;
			range[1] = 100;
		}
		else try
		{
			StringTokenizer st = new StringTokenizer(ageRange,"- ");
			range[0] = SimUtil.makeInteger(st.nextToken());
			range[1] = SimUtil.makeInteger(st.nextToken());
		}
		catch (Exception ex) {throw new Exception("Invalid age range: '" + ageRange + "'");}
		return range;
		
	}
	
	public static void debug(String s) throws Exception
	{
		String debug = s; // line here to put a break point for debugging
		throw new Exception(debug);
	}
	
	//--------------------------------------------------------------------------------------------
	//               making disease state probabilities as a function of days after exposure
	//--------------------------------------------------------------------------------------------

	
	
	/**
	 * 
	 * @throws Exception
	 */
	private void makeStateProbabilities() throws Exception
	{
		int traceDecade = -5; // set to 0 to get a trace
		DiseaseState someState = getDiseaseStates().elements().nextElement();
		int maxDays  = someState.getMaxDays();
		
		// do the calculation for each decade of age
		for (int decade = 0; decade < someState.getMaxDecades(); decade++)
		{
			if (decade == traceDecade) {writeCodeHeader();}
			
			// on day 0 after exposure, only state A or E (exposed) is populated
			DiseaseState initialState = getDiseaseState("A");
			if (initialState == null) initialState = getDiseaseState("E");
			
			initialState.addCurrentStateProbability(0, 0, decade, 1.0);
			initialState.addArrivedStateProbability(0, 0, decade, 1.0);

			if (decade == traceDecade) writeStateProbabilities(0, 0);
			checkProbabilitySum(0, decade);
			
			// iterate over all days except the last, calculating the next day
			for (int day = 0; day < someState.getMaxDays() - 1; day++)
			{

				stepOneDay(day, decade);
				
				if (decade == traceDecade) writeStateProbabilities(day + 1, decade);

				checkProbabilitySum(day + 1, decade);
			}
		}		
	}
	
	/**
	 * from the probabilities in day day, calculate the probabilities for day (day + 1)
	 * param day
	 * @param decade
	 */
	private void stepOneDay(int day, int decade) throws Exception
	{
		for (Enumeration<DiseaseState> en = getDiseaseStates().elements();en.hasMoreElements();)
		{
			DiseaseState state1 = en.nextElement();
			if (state1.getStateProbability(day, decade) > 0.0)
			{
				// move all current probabilities and arrived probabilities forward to tomorrow
				state1.moveCurrentProbsForward(day, decade);
				state1.moveArrivedProbsForward(day, decade);

				for (Enumeration<StateTransition> ep =  state1.getTransitions().elements();ep.hasMoreElements();)
				{
					StateTransition trans = ep.nextElement();
					DiseaseState state2 = trans.getToState();
					makeTomorrowProbability(state1, state2, day,decade);
				}
			}

		}		
	}
	
	/**
	 * 
	 * @param state1
	 * @param state2
	 * @param day
	 * @param decade
	 * @throws Exception
	 */
	private void makeTomorrowProbability(DiseaseState state1, DiseaseState state2, int day, int decade) throws Exception
	{
		// tracing
		int dec = -5; // decade for which there is tracing
		String code1 = state1.getCode();
		String code2 = state2.getCode();
		String daySum = code1 + code2 + " " + day + "\t";
		double sProb = 0.0;
		
		for (int startDay = 0; startDay < day+1; startDay++)
		{
			
			int daysAgo = day - startDay + 1; // daysAgo must be appropriate for tomorrow
			// probability of being in the first state from the start day
			double startProb = state1.getArrivedStateProbability(startDay,day, decade);
			// conditional probability of making the transition to the second state
			double condProb = state1.conditionalTransProb(daysAgo, decade, state2.getCode());
			// transition probability
			double tProb = startProb*condProb;
			sProb = sProb + tProb;
			
			// add to the probability of the second state, for tomorrow; subtract from current state for double entry
			state2.addCurrentStateProbability(day + 1, day + 1, decade, tProb);
			state1.addCurrentStateProbability(startDay, day+ 1, decade, -tProb);
			
			// set up the arrived probability for tomorrow
			state2.addArrivedStateProbability(day + 1, day + 1, decade, tProb);
			
			// diagnostic trace
			if (tProb > 0.0) daySum = daySum + "[" + startDay + "," + neat(tProb) +"] ";
			else daySum = daySum + startDay + " ";
			
		}
		if (decade == dec) SimUtil.message(daySum + "\t" + neat(sProb));

	}

	
	/**
	 * 
	 * @param day
	 * @param decade
	 * @throws Exception
	 */
	private void checkProbabilitySum(int day, int decade) throws Exception
	{
		double probSum = 0.0;
		double epsilon = 0.0001;
		
		int nState = 0;
		for (Enumeration<DiseaseState> en = getDiseaseStates().elements();en.hasMoreElements();)
		{
			DiseaseState state = en.nextElement();
			for (int startDay = 0; startDay < day+1; startDay++)
			{
				probSum = probSum + state.getCurrentStateProbability(startDay, day, decade);

				if (probSum > 1.0 + epsilon) 
					Factory.debug("Sum of state probabilities exceeds one  at state " + nState + " " + state.getCode()
					+ " start day " + startDay + " day " + day + " decade " + decade);
			}				
			nState++;
		}
		
		if (probSum < 1.0 - epsilon) Factory.debug("Probability sum is " + probSum + " on day " + day + " decade " + decade);
	}
	
	/**
	 * a row of the Age file looks like [weight,age] = [10,20]
	 * @param decade
	 * @return
	 * @throws Exception
	 */
	public double getProbability(int decade) throws Exception
	{
		Vector<String[]> ages =reader.getData("Age");
		double ageSum = 0.0;
		double prob = 0.0;
		for (int d = 1; d < ages.size(); d++)
		{
			String[] row = ages.get(d);
			int dec = SimUtil.makeInteger(row[1])/10;
			double p = SimUtil.makeReal(row[0]);
			ageSum = ageSum + p;
			if (dec == decade) prob = p;
		}
		
		return (prob/ageSum);
	}


	
	//-----------------------------------------------------------------------------------------------------------------
	//                                                  diagnostics
	//-----------------------------------------------------------------------------------------------------------------
	
	/**
	 * 
	 */
	private void writeCodeHeader()
	{
		String header = "Day";
		for (String code: diseaseStateCodes) header = header + ("," + code);
		header = header + ",Infectious";
		SimUtil.message(header);
	}
	
	/**
	 * 
	 * @param day
	 */
	private void writeStateProbabilities(int day, int decade)
	{
		String row = new Integer(day).toString();
		double infectious = 0.0;
		for (String code: diseaseStateCodes)
		{
			DiseaseState state = getDiseaseState(code);
			double prob = state.getStateProbability(day, decade);
			if (state.isInfectious()) infectious = infectious + prob;
			row = row + "," + neat(prob);
		}
		row = row + "," + neat(infectious);
		SimUtil.message(row);
	}
	
	/**
	 * 
	 * @param d
	 * @return
	 */
	public static String neat(double d)
	{ 
		String neat = "0.0";
		if (Math.abs(d) < 0.001) return neat;
		neat = new Double(d).toString();
		if (neat.length() > 5) neat = neat.substring(0,5);
		return neat;
	}
	
	
	/**
	 * find out how many people never have any meetings
	 */
	private void testHermits() throws Exception
	{
		SimUtil.message("\nChecking for hermits");

		Hashtable<String,String> repeaters = null;
		int hermits = this.getPersons().size();
		double attrition = 1.0;
		for (Enumeration<DayEncounterSet> en = dayEncounterSets.elements();en.hasMoreElements();)
		{
			DayEncounterSet picked = en.nextElement();
			if (repeaters == null) repeaters = picked.getHermits();
			else repeaters = picked.getRepeatHermits(repeaters);
			int nextHermits = repeaters.size();
			attrition = new Double(nextHermits)/new Double(hermits);
			SimUtil.message("Remaining hermits: " + nextHermits + "; attrition: " + neat(attrition));
			hermits = nextHermits;
		}		
	}
	
	/**
	 * writable histogram of group memberships
	 * @return
	 */
	private String groupMembershipList()
	{
		int[] hist = groupMembershipHistogram();
		String line = "";
		for (int i = 0; i < hist.length;i++) line = line + hist[i] + ",";
		return line;
	}
	
	/**
	 * element [N] = the number of people who are members of N groups
	 * @return
	 */
	private int[] groupMembershipHistogram()
	{
		int maxGroups = 25;
		int[] hist = new int[maxGroups];
		
		// for each person, find out how many groups they are a member of
		
		for (Enumeration<String> en = persons.keys();en.hasMoreElements();)
		{
			String pid = en.nextElement();
			int memberships = 0;
			for (Enumeration<EncounterGroup> ep = groups.elements();ep.hasMoreElements();)
			{
				EncounterGroup g = ep.nextElement();
				if (g.getMember(pid) != null) memberships++;
			}
			if (memberships < maxGroups) hist[memberships]++;
		}
		
		return hist;		
	}


}
