package com.openmapping.covid.model;

import java.util.Hashtable;
import java.util.StringTokenizer;

/**
 * representation of a person in the model.
 * 
 * As the simulation goes forward day by day, data are added to each Person instance,  not modified
 */
import java.util.Vector;

import com.openmapping.covid.SimUtil;
import com.openmapping.covid.WeightReader;
import com.openmapping.covid.display.DaySummary;
import com.openmapping.covid.display.Filterable;
import com.openmapping.covid.display.ResultAnalyser;

public class Person extends GenericEntity implements ModelEntity, Filterable {
	
	public Household getHousehold() {return household;}
	private Household household;
	
	private String gender;
	private String firstName;
	private String initial;
	private String surname;
	private String age;  // age in years
	private String profession;
	private String covidApp;
	private String initialStateUntilDay;
	private String secondState;
	
	// disease state codes on day 0,1,... etc; state on day 0 is saved in model data
	public Vector<String> getDiseaseStates() {return diseaseStates;}
	private Vector<String> diseaseStates = new Vector<String>(); // sequence of disease state codes from day 0
	public String getDiseaseState(int day) {return diseaseStates.get(day);}
	public String getCurrentDiseaseState() {return diseaseStates.get(diseaseStates.size() -1);}
	public String getInitialState() {return diseaseStates.get(0);}
	public boolean hasBeenInState(String code) {return SimUtil.inVector(code, diseaseStates);}
	
	private String initialDiseaseState;
	
	// true if has been through state "B"
	public boolean hasBeeninfected() {return hasBeenInfected;}
	private boolean hasBeenInfected = false;
		
	// social states on day 0,1,... etc; 
	// state on day 0 is  F = free. Other states are C = confined and I = isolated
	public Vector<String> getSocialStates() {return socialStates;}
	private Vector<String> socialStates = new Vector<String>(); // sequence of social state codes from day 0
	public void addSocialState(String state) {socialStates.add(state);}
	public String getCurrentSocialState() {return socialStates.get(socialStates.size() -1);}
	
	// the date on which this person will emerge from an isolated or confined state 
	private int setFreeDate = 0;
	
	boolean confineToday = false;
	boolean isolateToday = false;
	
	public int getAge() {return new Integer(age).intValue();}
		
	// record of all transitions between state
	private Vector<StateChange> diseaseTransitions = new Vector<StateChange>();
	
	// when this person is exposed to the virus in a group, store the event
	public Vector<GroupExposureEvent> getGroupExposures() {return groupExposures;}
	private Vector<GroupExposureEvent> groupExposures = new Vector<GroupExposureEvent>();
	
	public GroupExposureEvent getGroupExposure(int day)
	{
		GroupExposureEvent exposure= null;
		for (GroupExposureEvent exp: groupExposures)
			if (day == exp.getDay()) exposure = exp;
		return exposure;
	}
	
	// when this person is exposed to the virus at home, store the event
	public Vector<ExposureEvent> getHomeExposures() {return homeExposures;}
	private Vector<ExposureEvent> homeExposures = new Vector<ExposureEvent>();
	
	// when this person exposes someone else to the virus, store the event
	public Vector<String[]> getExposings() 
	{
		Vector<String[]> res = new Vector<String[]>();
		for (ExposureEvent event: exposings) res.add(event.getSummary());
		return res;
	}
	public void addExposing(ExposureEvent e) {exposings.add(e);}
	private Vector<ExposureEvent> exposings = new Vector<ExposureEvent>();
	
	public ExposureEvent getHomeExposure(int day)
	{
		ExposureEvent exposure= null;
		for (ExposureEvent exp: homeExposures)
			if (day == exp.getDay()) 
				exposure = exp;
		return exposure;
	}
	
	//-----------------------------------------------------------------------------------------
	//                               Constructor and creation
	//-----------------------------------------------------------------------------------------


		
	public Person(WeightReader reader,Factory factory, Household household)
	{
		super(reader,factory);
		this.household = household;
	}

	public void makeRandom() throws Exception {
		if (household != null) household.addPerson(this);
		gender = reader.makeRandomData("Gender")[1];
		if ("male".equalsIgnoreCase(gender)) firstName = reader.makeRandomData("MaleFirstName")[1];
		if ("female".equalsIgnoreCase(gender)) firstName = reader.makeRandomData("FemaleFirstName")[1];
		initial = reader.makeRandomData("Initial")[1];
		surname = reader.makeRandomData("Surname")[1];
		age = makeAge();
		profession = makeProfession();
		covidApp = reader.makeRandomData("CovidApp")[1];
		
		boolean makeRandom = true;
		setInitialDiseaseState(makeRandom,"","","");
		
		socialStates = new Vector<String>();
		socialStates.add("F"); // all people start social state F = free, so no need to record it
		
	}
	
	/**
	 * put in a random profession , consistent with age
	 * @return
	 * @throws Exception
	 */
	private String makeProfession() throws Exception
	{
		String prof = "";
		boolean employed = false;
		
		while (!employed)
		{
			String[] job = reader.makeRandomData("Profession");
			int minAge = new Integer(job[2]).intValue();
			int maxAge = new Integer(job[3]).intValue();
			if ((getAge() > minAge -1 ) && (getAge() < maxAge + 1))
			{
				employed = true;
				prof = job[1];
			}
		}
		return prof;
	}
	
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	private String makeAge() throws Exception
	{
		String decade = reader.makeRandomData("Age")[1]; 
		int decInt = SimUtil.makeInteger(decade);
		int unitInt = (int)(10.0*Math.random());
		return new Integer(decInt + unitInt).toString();
	}

	
	//----------------------------------------------------------------------------------------------------
	//                                          initial disease states
	//----------------------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param day
	 * @throws Exception
	 */
	public void checkDiseaseState(int day) throws Exception
	{
		if (diseaseTransitions.size() < 1) Factory.debug("Person has no state transitions)");
		StateChange lastChange = diseaseTransitions.get(diseaseTransitions.size() - 1);
		lastChange.checkState(day);
	}
	
	
	/**
	 * 
	 * @param day
	 * @param fromCode
	 * @throws Exception
	 */
	private void addRandomTransition(int day, String fromCode) throws Exception
	{
		String nextCode = getNextCode(fromCode);
		if (nextCode.length() == 0) nextCode = fromCode;
		
		addTransition(day,fromCode,nextCode);
	}
	
	/**
	 * 
	 * @param day
	 * @param fromCode
	 * @param toCode
	 * @throws Exception
	 */
	private void addTransition(int day, String fromCode, String toCode) throws Exception
	{
		String duration;
		if (toCode.equals(fromCode)) duration = "1000";
		else duration = getDuration(fromCode,toCode);
		int iDuration = new Integer(duration).intValue();  
		
		// initial states may have onset too early (day too negative); fix it to allow the first transition to happen after day 0
		if ((day + iDuration) < 1) day = 1 - iDuration;
		
		StateChange change = new StateChange(this, fromCode, toCode,day, iDuration);
		diseaseTransitions.add(change);	
	}
	
	
	//-----------------------------------------------------------------------------------------
	//                           events during simulation             
	//-----------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param day
	 * @return
	 */
	public boolean infectable(int day)
	{
		return ("C".equals(diseaseStates.get(day-1)));
	}
	
	/**
	 * 
	 * @param day
	 * @param exposerId
	 * @param groupId
	 */
	public void exposeAtGroup(int day, Person exposer, EncounterGroup group) throws Exception
	{
		GroupExposureEvent event = new GroupExposureEvent(day, exposer, this,group);
		groupExposures.add(event);
		exposer.addExposing(event);
		addExposureTransition(day);
		
	}
	
	/**
	 * 
	 * @param day
	 * @param exposerId
	 */
	public void exposeAtHome(int day, String exposerId) throws Exception
	{
		Person exposer = factory.getPerson(exposerId);
		ExposureEvent event = new HomeExposureEvent(day,exposer, this);
		homeExposures.add(event);
		exposer.addExposing(event);
		addExposureTransition(day);
		
	}
	
	/**
	 * Exposure to the virus only adds a transition to state A (exposed)
	 * if the person was previously in state C (not infected).
	 * For all other disease states, exposure makes no difference
	 */
	private void addExposureTransition(int day) throws Exception
	{
		if ("C".equals(getCurrentDiseaseState()))
		{
			StateChange forced = new StateChange(this,"C","A",day,1);
			diseaseTransitions.add(forced);
		}
	}


	
	//-----------------------------------------------------------------------------------------
	//                               disease states
	//-----------------------------------------------------------------------------------------

	
	/**
	 * find the next state, with the right probability
	 * @param code
	 * @param transitionProbabilities
	 * @return
	 */
	private String getNextCode(String code) throws Exception
	{
		double pSum = 0.0;
		double rand = Math.random();
		boolean found = false;
		String nextCode = "";
		Vector<String[]> transitionProbabilities = factory.getTransitionProbabilities();
		
		for (String[] prob: transitionProbabilities) 
		{
			// use only probabilities for this state and this age
			if ((code.equals(prob[0])) && (fitsAge(age, prob[2])))
			{
				pSum = pSum + new  Double(prob[3]).doubleValue();
				if ((!found) && (pSum > rand))
				{
					found = true;
					nextCode = prob[1];
				}				
			}
		}
		return nextCode;
	}
	
	/**
	 * 
	 * @param age
	 * @param range
	 * @return
	 */
	private boolean fitsAge(String age, String range)
	{
		if ("all".equals(range)) return true;
		
		StringTokenizer st = new StringTokenizer(range,"- ");
		int minAge = new Integer(st.nextToken()).intValue();
		int maxAge = new Integer(st.nextToken()).intValue();
		int ageInt = new Integer(age).intValue();
		return ((ageInt > minAge -1) && (ageInt < maxAge + 1));
	}

	
	/**
	 * find a random duration in days for  a transition between states to happen
	 * @param code
	 * @param nextCode
	 * @param transitionTimes
	 * @return
	 */
	private String getDuration(String code, String nextCode) throws Exception
	{
		String days = null;
		Vector<String[]> transitionTimes = factory.getTransitionTimes();
		
		for (String[] trans: transitionTimes)
		{
			//find a sequence of (days,weight) for the two states
			if ((code.equals(trans[0])) && (nextCode.equals(trans[1])))
			{
				// trans[3] looks like e.g. '5^1 6^1 7^2 8^2 9^1'. convert it into a Vector<double[2]>
				StringTokenizer st = new StringTokenizer(trans[2]);
				Vector<double[]> dayVect = new Vector<double[]>();
				double daySum = 0.0;
				while (st.hasMoreTokens())
				{
					double[] onePair = new double[2]; // days, weight
					StringTokenizer su = new StringTokenizer(st.nextToken(),"^");
					onePair[0] = new Double(su.nextToken()).doubleValue();
					onePair[1] = new Double(su.nextToken()).doubleValue();
					dayVect.add(onePair);
					daySum = daySum + onePair[1]; // sum of weights for all days
				}
				
				// find a random number of days
				double sum = 0.0;
				double rand= Math.random()*daySum;
				boolean found = false;
				for (double[] onePair: dayVect)
				{
					sum = sum + onePair[1];
					if ((sum > rand) && (!found))
					{
						found = true;
						String doubleDays = new Double(onePair[0]).toString();
						StringTokenizer sx = new StringTokenizer(doubleDays,".");
						days = sx.nextToken();
					}
				}
				if (days == null) throw new Exception("Failed to find state transition days from " + trans[3]);
			}
					
		}
		
		if (days == null) throw new Exception("Found no state transition days for states " + code + " to " + nextCode);
		return days;
	}
	
	/**
	 * 
	 * @return first day of infected state
	 */
	public int dayInfectedx()
	{
		int day = -1;
		boolean infected = false;
		for (int d = 0; d < diseaseStates.size(); d++) 
		{
			String state = diseaseStates.get(d);
			if ((!infected) && ("B".equals(state)))
			{
				day = d;
				infected = true;
			}
		}
		return day;
	}
	
	/**
	 * 
	 * @return table of disease states, with the first day in each state
	 */
	public Hashtable<String,Integer> getFirstDayOfState()
	{
		Hashtable<String,Integer> firstDay = new Hashtable<String,Integer>();
		String previousState = "X";
		for (int day = 0; day < diseaseStates.size();day++)
		{
			String state = diseaseStates.get(day);
			if (!previousState.equals(state)) firstDay.put(state,new Integer(day));
			previousState = state;
		}		
		return firstDay;
	}
	
	/**
	 * 
	 * @return the day when someone was infected, and first and last days when they were infectious
	 */
	public int[] daysInfectious()
	{
		String[] infectiousStates = {"E","F","G","H"};
		int[] day = new int[3];
		for (int i = 0; i < 3; i++) day[i] = -1;
		
		for (int d = 0; d < diseaseStates.size(); d++) 
		{
			String diseaseState = diseaseStates.get(d);
			String socialState = socialStates.get(d);
			if ((diseaseState.equals("B")) && (day[0] == -1)) day[0] = d;
			if ((socialState.equals("F")) && (SimUtil.inArray(diseaseState, infectiousStates)))
			{
				if (day[1] == -1) day[1] = d;
				day[2] = d;
			}
		}
		return day;
	}
	



	//---------------------------------------------------------------------------------------------------
	// 									advancing by a day, confinement and isolation
	//---------------------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param day
	 * @throws Exception
	 */
	public void advanceOneDay(int day) throws Exception
	{
		int tomorrow = day + 1;
		StateChange lastChange = diseaseTransitions.get(diseaseTransitions.size() - 1);
		String lastState = diseaseStates.get(diseaseStates.size() - 1);
		String code = lastChange.getFromCode();
		if (!code.equals(lastState)) 
			Factory.debug("Latest transition start state " + code + " should always be the current state, not " + lastState);

		int changeDay = lastChange.getLastDay(); // there was a (+ 1) here
		
		// error; this transition should have already happened
		if (changeDay < tomorrow) 
			Factory.debug("State change should have happened already: day after end of current state " + changeDay + " is less than " + tomorrow);
		
		// this is the day for a change
		if (changeDay == tomorrow)
		{
			String nextCode = lastChange.getToCode();
			addRandomTransition(changeDay,nextCode);
			diseaseStates.add(nextCode);
			if ("B".equals(nextCode)) hasBeenInfected = true;
		}
		
		// no change needed yet
		else if (changeDay > tomorrow)
		{
			diseaseStates.add(code);
		}
		
		// update social state
		String newSocialState = getCurrentSocialState();
		if (confineToday) 
		{
			newSocialState = "C";
			confineToday = false;
		}
		if (isolateToday) 
		{
			newSocialState = "I";
			isolateToday = false;
		}
		if (day == setFreeDate)
		{
			newSocialState = "F";
			setFreeDate = 0;
		}
		addSocialState(newSocialState);
	}
	
	/**
	 * isolate this person for a period
	 * @param duration
	 */
	public void isolate(int duration)
	{
		isolateToday = true;
		setFreeDate = socialStates.size() + duration;
	}

	/**
	 * confine this person to home for a period
	 * @param duration
	 */
	
	public void confine(int duration)
	{
		confineToday = true;
		setFreeDate = socialStates.size() + duration;
	}
	
	/**
	 * 
	 * @return
	 */
	public String diseaseHistory()
	{
		String history = "";
		for (String state:diseaseStates) history = history + state;
		return history;
	}

	
	/**
	 * 
	 * @return
	 */
	public String socialHistory()
	{
		String history = "";
		for (String state:socialStates) history = history + state;
		return history;
	}

	
	//-----------------------------------------------------------------------------------------
	//                               input/output (day 0)
	//-----------------------------------------------------------------------------------------

	/**
	 * 
	 */
	public void fromData(String[] row) throws Exception
	{
		id = row[0];
		household = factory.getHousehold(row[1]);
		household.addPerson(this);
		gender = row[2];
		firstName = row[3];
		initial = row[4];
		surname = row[5];
		age = row[6];
		profession = row[7];
		covidApp = row[8];
		initialDiseaseState = row[9];
		secondState = row[10];
		initialStateUntilDay = row[11];
		
		boolean makeRandom = false;
		setInitialDiseaseState(makeRandom,initialDiseaseState,secondState,initialStateUntilDay);
		
		socialStates = new Vector<String>();
		socialStates.add("F"); // all people start social state F = free, so no need to record it

	}
	
	
	/**
	 * set the disease state for day 0, and the first transition from that state
	 * When a person in made random, the two arguments are empty
	 * When a person is read from a data file, they are not empty
	 * @throws Exception
	 */
	private void setInitialDiseaseState(boolean makeRandom, String firstCode, String secondCode, String firstEndDay) throws Exception
	{
		diseaseStates = new Vector<String>();
		diseaseTransitions = new Vector<StateChange>();
		
		if (makeRandom)
		{
			String[] firstStateData = reader.makeRandomData("InitialStates");
			String firstStateName  = firstStateData[1];
			String firstStateCode = factory.getDiseaseCodeFromName(firstStateName);
			diseaseStates.add(firstStateCode);
			
			DiseaseState firstState = factory.getDiseaseState(firstStateCode);
			StateChange firstChange = firstState.randomChange(this, 0);
			diseaseTransitions.add(firstChange);
			
			initialStateUntilDay = new Integer(firstChange.getDuration()).toString();
			secondState = firstChange.getToCode();
		}
		
		
		else if (!makeRandom) try
		{
			diseaseStates.add(firstCode);
			int iFirst = new Integer(firstEndDay).intValue();
			diseaseTransitions.add(new StateChange(this,firstCode,secondCode,0,iFirst));
		}
		catch (Exception ex) {Factory.debug(ex.getMessage());}
		
		checkDiseaseState(0);
				
	}
	
	/**
	 * set this person back to the state before a simulation run
	 */
	public void refresh() throws Exception
	{
		diseaseStates = new Vector<String>(); // sequence of disease state codes from day 0
		hasBeenInfected = false;
		diseaseTransitions = new Vector<StateChange>();

		socialStates = new Vector<String>(); // sequence of social state codes from day 0
		socialStates.add("F"); // all people start social state F = free, so no need to record it

		groupExposures = new Vector<GroupExposureEvent>();
		homeExposures = new Vector<ExposureEvent>();
		exposings = new Vector<ExposureEvent>();

		setFreeDate = 0;		
		confineToday = false;
		isolateToday = false;
		boolean makeRandom = false;
		setInitialDiseaseState(makeRandom,initialDiseaseState,secondState,initialStateUntilDay);
		
	}

	
	public String[] headerRow() {return header;}
	private String[] header = {"id","Household","Gender","First name","Initial","Surname","Age","Profession","COVID app","Start state","Second state","Start state last day"};


	public String[] dataRow() {
		String[] row = new String[12];
		row[0] = getId();
		row[1] = household.getId();
		row[2] = gender;
		row[3] = firstName;
		row[4] = initial;
		row[5] = surname;
		row[6] = age;
		row[7] = profession;
		row[8] = covidApp;
		row[9] = diseaseStates.get(0);
		row[10] = secondState;
		row[11] = initialStateUntilDay;
		return row;
	}
	
	//----------------------------------------------------------------------------------------------------------
	//                                            Filterable interface
	//----------------------------------------------------------------------------------------------------------

	public String getFilterKey() {
		return getId();
	}

	@Override
	public String getFilterValue(DaySummary daySummary,int filterType) throws Exception
	{
		String result = "";
		
		// filter by name of disease state, in the daySummary for the scenario, run, and day
		if (filterType == ResultAnalyser.DISEASE_STATE)
		{
			result = daySummary.getDiseaseStateName(getId());
		}
		
		// filter by name of social state, in the daySummary for the scenario, run, and day
		// the combo boxes have menu items like "S:isolated" rather than "isolated"
		else if (filterType == ResultAnalyser.SOCIAL_STATE)
		{
			result = "S:" + daySummary.getSocialStateName(getId());
		}
		
		else if (filterType == ResultAnalyser.AGE_RANGE)
		{
			result = new Integer(getAge()).toString();
		}
		
		else if (filterType == ResultAnalyser.REGION)
		{
			result = getHousehold().getRegion();
		}
		
		else throw new Exception("Class Person does not support filtering by type " + filterType);
				
		return result;		
	}

}
