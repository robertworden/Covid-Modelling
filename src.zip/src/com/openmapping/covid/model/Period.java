package com.openmapping.covid.model;

public class Period {
	
	public int getScenarioIndex() { return scenarioIndex;}
	private int scenarioIndex;	
	
	public int getPeriodIndex() { return periodIndex;}
	private int periodIndex;	
	
	public int getStartDay() { return startDay;}
	private int startDay;
	
	public int getEndDay() { return endDay;}
	private int endDay;

	public String getLabel() { return label;}
	private String label;
	
	public Period(String[] periodData) throws Exception
	{
		try
		{
			scenarioIndex = new Integer(periodData[0]).intValue() - 1; // store in internal convention 0...N-1
			periodIndex = new Integer(periodData[1]).intValue() - 1;// store in internal convention 0..N-1
			startDay = new Integer(periodData[2]).intValue();
			endDay = new Integer(periodData[3]).intValue();
		}
		catch (Exception ex) { throw new Exception("Integers required for period index and end day");}
		label = periodData[4];
	}

}
