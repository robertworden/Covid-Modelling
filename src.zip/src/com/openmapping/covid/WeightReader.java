package com.openmapping.covid;

import java.io.File;
import java.io.FileInputStream;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

/**
 * reads the parameters of various probability distributions from csv files,
 * which typically define weights in the first column (weights are normalised to probabilities)
 * and generates random rows according to those probability distributions.
 *  
 * @author robert
 *
 */

public class WeightReader {
	
	public static String[] subFolderNames = {"general","population","person","disease"};
	
	private String distributionFolder;
	
	// csv data files
	private Hashtable<String,Vector<String[]>> csvRows = new Hashtable<String,Vector<String[]>>();
	
	// txt explanation files
	private Hashtable<String,Vector<String>> explanationRows = new Hashtable<String,Vector<String>>();
	
	public WeightReader(String distributionFolder) throws Exception
	{
		this.distributionFolder = distributionFolder;
		readDistributions(distributionFolder);
	}
	
	/**
	 * 
	 */
	public void readDistributions(String distributionFolder) throws Exception
	{
		File folder = new File(distributionFolder);
		File[] subFolders = folder.listFiles();
		if (subFolders == null) throw new Exception("There is no 'distributions' folder of model data at path " + distributionFolder);
		
		int foldersFound= 0;
		for (File subFolder:subFolders) if (SimUtil.inArray(subFolder.getName(), subFolderNames))
		{
			foldersFound++;
			File[] csvFiles = subFolder.listFiles();
			
			for (File csvFile: csvFiles)
			{
				String fileName = csvFile.getName();
				StringTokenizer st = new StringTokenizer(fileName,".");
				String name = st.nextToken();
				if (st.hasMoreTokens())
				{
					String ext  = st.nextToken();
					FileInputStream stream = new FileInputStream(csvFile);
					
					// csv data file
					if ("csv".equals(ext)) try
					{
						Vector<String[]> rows = SimUtil.getCSVRows(stream);
						csvRows.put(name, rows);
					}
					catch (Exception ex) {SimUtil.message("Failed to read csv file " + fileName);}
					
					// matching text explanation file
					else if ("txt".equals(ext)) try
					{
						Vector<String> lines = SimUtil.getTextLines(stream);
						explanationRows.put(name, lines);
					}
					catch (Exception ex) {SimUtil.message("Failed to read text explanation file " + fileName);}
				}
			}
		}
		
		if (foldersFound != 4) throw new Exception("The 'distributions' folder should have four sub-folders of simulation data: "
				+ "'general','population','person' and 'disease'");

		
		cMain.message("Read " + csvRows.size() + " distribution files.");
	}
	
	/**
	 * 
	 * @param folderName
	 * @return
	 */
	public String[] getcsvFileNames(String folderName)
	{
		File folder = new File(distributionFolder);
		File[] subFolders = folder.listFiles();
		String[] name = null;
		
		for (File subFolder:subFolders) if (subFolder.getName().equals(folderName))
		{
			File[] dataFiles = subFolder.listFiles();
			Vector<String> nameList = new Vector<String>();
			for (int f = 0; f < dataFiles.length; f++)
			{
				String fullName = dataFiles[f].getName();
				if (fullName.endsWith(".csv")) nameList.add(fullName.substring(0,fullName.length() - 4));
			}
			name = new String[nameList.size()];
			for (int i = 0; i < nameList.size(); i++)
				name[i] = nameList.get(i);
		}
		return name;
	}
	
	/**
	 * 
	 * @param dataName
	 * @return text explanation of the data file, or null if there is none
	 */
	public Vector<String> getExplanation(String dataName)
	{
		return explanationRows.get(dataName);
	}
	
	/**
	 * 
	 * @param dataName
	 * @return
	 * @throws Exception
	 */
	public Vector<String[]> getData(String dataName) throws Exception
	{
		Vector<String[]> data = csvRows.get(dataName);
		if (data == null) throw new Exception("No data file '" + dataName + ".csv'");
		return data;
	}
	
	/**
	 * 
	 * @param stateCode
	 * @return
	 * @throws Exception
	 */
	public boolean infectiousState(String stateCode) throws Exception
	{
		return SimUtil.inVector(stateCode, getInfectiousStates());
	}
	
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public Vector<String> getInfectiousStates() throws Exception
	{
		Vector<String> infect = new Vector<String>();
		Vector<String[]> states = getData("States");
		for (String[] state: states) if ("1".equals(state[2])) infect.add(state[0]);
		return infect;
	}
	
	/**
	 * 
	 * @param parameter
	 * @return
	 * @throws Exception
	 */
	public String getParameterValue(String parameter) throws Exception
	{
		String val = null;
		Vector<String[]> params = csvRows.get("Parameters");
		if (params == null) throw  new Exception("No parameters file");
		checkParameterFile(params);
		for (int p = 0; p < params.size(); p++)
		{
			String[] param = params.get(p);
			if (param[0].equalsIgnoreCase(parameter)) val = param[1];
		}
		if (val == null) throw new Exception("No parameter " + parameter);
		return val;
	}
	
	/**
	 * 
	 * @param params
	 * @throws Exception
	 */
	private void checkParameterFile(Vector<String[]> params) throws Exception
	{
		String[] intParam = {"days","runs","households","scenario","cutoff"};
		String[]realParam = {"infect_probability"};
		for (String[] pLine: params) try
		{
			if (SimUtil.inArray(pLine[0], intParam)) SimUtil.makeInteger(pLine[1]);
			if (SimUtil.inArray(pLine[0], realParam)) SimUtil.makeReal(pLine[1]);
			
		}
		catch (Exception ex) {throw new Exception("Parameter file error: " + ex.getMessage());}
	}
	
	/**
	 * generate a random row of a given data type (csv file name)
	 * with probability defined by the weights in the first column of the file,
	 * normalised to 1.
	 * 
	 * @param dataType
	 * @return
	 */
	public String[] makeRandomData(String dataType) throws Exception
	{
		Vector<String[]> rows = csvRows.get(dataType);
		if (rows == null) throw new Exception("No file '" + dataType + ".csv' to define randomised data of type " + dataType);
		String[] chosen = null;
		
		double sum = 0.0;
		String val = null;
		try
		{
			for (int r = 1; r < rows.size(); r++)
			{
				val = rows.get(r)[0];
				if (val.length() > 0) sum = sum + new Double(val).doubleValue();
			}			
		}
		catch (Exception ex) {ex.printStackTrace();throw new Exception("Invalid weight in file " + dataType + " :" + val);}
		
		// random number between 0 and 1
		double rand = Math.random();
		boolean exceeded = false;
		double partial = 0.0; // partial will grow up to 1
		for (int r = 1; r < rows.size(); r++)
		{
			val = rows.get(r)[0];
			if (val.length() > 0) partial = partial + new Double(val).doubleValue()/sum;
			if ((partial > rand) && !exceeded)
			{
				exceeded = true;
				chosen = rows.get(r);
			}
		}			
		
		return chosen;
	}
	
	/**
	 * 
	 * @param name
	 * @return
	 */
	public String covidStateCodeFromName(String name) throws Exception
	{
		Vector<String[]> codeNames = csvRows.get("States");
		if (codeNames == null) throw new Exception("No disease states table");
		String code = null;
		for (String[] pair: codeNames) 
			if (name.equals(pair[1])) code = pair[0];
		if (code == null) throw new Exception("No disease state name '" + name + "'");
		return code;
		
	}
	
	/**
	 * 
	 * @param name
	 * @return
	 */
	public String covidStateNameFromCode(String code) throws Exception
	{
		Vector<String[]> codeNames = csvRows.get("States");
		if (codeNames == null) throw new Exception("No disease states table");
		String name = null;
		for (String[] pair: codeNames) 
			if (code.equals(pair[0])) name = pair[1];
		if (code == null) throw new Exception("No disease state code '" + code + "'");
		return name;
		
	}
	
	private String[][] socialState = {{"F","free"},{"C","confined"},{"I","isolated"}};
	
	/**
	 * 
	 * @param code
	 * @return
	 * @throws Exception
	 */
	public String socialStateNameFromCode(String code) throws Exception
	{
		String name = "";
		for (int c = 0; c < socialState.length;c++)
			if (socialState[c][0].equals(code)) name = socialState[c][1];
		if (name.length() == 0) throw new Exception("No social state code " + code);
		return name;
	}
	
	

}
