package com.openmapping.covid;

import java.io.File;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JFileChooser;

import com.openmapping.covid.captureData.MapImporter;
import com.openmapping.covid.display.LinearPlot;
import com.openmapping.covid.display.LogPlot;
import com.openmapping.covid.display.MapCanvas;
import com.openmapping.covid.display.MapPlot;
import com.openmapping.covid.display.ResultAnalyser;
import com.openmapping.covid.display.ViewFrame;
import com.openmapping.covid.model.Factory;
import com.openmapping.covid.model.ModelRunner;

public class cMain {
	
	public ViewFrame getFrame() {return frame;}
	private ViewFrame frame;
	
	public Factory getFactory() {return factory;}
	private Factory factory;
	
	public WeightReader getReader() {return reader;}
	private WeightReader reader;
	
	public ResultAnalyser getAnalyser() {return analyser;}
	private ResultAnalyser analyser;
	
	public ModelRunner getRunner() {return runner;}
	private ModelRunner runner;
	
	public MapImporter getMapImporter() {return importer;}
	public MapImporter importer;
	
	
	public cMain(String rootFolderPath)
	{
		if (rootFolderPath == null)
		{
			JFileChooser rootFolderChooser = new JFileChooser();
			rootFolderChooser.setDialogTitle("Choose folder for model data");
			rootFolderChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				    int returnVal = rootFolderChooser.showOpenDialog(null);
				    if (returnVal == JFileChooser.APPROVE_OPTION) 
				    {
				    	File folder = rootFolderChooser.getSelectedFile();
				    	rootFolderPath = folder.getPath();
				    }
		}
		
		
		boolean startupOK = true;

		if (rootFolderPath != null) try
		{
			String distributionFolder = rootFolderPath + "/distributions/";
			SimUtil.message("Chosen root folder: " + rootFolderPath);
		    try
		    {
			    // set up other central classes, reading lots of data files
			    reader = new WeightReader(distributionFolder); // for reading data files 
				factory = new Factory(reader,rootFolderPath); // for making model objects
				runner  = new ModelRunner(factory,reader, this); // for running the simulation model
				analyser = new ResultAnalyser(factory, reader, runner, frame); // for analysing simulation results, to show them
				importer = new MapImporter(this);
		    }
		    catch (Exception ex)
		    {
		    	// show an empty view frame with no menus just to show an error message
		    	reader = null;
		    	factory = null;
		    	analyser = null;
				frame = new ViewFrame(this);
			    frame.showErrorMessage("Startup failure: " + ex.getMessage());
			    ex.printStackTrace();
			    frame.validate();
			    frame.setVisible(true);
			    startupOK= false;
		    }
			
		    // show the viewing frame properly, using the data
		    if (startupOK)
		    {
				frame = new ViewFrame(this); // gets reader, factory , and analyser from cMain
			    frame.validate();
			    frame.setVisible(true);
			    analyser.setFrame(frame);
		    }
			

		}
		catch (Exception ex) 
		{
			ex.printStackTrace();
			try {frame = new ViewFrame(this);} 
			catch (Exception ey) {SimUtil.message("Exception in startup: " + ey.getMessage());ey.printStackTrace();}

			frame.showErrorMessage(ex.getMessage());
		    frame.validate();
		    frame.setVisible(true);

		    ex.printStackTrace();
		}
		if (rootFolderPath == null) SimUtil.message("Stopped: no root folder chosen for model data.");
	}

	  
	  //--------------------------------------------------------------------------------------------------
	  //                                              Actions
	  //--------------------------------------------------------------------------------------------------

	/*
	protected String[] buttonLabel = {"Make Model","Read Model","Run Model","Add Plot","Remove Plot",
			"Add Plot","Remove Plot",
			"","","","",""};
			*/
		 
		 public void buttonAction(int tab, int action)
		 {
			 String preface = "Error ";
			 //SimUtil.message("Tab " + tab + " Button " + action);
			 try
			 {
				 //control tab and disease state display
				 if (tab == 0)
				 {
					 LogPlot plot = (LogPlot)frame.getPlot(tab,0);

					 // generate and write out a model
					 if (action == 0)
					 {
						    preface = preface + "making random demographic model: ";
							factory.makeModel();
							factory.writeModel();
					 }
					 
					 // read in a model
					 else if (action == 1)
					 {
						    preface = preface + "reading demographic model: ";
						    factory.readModel();
							message("Model read in");
					 }
					 
					 // run a model forward in time
					 else if (action == 2)
					 {
						    preface = preface + "running simulation model: ";
						 runner.runModel();
						 analyser.setSummaries();
						 message("Run completed");
					 }
					 
					 // add a plot to the disease state plot
					 else if (action == 3)
					 {
						    preface = preface + "adding graph of disease states: ";
						 Vector<double[]> values = analyser.getLogNumbers(tab,ResultAnalyser.STATE_PLOT);
						 plot.addPlot(tab,action,values,analyser.getLabel(tab,action),analyser.getColour(tab),analyser.getStyle(tab));
					 }
					 
					 // remove a plot from the disease state plot
					 else if (action == 4)
					 {
						 plot.removePlot();
					 }
					 
					 plot.repaint();
					 frame.validate();
				 }
				 
				 // event display tab
				 else if (tab == 1)
				 {
					 LogPlot plot = (LogPlot)frame.getPlot(tab,0);

					 // add a graph to the exposure event plot
					 if (action == 0)
					 {
						    preface = preface + "adding graph of disease exposure events: ";
						 Vector<double[]> values = analyser.getLogNumbers(tab,ResultAnalyser.EVENT_PLOT);
						 plot.addPlot(tab,action,values,analyser.getLabel(tab,action),analyser.getColour(tab),analyser.getStyle(tab));
					 }
					 
					 // remove the top graph from the exposure event plot
					 else if (action == 1)
					 {
						 plot.removePlot();
					 }
					 
					 plot.repaint();
					 frame.validate();
					
				 }
				 
				 // disease model tab
				 else if (tab == 2)
				 {
					 LinearPlot plot = (LinearPlot)frame.getPlot(tab,0);

					 // add a graph of calculated results
					 if (action == 0)
					 {
						    preface = preface + "adding graph of calculated results: ";
						 Vector<double[]> values = analyser.getRealNumbers(tab,ResultAnalyser.COMPUTE);
						 plot.addPlot(tab,action,values,analyser.getLabel(tab,action),analyser.getColour(tab),analyser.getStyle(tab));
					 }
					 
					 // add a graph of simulation results
					 else if (action == 1)
					 {
						    preface = preface + "adding graph of simulated results: ";
						 Vector<double[]> values = analyser.getRealNumbers(tab,ResultAnalyser.SIMULATE);
						 plot.addPlot(tab,action,values,analyser.getLabel(tab,action),analyser.getColour(tab),analyser.getStyle(tab));
					 }
					 
					 // remove the top graph
					 else if (action == 2)
					 {
						 plot.removePlot();
					 }
					 
					 plot.repaint();
					 frame.validate();
					 
				 }
				 
				 // map view
				 else if (tab == 5)
				 {
					 MapPlot mapPlot = (MapPlot)frame.getPlot(tab,0);
					 String label = analyser.getLabel(tab,action);
					 int day = ((Integer)(frame.getDaySpinner().getValue())).intValue();

					 // show people
					 if (action == 0)
					 {
						    preface = preface + "mapping disease states: ";
						 Vector<double[]> coords = analyser.getCoordinates(tab,ResultAnalyser.SHOW_PEOPLE);
						 label = label + ", day " + day;
						 mapPlot.addPlot(tab,action,coords,label,analyser.getColour(tab),analyser.getStyle(tab));
					 }

					 // show venues
					 else if (action == 1)
					 {
						    preface = preface + "mapping meeting places: ";
						 Vector<double[]> coords = analyser.getCoordinates(tab,ResultAnalyser.SHOW_VENUES);
						 mapPlot.addPlot(tab,action,coords,label,analyser.getColour(tab),analyser.getStyle(tab));
					 }

					 // show events
					 else if (action == 2)
					 {
						    preface = preface + "mapping disease events: ";
						 Vector<double[]> coords = analyser.getCoordinates(tab,ResultAnalyser.SHOW_EVENTS);
						 mapPlot.addPlot(tab,action,coords,label,analyser.getColour(tab),analyser.getStyle(tab));
					 }

					 // remove symbols
					 else if (action == 3)
					 {
						 mapPlot.removePlot();
					 }

					 // not currently used
					 else if (action == 4)
					 {
					 }
					 
					 mapPlot.repaint();
					 frame.validate();

					 
				 } 
				 
				 // map capture
				 else if (tab == 6)
				 {
					 MapCanvas capture = frame.getCaptureMapCanvas();

					 // read map file and show it all in the view
					 if (action == 0)
					 {
						    preface = preface + "capturing map data: ";
						 importer.chooseImportFile(frame);
						 capture.setNormalPolygons(importer.getNormalPolygons());
						 
						 capture.repaint();
						 frame.validate();
					 }

					 // define polygons
					 if (action == 1)
					 {
						 
					 }

					 // export polygon file
					 if (action == 2)
					 {
						    preface = preface + "exporting map data: ";
						 importer.exportRegionData(capture.getPanZoomSetting(),frame);
					 }
					 
					 
				 }

			 }
			 catch (Exception ex) {ex.printStackTrace();frame.showErrorMessage(preface + ex.getMessage());}
		 }
		 
		 
		 /**
		  * 
		  * @param comboIndex
		  * @param selected
		  */
		 public void comboAction(int tab,int comboIndex, int comboType, Object selected, int selectedIndex)
		 {
			 String preface = "Error occurred when making selection: ";
			 try
			 {
				 if (comboType == ViewFrame.TOP_ROW) analyser.setLabelPart(tab, comboIndex, (String)selected);

				 // control and person states plots
				 if (tab == 0)
				 {
					 
					 // choose scenario
					 if (comboIndex == 0)
					 {
						analyser.setScenario(tab,selectedIndex);
					 }
					 
					 // choose disease state; setting the label sets the disease code
					 else if (comboIndex == 1)
					 {
					 }

					 // choose age range to graph
					 else if (comboIndex == 2)
					 {
						analyser.setAgeRangeCriterion((String)selected);
					 }

					 // choose colour of disease state graph
					 else if (comboIndex == 3)
					 {
						analyser.setColour(tab,selectedIndex);
					 }

					 // choose style of disease state graph
					 else if (comboIndex == 4)
					 {
						analyser.setStyle(tab,(String)selected);
					 }
				 }
				 
				 // event plots
				 else if  (tab == 1)
				 {
					 
					 // choose scenario
					 if (comboIndex == 0)
					 {
						analyser.setScenario(tab,selectedIndex);
					 }
					 
					 // choose venue type of exposure event graph
					 else if (comboIndex == 1)
					 {
						analyser.setVenueName((String)selected);
					 }

					 // choose region of exposure event graph
					 else if (comboIndex == 2)
					 {
					 }

					 // choose colour of exposure event graph
					 else if (comboIndex == 3)
					 {
							analyser.setColour(tab,selectedIndex);
					 }

					 // choose style of exposure event graph
					 else if (comboIndex == 4)
					 {
							analyser.setStyle(tab,(String)selected);
					 }
				 }
				 
				 // disease model day plots
				 else if  (tab == 2)
				 {
					 // choice of scenario and period
					 if (comboIndex == 0)
					 {
						 StringTokenizer st = new StringTokenizer((String)selected,",");
						 String scenarioName = st.nextToken();
						 String periodName= st.nextToken();
						 
					     int scenario = factory.getScenarioIndex(scenarioName);
						 analyser.setScenario(tab,scenario);
					     analyser.setPeriodIndex(tab, factory.getNamedPeriod(scenario, periodName).getPeriodIndex());						 						 
					 }

					 // choice of disease state; setting the label sets the disease state
					 if (comboIndex == 1)
					 {
					 }

					 // choice of venue
					 if (comboIndex == 2)
					 {
							analyser.setVenueName((String)selected);
					 }

					 // choice of bar colour
					 if (comboIndex == 3)
					 {
							analyser.setColour(tab,selectedIndex);
					 }

					 // choice of bar style
					 if (comboIndex == 4)
					 {
							analyser.setStyle(tab,(String)selected);
					 }
					 
				 }

				 // simulation data model tables
				 else if  (tab == 3)
				 {
					 // choice of folder; change the files available
					 if (comboIndex == 0)
					 {
						 String folderName = (String)selected;
						 String[] fileNames = reader.getcsvFileNames(folderName);
						 JComboBox<String> fileChoice = frame.getDropDown()[tab][1];
						 fileChoice.removeAllItems();
						 for (String fileName: fileNames) fileChoice.addItem(fileName);
					 }
					 
					 //choice of file within folder
					 else if (comboIndex == 1)
					 {
						 if (selected != null)
						 {
							 String dataName = (String)selected;
							 Vector<String[]> tableData = reader.getData(dataName);
							 Vector<String>  explanation = reader.getExplanation(dataName);
							 frame.getPersonTable().showTable(tableData);
							 frame.setExplanation(explanation,tab);
						 }
					 }
				 }

				 // demographic model tables
				 else if  (tab == 4)
				 {
					 if (comboIndex == 0)
					 {
						 String selectedFileName = (String)selected;
						 Vector<String[]> tableData = factory.readEntity(selectedFileName);
						 Vector<String>  explanation = factory.readExplanation(selectedFileName);
						 if (tableData != null)
						 {
							 frame.getDemographicTable().showTable(tableData);
							 frame.setExplanation(explanation,tab);
						 }
					 }
				 }
				 
				 // map view
				 else if  (tab == 5)
				 {
					 // set scenario
					 if (comboIndex == 0)
					 {
							analyser.setScenario(tab,selectedIndex);
					 }
					 
					 // set disease state - set as a label part
					 else if (comboIndex == 1)
					 {
						 
					 }
					 
					 // set venue type - set as a label part
					 else if (comboIndex == 2)
					 {
						 
					 }
					 
					 // choice of bar colour
					 if (comboIndex == 3)
					 {
							analyser.setColour(tab,selectedIndex);
					 }

					 // choice of symbol
					 if (comboIndex == 4)
					 {
							analyser.setStyle(tab,(String)selected);
					 }
					 
				 }
				 
			 }
			 catch (Exception ex) {ex.printStackTrace();frame.showErrorMessage(preface + ex.getMessage());}
			 
		 }


	  //------------------------------------------------------------------------------------------------
	  //                              main method
	  //------------------------------------------------------------------------------------------------

	  public static void main(String[] args) {
		  try
		  {
			  String rootFolder = null;
			  if (args.length > 0) rootFolder = args[0];
			  new cMain(rootFolder);
		  }
		  catch (Exception ex) {message("Exception in simulator: " + ex.getMessage());ex.printStackTrace();}
	  }

	  public static void message(String s) {System.out.println(s);}
}
