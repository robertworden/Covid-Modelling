package com.openmapping.covid.display;

import java.awt.Color;
import java.awt.Graphics;

import com.openmapping.covid.model.Period;

public class LogPlot extends Plot{
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// log plots of numbers versus days - numbers of pixels
	private int logDecade = 90;  //  per decade on vertical axis
	
	private int periodBarWidth = 4;
	
	int periodLabelOffLine = 3;
	

	protected int dayInterval = 10; //  per day on horizontal axis

	

    //-------------------------------------------------------------------------------------------------
	//                                       Constructor
	//-------------------------------------------------------------------------------------------------
	
	
	public LogPlot(int left, int top, int x, int y,ViewFrame frame)
	{
		super(left,top,x,y,frame);
	}

	
	  /**
	   * 
	   * @param g
	   */
	  protected void drawVerticalAxisTicks(Graphics g, int logDecade)
	  {
		  String[] decadeLabel = {"   1","  10"," 100","1000","10^4","10^5","10^7","10^8"};
		  // number of decades you can fit in
		  int decades = (yBottom - 2*scaleInset)/logDecade;
		  
		  for (int i = 0; i < decades;i++)
		  {
			  int vertical = yBottom - scaleInset - i*logDecade;
			  g.setColor(Color.BLACK);
			  
			  // label power of 10 every decade
			  boldFont(g);
			  g.drawChars(decadeLabel[i].toCharArray(), 0, decadeLabel[i].length(), 5, vertical);
			  normalFont(g);
			  // long tick every decade
			  g.drawLine(scaleInset - longTick, vertical, scaleInset, vertical);
			  
			  // horizontal guide lines every decade
			  if (i > 0) 
			  {
				  g.setColor(Color.LIGHT_GRAY);
				  g.drawLine(scaleInset, vertical, xRight - scaleInset, vertical);
				  g.setColor(Color.BLACK);
			  }
			  
			  // short ticks for 2...9 times a power of 10
			  for (int j = 1; j < 10;j++)
			  {
				  double dj = new Double(j).doubleValue();
				  double height = vertical - (Math.log10(dj))*logDecade;
				  int h = (int)height;
				  g.drawLine(scaleInset - shortTick, h, scaleInset, h);
			  }
		  }
	  }

	  
	  
	  
	  /**
	   * 
	   * @param g
	   */
	  protected void drawPeriodMarkers(Graphics g)
	  {
		  if (factory != null)
		  {
			  for (int s = 0; s < factory.nScenarios();s++)
			  {
				  int startDay = 0;
				  int yScen = 30*(s + 2);
				  String scenarioLabel = "s" + new Integer(s+1).toString() + ": " + factory.getScenarioName(s);
				  int scenarioLabelStart = 0;

				  for(int n = 0; n < factory.nPeriods(s); n++)
				  {
					  Period p = factory.getPeriod(s, n);
					  int endDay = p.getEndDay();

					  // horizontal period bar and period end ticks
					  g.setColor(Color.LIGHT_GRAY);
					  int xStart = scaleInset + startDay*dayInterval;
					  int xEnd = scaleInset + endDay*dayInterval;
					  for (int t = 0; t < periodBarWidth; t++)
					  {
						  g.drawLine(xStart+t, yScen - longTick, xStart+t, yScen);
						  g.drawLine(xEnd - periodBarWidth + t, yScen - longTick, xEnd - periodBarWidth + t, yScen);
						  g.drawLine(xStart, yScen + t, xEnd, yScen + t);
						  
					  }

					  // period label
					  int labelStart = scaleInset + dayInterval*(startDay + endDay)/2 - 40;
					  scenarioLabelStart = scaleInset + dayInterval*endDay + 10;
					  g.setColor(Color.BLACK);
					  String label = p.getLabel();
					  bigBoldFont(g);
					  g.drawChars(label.toCharArray(), 0, label.length(), labelStart, yScen - periodLabelOffLine);
					  normalFont(g);
					  startDay = endDay;
				  }
				  
				  // draw scenario label to the right of the period bar
				  bigBoldFont(g);
				  g.drawChars(scenarioLabel.toCharArray(), 0, scenarioLabel.length(), scenarioLabelStart, yScen - periodLabelOffLine);
				  normalFont(g);
			  }
		  }
	  }
	  
	  /**
	   * 
	   * @param g
	   */
	  protected void drawPopulationBar(Graphics g)
	  {	
		  if (factory != null)
		  {
			  int population = factory.getPersons().size();
			  if (population > 0)
			  {
				  int y = yBottom - scaleInset - (int)(logDecade*Math.log10(new Double(population).doubleValue()));
				  int xMin = scaleInset;
				  g.setColor(Color.ORANGE);

				  // go over all scenarios and periods to find the latest end day
				  int maxEndDay = 0;
				  for (int s = 0; s < factory.nScenarios();s++)
				  {
					  for(int n = 0; n < factory.nPeriods(s); n++)
					  {
						  Period p = factory.getPeriod(s, n);
						  int endDay = p.getEndDay();
						  if (endDay > maxEndDay) maxEndDay = endDay;
					  }
				  }
				  
				  int xMax = xMin + dayInterval*maxEndDay;
				  for (int t = 0; t < 4; t++) g.drawLine(xMin, y- t, xMax, y - t);

				  // draw scenario label to the right of the period bar
				  String popLabel = "Population " + new Integer(population).toString();
				  int popLabelStart = scaleInset + dayInterval*maxEndDay + 10;
				  g.setColor(Color.BLACK);
				  bigBoldFont(g);
				  g.drawChars(popLabel.toCharArray(), 0, popLabel.length(), popLabelStart, y - periodLabelOffLine);
				  normalFont(g);
			  }
		  }
	  }
  

	@Override
	int verticalTick() {
		return logDecade;
	}


	@Override
	int dayInterval() {
		return dayInterval;
	}


	@Override
	protected int logDecade() {
		return logDecade;
	}



}
