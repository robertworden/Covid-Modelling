package com.openmapping.covid.display;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Polygon;
import java.util.Vector;

import com.openmapping.covid.model.Region;

public class MapPlot extends Plot{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int mapScale;
	
	private int legendArea;
	
	private boolean drawMap;
	
	private Vector<String[]> mapData;
		
	public MapPlot(int left, int top, int x, int y,int legendArea, ViewFrame frame, boolean drawMap)
	{
		super(left,top,x,y,frame);
		
		this.legendArea = legendArea;
		this.drawMap = drawMap;

		mapScale = x/100;

	}
	
	/**
	 *   
	 */
	protected void drawFrame(Graphics g) throws Exception
	  {
		  super.drawFrame(g);
		  
		  if (drawMap)
		  {
			  // draw the regions a second time with no fill, to make the boundaries clear and thick
			  if  (factory != null) 
			  {
				  for (Region region: factory.getRegions())
						drawRegion(g,region,true,false);
				  for (Region region: factory.getRegions())
						drawRegion(g,region,false,true);
			  }
			  
			  // make a white strip over the bottom of the map, for captions
			  g.setColor(Color.WHITE);
			  g.fillRect(0, yBottom - 40, xRight, 40);
			  g.setColor(Color.BLACK);
			  g.drawLine(0, yBottom - 40, xRight, yBottom -40);
			  			
			  drawAllPoints(g);
		  }
		  

	  }
	
	/**
	 * do-nothing override  
	 */
	protected void drawAxes(Graphics g) throws Exception {}

	
	  
	  /**
	   * 
	   * @param g
	   * @param region
	   */
	  private void drawRegion(Graphics g, Region region, boolean withFill, boolean thickLines)
	  {
			// scaling from 100*100 grid to actual drawing grid
			 double scaling = new Double(xRight).doubleValue()/100.0;

			 Vector<double[]> polygon = region.getNormalPolygon();
			 int[] xPoint = new int[polygon.size()];
			 int[] yPoint = new int[polygon.size()];
			 
			 for (int p = 0; p < polygon.size(); p++)
			 {
				 // scale to actual pixels drawn
				 xPoint[p]= (int)(scaling*polygon.get(p)[0]);
				 yPoint[p]= xRight - (int)(scaling*polygon.get(p)[1]);
			 }
			 
			  // black outline for region polygon
			  g.setColor(Color.BLACK);
			 g.drawPolygon(xPoint, yPoint, polygon.size());
			 if (thickLines)
			 {
				 int[] xd = new int[polygon.size()];
				 int[] yd = new int[polygon.size()];
				 for (int p = 0; p < polygon.size();p++)
				 {
					 xd[p] = xPoint[p] + 1;
					 yd[p] = yPoint[p] + 1;
				 }
				 g.drawPolygon(xd, yPoint, polygon.size());
				 g.drawPolygon(xPoint, yd, polygon.size());				 
			 }

		  
		  // fill the rectangle - colour depends on density
		  if (withFill)
		  {
			  int density  = (int) region.getDensity();
			  Color c = getRegionColour(density);
			  g.setColor(c);
			  g.fillPolygon(xPoint, yPoint, polygon.size());
		  }
		  
		  
		  g.setColor(Color.BLACK);
		  String name = region.getName();
		  int scale_100 = (int)(scaling*100.0);
		  int[] centre = getCentre(xPoint,yPoint,scale_100);
		  int posX = centre[0] - 5*name.length();
		  int posY = centre[1];
		  Plot.bigBoldFont(g);
		  g.drawChars(name.toCharArray(), 0, name.length(), posX, posY);
		  Plot.normalFont(g); 

	  }
	  
	  /**
	   * find the centre of the on-map drawn points of a region
	   * @param x
	   * @param y
	   * @return
	   */
	  private int[] getCentre(int[]x, int[]y, int scale_100)
	  {
		  int[] centre = new int[2];
		  
		  int onPlot = 0;
		  for (int p = 0; p < x.length; p++)
		  {
			  if ((x[p] > 0) && (x[p] < scale_100) && (y[p] > 0) && (y[p] < scale_100))
			  {
				  centre[0] = centre[0] + x[p];
				  centre[1] = centre[1] + y[p];
				  onPlot++;
			  }
		  }
		  if (onPlot > 0) for (int i = 0; i < 2; i++) centre[i] = centre[i]/onPlot;
		  
		  return centre;
	  }
	  
	  
	  /**
	   * 
	   * @param density
	   * @return
	   */
	  private Color getRegionColour(int density)
	  {
		  Color c = Color.LIGHT_GRAY;
		  if (density > 0) c = Color.GREEN;
		  if (density > 4) c = Color.YELLOW;
		  if (density > 8) c = Color.ORANGE;
		  if (density > 15) c = Color.RED;
		  
		  return c;
		  
	  }
	  
	  /**
	   * draw all points in the whole stack of graphs
	   * @param g
	   */
	  private void drawAllPoints(Graphics g)
	  {
		  for (int i = 0; i< plotValues.size();i++)
			  drawPoints(g, plotValues.get(i), plotLabels.get(i), plotColours.get(i), plotTextures.get(i),i);
	  }
	  
	  /**
	   * draw the points and the caption in one member of the stack of graphs
	   * @param g
	   * @param values
	   * @param label
	   * @param colour
	   * @param symbol
	   * @param i
	   */
	  private void drawPoints(Graphics g, Vector<double[]> values, String label, Color colour, String symbol,int i)
	  {
		  for (double[] point: values) drawOnePoint(g, point,colour, symbol);
		  g.setColor(Color.BLACK);
		  drawCaption(g, colour, symbol, label,i);
	  }
	  
	  private static int[][] SQUARE = {{-3,-3,3,3},{-3,3,3,-3}};
	  private static int[][] TRIANGLE = {{-4,0,4},{3,-4,3}};
	  private static int[][] CROSS = {{-3,3,-3,3},{-3,3,3,-3}};

	  
	  /**
	   * draw one point
	   * @param g
	   * @param point
	   * @param colour
	   * @param symbol
	   */
	  private void drawOnePoint(Graphics g, double[] point, Color colour, String symbol)
	  {

		  int[] centre = new int[2];
		  centre[0] = (int)(xRight*point[0]);
		  centre[1] = (int)(xRight*(1.0- point[1]));
		  
		  drawThePoint(g,centre, colour, symbol);

	  }
	  
	  /**
	   * needed to write symbols in captions under the map
	   */
	  protected void drawBar(Graphics g, int[] today, int[] yesterday, Color colour, String style)
	  {
		  int xmin = today[0];
		  int meany = today[4];
		  int[] centre = new int[2];
		  centre[0] = xmin;
		  centre[1] = meany;
		  drawThePoint(g, centre, colour, style);
	  }

	  
	  /**
	   * 
	   * @param g
	   * @param centre
	   * @param colour
	   * @param symbol
	   */
	  private void drawThePoint(Graphics g,int[] centre, Color colour, String symbol)
	  {
		  g.setColor(colour);

		  if ("square".equalsIgnoreCase(symbol))
		  {
			  int[][] points = displace(SQUARE,centre);
			  Polygon poly = new Polygon(points[0],points[1],4);
			  g.fillPolygon(poly);
		  }

		  else if ("triangle".equalsIgnoreCase(symbol))
		  {
			  int[][] points = displace(TRIANGLE,centre);
			  Polygon poly = new Polygon(points[0],points[1],3);
			  g.fillPolygon(poly);
		  }

		  else if ("circle".equalsIgnoreCase(symbol))
		  {
			  g.fillOval(centre[0] -5, centre[1] -5 , 10, 10);
		  }
		  
		  else if ("cross".equalsIgnoreCase(symbol))
		  {
			  //  CROSS = {{-3,  3,  -3,  3},  {-3,  3,  3,  -3}};
			  //             x1,x2,  x1'  x2'    y1  y2  y1'  y2'
			  // lines (x1,y1)=> (x2,y2)   and (x1',y1' => x2', y2')
			  int[][] points = displace(CROSS,centre);
			  for (int width = 0; width < 2; width++) // width makes the line thicker in x
				  for (int prime = 0; prime < 2; prime++) // unprimed line, then primed line
						g.drawLine(points[0][2*prime] + width, points[1][2*prime], points[0][2*prime+1] + width, points[1][2*prime+1]);
			  					//        x1                        y1                  x2                           y2
		  }
		  
	  }

	  
	  /**
	   * displace a polygon
	   * @param shape
	   * @param disp
	   * @return
	   */
	  private int[][] displace(int[][] shape, int[]disp)
	  {
		  int[][] res = new int[2][6];
		  int points = shape[0].length;
		  for (int dim = 0; dim < 2; dim++)
			  for (int p = 0; p < points; p++)
				  res[dim][p] = disp[dim] + shape[dim][p];
		  return res;
	  }
		
		//-------------------------------------------------------------------------------------------------------------
		//                                             useless methods
		//-------------------------------------------------------------------------------------------------------------



	// do nothing
	protected int[] drawDay(Graphics g, int day, double[] value, int[] yesterday, Color colour, String style) {
		return null;		
	}
	
	@Override
	protected void drawVerticalAxisTicks(Graphics g, int logDecade) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void drawPeriodMarkers(Graphics g) {
		// TODO Auto-generated method stub
		
	}

	@Override
	int verticalTick() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	int dayInterval() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	protected int logDecade() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	protected void drawPopulationBar(Graphics g) {
		// TODO Auto-generated method stub
		
	}


}
