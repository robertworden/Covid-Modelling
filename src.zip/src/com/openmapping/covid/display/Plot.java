package com.openmapping.covid.display;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.Vector;

import com.openmapping.covid.model.Factory;

public abstract class Plot extends Canvas{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected int xRight;
	protected int yBottom;

	protected int scaleInset = 60;  //  distance of axes from left and bottom edges
	protected int shortTick = 4;    // short ticks on axes
	protected int longTick = 12;    // long ticks on axes, for each decade or 10 days
	
	protected int yCaptionInset = 20; // captions for plot above the bottom of the canvas
	protected int xCaptionInsetPerChar = 10; // x inset of caption per character of previous captions
	protected int captionSpace = 60;
	
	protected int bottomInterval = 35; // day labels from bottom edge
	
	/* outer vector = stack of plots; inner vector = days; double[] = [mean, lower quantile, median, upper quantile]  */
	protected Vector<Vector<double[]>> plotValues = new Vector<Vector<double[]>>();
	
	// stack of label for plots
	protected Vector<String> plotLabels = new Vector<String>();
		
	// stack of colours for plots
	protected Vector<Color> plotColours = new Vector<Color>();
	
	// stack of textures for plots
	protected Vector<String> plotTextures = new Vector<String>();
	
	// stack of button actions which gave plots each int is [tab,action]
	protected Vector<int[]> plotActions = new Vector<int[]>();
	
	// 
	protected Vector<int[]> copyPlotActions = new Vector<int[]>();

	
	public static Color[] COLOURS = {Color.BLACK, Color.BLUE, Color.RED, Color.GREEN};
	public static String[] COLOUR_NAMES = {"Black", "Blue", "Red", "Green"};

		
	protected ViewFrame frame;
	
    protected Factory factory;

	
	public Plot(int left, int top, int x, int y,ViewFrame frame)
	{
		this.frame = frame;
		xRight = x;
		yBottom = y;
		factory = frame.getFactory();
		
	    setBounds(left, top, x, y);
	    setBackground(Color.WHITE);
	}
	
	  public void paint(Graphics g) {
		    clear(g);
		    this.setBackground(Color.WHITE);
		    try
		    {
			    drawFrame(g);
		    }
		    catch (Exception ex) {ex.printStackTrace();}
		  }
	
	// super.paintComponent clears off screen pixmap,
	// since we're using double buffering by default.
	  protected void clear(Graphics g) {
	    super.paint(g);
	  }
	  
	  protected void drawFrame(Graphics g) throws Exception
	  {
		  g.setColor(Color.BLACK);
		  
		  // outer edges
		  g.drawLine(0, 0, xRight, 0);
		  g.drawLine(0, yBottom-1, xRight, yBottom-1);
		  g.drawLine(0, 0, 0, yBottom);
		  g.drawLine(xRight-1, 0, xRight-1, yBottom);
		  
		  drawAxes(g);
		  
		  // draw the data
		  drawGraphs(g);
	  }
	  
	  protected void drawAxes(Graphics g) throws Exception
	  {
		  
		  // draw axes slightly inset from border of frame
		  g.drawLine(scaleInset, yBottom-scaleInset, xRight - scaleInset, yBottom-scaleInset);
		  g.drawLine(scaleInset, scaleInset, scaleInset, yBottom - scaleInset);

		  // draw ticks and labels on axes
		  drawVerticalAxisTicks(g,verticalTick());
		  drawDayTicks(g, dayInterval());
	  }
	  
	  abstract int dayInterval();

	  
	   /**
	    * add a plot to the stack
	    * @param tab
	    * @param action
	    * @param values
	    * @param label
	    * @param colour
	    * @param texture
	    */
		public void addPlot(int tab, int action,Vector<double[]> values, String label, Color colour, String texture )
		{
			plotValues.add(values);
			plotLabels.add(label);
			plotColours.add(colour);
			plotTextures.add(texture);
			int[] act = new int[2];
			act[0] = tab;
			act[1] = action;
			plotActions.add(act);
		}
		
		/**
		 * remove the top plot from the stack
		 */
		public void removePlot()
		{
			if (plotLabels.size() > 0)
			{
				int last = plotValues.size() - 1;
				plotValues.remove(last);
				plotLabels.remove(last);
				plotColours.remove(last);
				plotTextures.remove(last);
				plotActions.remove(last);
			}
		}
		
		public void emptyAllPlots()
		{
			plotValues = new Vector<Vector<double[]>>();
			plotLabels = new Vector<String>();
			plotColours = new Vector<Color>();
			plotTextures = new Vector<String>();

			// to avoid java.util.ConcurrentModificationException, make a copy of plotActions
			copyPlotActions = new Vector<int[]>();
			for (int[] act: plotActions) copyPlotActions.add(act);
			plotActions = new Vector<int[]>(); 
		}
		
		/**
		 * for live update of graphs
		 */
		public void replayButtonPresses()
		{
			for (int[] act: copyPlotActions)// use a copy which will not be updated by doing the button actions
			{
				int tab = act[0];
				int action = act[1];
				frame.getMain().buttonAction(tab, action);
			}
		}
		
		
		
		  abstract protected void drawVerticalAxisTicks(Graphics g, int logDecade);
		
		  abstract int verticalTick();
		
		/**
		 *   
		 * @param g
		 * @param dayInterval
		 */
		protected void drawDayTicks(Graphics g, int dayInterval)
		  {
			  // number of decades you can fit in
			  int decades = (xRight - 2*scaleInset)/(10*dayInterval);
			  
			  
			  for (int i = 0; i < decades;i++)
			  {
				  int horizontal = scaleInset + 10*dayInterval*i;
				  g.setColor(Color.BLACK);
				  
				  String label = decadeLabel(i);
				  if (i == decades - 1) label = label + " days";

				  // label number of days every 10 days
				  boldFont(g);
				  g.drawChars(label.toCharArray(), 0, label.length(), horizontal-5, yBottom - bottomInterval);
				  normalFont(g);
				  // large tick every 10 days
				  g.drawLine(horizontal, yBottom - scaleInset, horizontal, yBottom - scaleInset + longTick);

				  // gray guide line every 10 days
				  if (i > 0) 
				  {
					  g.setColor(Color.LIGHT_GRAY);
					  g.drawLine(horizontal, yBottom - scaleInset, horizontal,  scaleInset);
					  g.setColor(Color.BLACK);
				  }
				  
				  // small ticks every day
				  for (int j = 1; j < 10;j++)
				  {
					  int x = horizontal + j*dayInterval;
					  g.drawLine(x, yBottom - scaleInset, x, yBottom - scaleInset + shortTick);
				  }
			  }
			  
			  drawPeriodMarkers(g);
		  }

		  /**
		   * 
		   * @param i
		   * @return
		   */
		  protected String decadeLabel(int i)
		  {
			  return new Integer(10*i).toString();
		  }
		  
		  abstract protected void drawPeriodMarkers(Graphics g);		  {}

		  /**
		   * draw all graphs
		   * @param g
		   */
		  protected void drawGraphs(Graphics g)
		  {
			  drawPopulationBar(g);
			  for (int i = 0; i< plotValues.size();i++)
				  drawGraph(g, plotValues.get(i), plotLabels.get(i), plotColours.get(i), plotTextures.get(i),i);
		  }
		  
		  abstract 	protected void drawPopulationBar(Graphics g);

		  
		  /**
		   * draw one graph
		   * @param g
		   * @param values
		   * @param label
		   * @param colour
		   * @param style
		   */
		  protected void drawGraph(Graphics g, Vector<double[]> values, String label, Color colour, String style, int i)
		  {
			  
			  // draw caption saying what the bars mean
			  drawCaption(g,colour,style,label,i);

			  int[] yesterday= null;
			  for (int day = 0; day < values.size(); day++)
			  {
				  double[] value = values.get(day);
				  yesterday = drawDay(g,day,value,yesterday,colour,style);

			  }
		  }
		  
		  /**
		   * 
		   * @param g
		   * @param colour
		   * @param style
		   * @param label
		   */
		  protected void drawCaption(Graphics g, Color colour, String style, String label, int i)
		  {
			  int yCaption = yBottom - yCaptionInset;
			  int[] pos = makeDay(xCaption(i), yCaption, yCaption  + 5, dayInterval(), 10);
			  drawBar(g,pos , pos, colour, style);
			  g.setColor(Color.BLACK);
			  Font font = new Font("Arial", Font.BOLD, 16);
			  g.setFont(font);
			  g.drawChars(label.toCharArray(), 0, label.length(), xCaption(i) + 25, yCaption + 10);
			  font = new Font("Arial", Font.PLAIN, 12);
			  g.setFont(font);
		  }
		  
		  /**
		   * inset of the ith caption
		   * @param i
		   * @return
		   */
		  protected int xCaption(int i)
		  {
			  int xCaption = scaleInset + 10;
			  
			  for (int p = 0; p < i; p++)
			  {
				  xCaption = xCaption + captionSpace + xCaptionInsetPerChar*plotLabels.get(p).length();
			  }
			  return xCaption;
		  }
		  
		  abstract protected int logDecade();
		  
		  /**
		   * 
		   * @param g
		   * @param day
		   * @param value
		   * @param colour
		   * @param style
		   */
		  protected int[] drawDay(Graphics g, int day,double[] value, int[] yesterday, Color colour, String style)
		  {
			  int xmin = scaleInset + day*dayInterval();
			  int maxy = yBottom - scaleInset - (int)(value[3]*logDecade()); // top of box = top quartile
			  int meany = yBottom - scaleInset - (int)(value[0]*logDecade()); // mean value if marked
			  int height = (int)(logDecade()*(value[3]- value[1])); // top quartile - bottom quartile
			  if (height < 1) height = 2;
			  
			  int[] today = makeDay(xmin,maxy,meany,height, dayInterval());
			  drawBar(g, today, yesterday, colour, style);
			  
			  return today;
		  }
		  
		  /**
		   * 
		   * @param xmin
		   * @param maxy
		   * @param meany
		   * @param height
		   * @param width
		   * @return
		   */
		  protected int[] makeDay(int xmin, int maxy, int meany, int height, int width)
		  {
			  int[] today = new int[5];
			  today[0] = xmin;
			  today[1] = maxy;
			  today[2] = height;
			  today[3] = width;
			  today[4] = meany;
			  return today;
		  }

		  
		  /**
		   * draw one bar on the graph in the selected style and colour
		   * @param g
		   * @param xmin
		   * @param maxy
		   * @param meany
		   * @param xinterval
		   * @param height
		   * @param colour
		   * @param style
		   */
		  protected void drawBar(Graphics g, int[] today, int[] yesterday, Color colour, String style)
		  {
			  int xmin = today[0];
			  int maxy = today[1];
			  int height = today[2];
			  int width = today[3];
			  int meany = today[4];
			  
			  g.setColor(colour);

			  if (style.equals("Solid"))
			  {
				  g.fillRect(xmin, maxy, width, height);
			  }
			  else if (style.equals("Dashed"))
			  {
				  g.fillRect(xmin, maxy, width/2, height);
			  }
			  else if (style.equals("Bar"))
			  {
				  int xVert = xmin + dayInterval()/2 - 1;
				  g.fillRect(xVert, maxy, 2, height); // vertical bar width 2
				  // g.drawLine(xVert, maxy, xVert, maxy + height);
				  g.drawLine(xmin, meany, xmin + width, meany);
			  }
			  else if (style.equals("Line"))
			  {
				  if (yesterday == null) yesterday = today;
				  int thickness = 3;
				  for (int t = 0; t < thickness; t++)
					  g.drawLine(xmin - width, yesterday[1] + t, xmin, today[1]+ t);
			  }
		  }

	  
	  //----------------------------------------------------------------------------------------------------------------------------
	  //                                                utility stuff
	  //----------------------------------------------------------------------------------------------------------------------------
	  
	  
	  public static void normalFont(Graphics g)
	  {
		  Font font = new Font("Arial", Font.PLAIN, 12);
		  g.setFont(font);
	  }

	  public static void boldFont(Graphics g)
	  {
		  Font font = new Font("Arial", Font.BOLD, 12);
		  g.setFont(font);
	  }

	  public static void bigBoldFont(Graphics g)
	  {
		  Font font = new Font("Arial", Font.BOLD, 16);
		  g.setFont(font);
	  }
	 


}
