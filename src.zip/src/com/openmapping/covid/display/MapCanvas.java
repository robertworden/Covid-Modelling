package com.openmapping.covid.display;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.util.Vector;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class MapCanvas extends Canvas implements ChangeListener{
	
	private int width;
	private int height;
	
	// region polygons to draw
	public void setNormalPolygons(Vector<Vector<double[]>> normalPolygons) {this.normalPolygons = normalPolygons;}
	private Vector<Vector<double[]>> normalPolygons = new Vector<Vector<double[]>>();
	
	private ViewFrame frame;
	
	public int[] getPanZoomSetting () {return panZoomSetting;}
	private int[] panZoomSetting = {10,50,50};
	
	public double getZoomFactor() {return zoomFactor;}
	private double zoomFactor;

	

	
	private static final long serialVersionUID = 1L;

	public MapCanvas(ViewFrame frame,int x, int y, int width, int height)
	{
		setBounds(x,y,width,height);
		this.width = width;
		this.height = height;
		this.frame = frame;
		
		for (int i = 0; i < 3; i++) frame.getPanZoomSlider()[i].addChangeListener(this);
		
	    setBackground(Color.WHITE);
	}
	
	/**
	 * 
	 * @param g
	 */
	private void drawMapLines(Graphics g)
	{
		// scaling from 100*100 grid to actual drawing grid
		 double scaling = new Double(width).doubleValue()/100.0;
		 
		 for (Vector<double[]> polygon: normalPolygons)
		 {
			 int[] xPoint = new int[polygon.size()];
			 int[] yPoint = new int[polygon.size()];
			 
			 for (int p = 0; p < polygon.size(); p++)
			 {
				 double[] displaced = panZoom(polygon.get(p),panZoomSetting);
				 
				 // scale to actual pixels drawn
				 xPoint[p]= (int)(scaling*displaced[0]);
				 yPoint[p]= width - (int)(scaling*displaced[1]);
			 }
			 
			 g.drawPolygon(xPoint, yPoint, polygon.size());
		 }
		
	}
	
	/**
	 * 
	 * @param point
	 * @param panZoomSetting
	 * @return
	 */
	public static double[] panZoom(double[] point, int[] panZoomSetting)
	{
		 // zoom by a factor 1.2 for every tick of the slider away from 10
		 double zoomFactor = Math.pow(1.20, new Double(panZoomSetting[0] - 10).doubleValue());

		 double[] result = new double[2];

		 // pan x and y. 50 (centre of slider) means no pan
		 double x = point[0] + new Double(panZoomSetting[1] - 50);
		 double y = point[1] + new Double(panZoomSetting[2] - 50);
		 
		 // zoom with centre point (50,50)
		 result[0] = 50.0 + zoomFactor*(x - 50.0);
		 result[1] = 50.0 + zoomFactor*(y - 50.0);
		
		return result;
	}
	
	//---------------------------------------------------------------------------------------------------------
	// 												graphics basics
	//---------------------------------------------------------------------------------------------------------
	
	
	  public void paint(Graphics g) {
		    clear(g);
		    setBackground(Color.WHITE);
		    try
		    {
			    drawFrame(g);
		    }
		    catch (Exception ex) {ex.printStackTrace();}
		  }
	
	// super.paintComponent clears off screen pixmap,
	// since we're using double buffering by default.
	  protected void clear(Graphics g) {
	    super.paint(g);
	  }


	  protected void drawFrame(Graphics g) throws Exception
	  {
		  g.setColor(Color.BLACK);
		  
		  // outer edges
		  g.drawLine(0, 0, width, 0);
		  g.drawLine(0, height-1, width, height-1);
		  g.drawLine(0, 0, 0, height);
		  g.drawLine(width-1, 0, width-1, height);
		  
		  
		  // draw the data
		  drawMapLines(g);
	  }


	/**
	 * when any of the three sliders is moved (zoom, pan x, or pan y)
	 * find out the new state.
	 */
	  public void stateChanged(ChangeEvent arg0) 
	{
			for (int i = 0; i < 3; i++) panZoomSetting[i] = frame.getPanZoomSlider()[i].getValue();
			repaint();
			frame.validate();
	}

}
