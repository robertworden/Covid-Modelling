package com.openmapping.covid.display;

import java.awt.Color;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JSpinner;

import com.openmapping.covid.SimUtil;
import com.openmapping.covid.WeightReader;
import com.openmapping.covid.model.DayEncounterSet;
import com.openmapping.covid.model.DiseaseState;
import com.openmapping.covid.model.EncounterGroup;
import com.openmapping.covid.model.ExposureEvent;
import com.openmapping.covid.model.Factory;
import com.openmapping.covid.model.ModelRunner;
import com.openmapping.covid.model.Period;
import com.openmapping.covid.model.Person;

public class ResultAnalyser {
	
	private Factory factory;
	private WeightReader reader;
	private ModelRunner runner;

	public void setFrame(ViewFrame frame) {this.frame = frame;}
	private ViewFrame frame;
	
	// maximum allowed number of scenarios
	private int maxScenarios = 10;
	
	// maximum number of periods in a scenario
	private int maxPeriods = 30;
	
	public Factory getFactory() {return factory;}
	
	// Outer Vector = scenarios; middle Vector = runs; inner Vector = days
	private Vector<Vector<Vector<DaySummary>>> daySummaries;
	
	public DaySummary getDaySummary(int scenario,int run, int day) {return daySummaries.get(scenario).get(run).get(day);}
	
	//  Vector = runs. index 1 = scenarios; index2 = periods
	private Vector<PeriodSummary[][]> periodSummaries = new Vector<PeriodSummary[][]>();
	
	private String venueName= "all";
	public void setVenueName(String name) {venueName = name;}
	
	private String personCriterion = "all";
	public void setAgeRangeCriterion(String code) {personCriterion = code;}
	
	private Color[] plotColour = new Color[ViewFrame.nTabs];
	public void setColour(int tab, int index) {plotColour[tab] = LogPlot.COLOURS[index];}
	public Color getColour(int tab) {return plotColour[tab];}
	
	private String[] barStyle = new String[ViewFrame.nTabs];
	public void setStyle(int tab, String style) {barStyle[tab] = style;}
	public String getStyle(int tab) {return barStyle[tab];}
	
	public static int STATE_PLOT = 0;
	public static int EVENT_PLOT = 1;
	public static int COMPUTE = 2;
	public static int SIMULATE = 3;
	public static int SHOW_PEOPLE = 4;
	public static int SHOW_VENUES = 5;
	public static int SHOW_EVENTS = 6;
	
	private String[][] labelPart = new String[ViewFrame.nTabs][ViewFrame.maxChoices];
	public void setLabelPart(int tab, int part,String val) {labelPart[tab][part] = val;}
	
	// index of dropdown used in each tab to choose a disease state or scenario or venue type; labelPart used to find current choice
	private int[] diseaseCodeChoice = {1,-1, 1,-1,-1, 1};
	private int[] scenarioChoice = {0,0,0,-1,-1,-1};
	private int[] venueTypeChoice = {-1,1,-1,-1,-1,2};
		
	private int[] scenario = new int[ViewFrame.nTabs];
	public void setScenario(int tab, int s) {scenario[tab] = s;}
	public int getScenario(int tab) {return scenario[tab];}
	
	private int[] periodIndex = new int[ViewFrame.nTabs];
	public void setPeriodIndex(int tab, int s) {periodIndex[tab] = s;}
	public int getPeriodIndex(int tab) {return periodIndex[tab];}
	
	// currently there is only one day spinner, on the map view tab
	public int getMapDay() 
	{
		JSpinner spinner = frame.getDaySpinner();
		Object value = spinner.getValue();		
		return ((Integer)value).intValue();
	}
	
	/**
	 * smarter labels for charts
	 * @param tab
	 * @param button
	 * @return
	 */
	public String getLabel(int tab, int button)
	{
		String label = "";
		int labelChoice = ViewFrame.useLabelParts[tab][button];
		if (labelChoice > 0)
		{
			String sLabel = new Integer(labelChoice).toString();
			for (int part = 0; part < sLabel.length(); part++)
			{
				String sPart = sLabel.substring(part,part + 1);
				int index = new Integer(sPart).intValue() - 1;
				String lPart =labelPart[tab][index];
				if (!"all".equalsIgnoreCase(lPart))
				{
					label = label + lPart;
					if (part < sLabel.length()-1) label = label + ",";
				}
			}
		}
			
		return label;
	}
	
	
	//---------------------------------------------------------------------------------------------------------
	//                                               Constructor
	//---------------------------------------------------------------------------------------------------------

	
	public ResultAnalyser(Factory factory,WeightReader reader,ModelRunner runner, ViewFrame frame)
	{
		this.factory = factory;
		this.reader = reader;
		this.runner = runner;
		this.frame = frame;
		
		runner.setAnalyser(this);
		
		for (int tab = 0; tab < ViewFrame.nTabs; tab++)
		{
			setColour(tab, 0); // set all tab colours black
			setStyle(tab,"Solid"); // set bar styles solid
			setScenario(tab,0); // all tabs to scenario 0
			setPeriodIndex(tab,0); // all tabs to period 0
		}
		
		setStyle(5,"Square"); // set map symbol square
					
	}
	

	
	public void setSummaries()
	{
		daySummaries = runner.getSummaries();
	}
		
	/**
	 * 
	 * @return
	 */
	public boolean hasResults()
	{
		boolean results = false;
		if ((daySummaries.size() > 0) && (daySummaries.get(0).size() > 0)) results = true;
		return results;
	}
	
	/**
	 * for a given scenario and day, return a Vector of DaySummariy for the different runs
	 * @param scenario
	 * @param day
	 * @return
	 */
	private Vector<DaySummary> getRunSummaries(int scenario, int day)
	{
		Vector<DaySummary> runSummaries = new Vector<DaySummary>();
		
		Vector<Vector<DaySummary>> scenarioSummaries = daySummaries.get(scenario);
		
		for (int r = 0; r < scenarioSummaries.size();r++)
		{
			Vector<DaySummary> oneRun = scenarioSummaries.get(r);
			if (oneRun.size() > day) runSummaries.add(oneRun.get(day));
		}		
		return runSummaries;
	}
	
	/**
	 * 
	 * @param day
	 * @return
	 */
	private double[] getEventNumbers(int scenario, int day) throws Exception
	{
		Vector<DaySummary> sums = getRunSummaries(scenario,day);

		int[] value = new int[sums.size()];		
		for (int r = 0; r < sums.size(); r++)
		{
			DaySummary daySummary = sums.get(r);
			Hashtable<String,Filterable> chosenThings = new Hashtable<String,Filterable>();
			Hashtable<String, ExposureEvent> allEvents = daySummary.getAllExposureEvents();
			for (Enumeration<String> en = allEvents.keys();en.hasMoreElements();)
			{
				String key = en.nextElement();
				chosenThings.put(key, allEvents.get(key));
			}
			
			//label part index is [tab][combo index]
			String venueType = labelPart[1][1];
			String region = labelPart[1][2];
			
			chosenThings = filter(venueType, VENUE_TYPE, daySummary, chosenThings);
			chosenThings = filter(region, REGION, daySummary, chosenThings);

			value[r] = chosenThings.size();
		}
		
		return makeQuartiles(value);
	}
	
	
	private double[] getPersonStateNumbers_2(int tab,int scenario, int day) throws Exception
	{
		Vector<DaySummary> sums = getRunSummaries(scenario,day);

		int[] value = new int[sums.size()];		
		for (int r = 0; r < sums.size(); r++)
		{
			DaySummary daySummary = sums.get(r);
			Hashtable<String,Filterable> chosenThings = new Hashtable<String,Filterable>();
			Hashtable<String, Person> allPeople = factory.getPersons();
			for (Enumeration<String> en = allPeople.keys();en.hasMoreElements();)
			{
				String key = en.nextElement();
				chosenThings.put(key, allPeople.get(key));
			}
			

			// filter them  (by disease name in the scenario in run 0 on the selected day)
			String selName = getChosenDiseaseStateName(tab);
			int filterType = getStateFilterType(selName);
			chosenThings = filter(selName,filterType,daySummary,chosenThings);
			

			value[r] = chosenThings.size();
		}
		
		return makeQuartiles(value);
	}
	
	// social state menu items start with "S:"
	private int getStateFilterType(String selName)
	{
		int type = DISEASE_STATE;
		if (selName.startsWith("S:")) type = SOCIAL_STATE;
		return type;
	}

	
	/**
	 * 
	 * @param tab
	 * @return
	 * @throws Exception
	 */
	private String getChosenDiseaseCode(int tab) throws Exception
	{
		String stateName = "all";
		String code = "all";

		int choice = diseaseCodeChoice[tab];
		if (choice > -1) stateName = labelPart[tab][choice];

		if (stateName.equals("R")) code = stateName;
		else if (stateName.equals("all")) code = stateName;
		else if (stateName.startsWith("S:")) {} // not allowed
		else code = reader.covidStateCodeFromName(stateName);
		return code;
	}
	
	/**
	 * 
	 * @param tab
	 * @return
	 * @throws Exception
	 */
	private String getChosenDiseaseStateName(int tab) throws Exception
	{
		String stateName = "all";
		int choice = diseaseCodeChoice[tab];
		if (choice > -1) stateName = labelPart[tab][choice];
		return stateName;
	}

	
	/**
	 * 
	 * @param tab
	 * @return
	 * @throws Exception
	 */
	private String getChosenVenueType(int tab) throws Exception
	{
		String typeName = "all";
		int choice = venueTypeChoice[tab];
		if (choice > -1) typeName = labelPart[tab][choice];		
		return typeName;
	}
	
	
	/**
	 * make an array of doubles [mean, lower quartile, median, upper quartile]
	 * from an array of integer values.
	 * 
	 * Best sizes for the array are 4*N + 1 :1,5,9,13....
	 * @param value
	 * @return
	 */
	private double[] makeQuartiles(int[]value)
	{
		int runs = value.length;
		double[] result = new double[4];

		double mean = 0.0;
		for (int r = 0; r < runs; r++)
			mean = mean + new Double(value[r]).doubleValue()/runs;
		result[0] = mean;
		
		Arrays.sort(value);
		
		int[] quartile = new int[3];
		quartile[0] = (runs-1)/4;
		quartile[1] = (runs-1)/2;
		quartile[2] = (3*(runs-1))/4;
		
		for (int i = 0; i < 3; i++)
			result[i+1] = new Double(value[quartile[i]]).doubleValue();
		
		return result;
	}

	/**
	 * make an array of doubles [mean, lower quartile, median, upper quartile]
	 * from an array of double values.
	 * 
	 * Best sizes for the array are 4*N + 1 :1,5,9,13....
	 * @param value
	 * @return
	 */
	private double[] makeQuartiles(double[]value)
	{
		int runs = value.length;
		double[] result = new double[4];

		double mean = 0.0;
		for (int r = 0; r < runs; r++)
			mean = mean + value[r]/runs;
		result[0] = mean;
		
		Arrays.sort(value);
		
		int[] quartile = new int[3];
		quartile[0] = (runs-1)/4;
		quartile[1] = (runs-1)/2;
		quartile[2] = (3*(runs-1))/4;
		
		for (int i = 0; i < 3; i++)
			result[i+1] = value[quartile[i]];
		
		return result;
	}
	
	//----------------------------------------------------------------------------------------------------------
	//                             return results for graphs and map
	//----------------------------------------------------------------------------------------------------------

	/**
	 * 
	 * @param code
	 * @return Vector of log numbers for plotting
	 */
	public Vector<double[]> getLogNumbers(int tab, int plotType) throws Exception
	{
		Vector<double[]> logNumbers = new Vector<double[]>();
		double[] natural = new double[4];
		
		// run 0 of the scenario determines the number of days in the plot
		int days = 0;
		if (plotType == STATE_PLOT) days = daySummaries.get(scenario[0]).get(0).size();
		if (plotType == EVENT_PLOT) days = daySummaries.get(scenario[1]).get(0).size();
		
		for (int day = 0; day < days; day++)
		{
			double[] logNumber = new double[4];

			if (plotType == STATE_PLOT) natural = getPersonStateNumbers_2(tab,scenario[0],day);
			else if (plotType == EVENT_PLOT) natural = getEventNumbers(scenario[1],day);
			
			for (int i = 0; i < 4; i++)
			{
				if (natural[i] > 0) logNumber[i] = Math.log10(natural[i]);
				else logNumber[i] = 0.0; // bottom axis of the plot
			}
			
			logNumbers.add(logNumber);
		}
		
		return logNumbers;
	}
	
	// normalisation factor to compute R.  0.8 is the probability of infection given exposure.
	private double R_normalisationFactor() throws Exception
	   {return new Double(reader.getParameterValue("infect_probability")).doubleValue()*0.8;}

	/**
	 * 
	 * @param code
	 * @return Vector of numbers for plotting on a linear scale
	 */
	public Vector<double[]> getRealNumbers(int tab,int plotType) throws Exception
	{
		PeriodSummary[][] thisRun= null; 
		PeriodSummary periodSum = null;

		// write a histogram of infectors - how many people they each infect
		if (periodSummaries.size() > 0)
		{
			thisRun = periodSummaries.get(0);
			periodSum = thisRun[getScenario(tab)][getPeriodIndex(tab)];
			// periodSum.writeInfectorHistogram();
		}
		
		Vector<double[]> resultNumbers = new Vector<double[]>();
		double[] onePoint = new double[4];
		
		String numberRow = "";
		double pSum = 0.0;
		// iterate over days  after the day of exposure
		for (int day = 0; day < DiseaseState.maxDays; day++)
		{
			String code = getChosenDiseaseCode(tab);
			// probabilities of disease states, or transmission rate R per day
			if (plotType == COMPUTE) 
			{
				double prob = getStateProbability(code,day);
				// no variance or quartiles, because a theoretical calculation
				onePoint = noSpread(prob);
				pSum = pSum + prob;
			}
			
			// probability of a disease code, or transmission rate R per day after exposure, from the simulation
			else if (plotType == SIMULATE)
			{
				// array to collect different runs
				double[]  codeProbability = new double[periodSummaries.size()];
				
				for (int run = 0; run < periodSummaries.size(); run++)
				{
					//get the correct Period Summary for the run, scenario and period
					thisRun = periodSummaries.get(run);
					periodSum = thisRun[getScenario(tab)][getPeriodIndex(tab)];

					if (!code.equals("R"))
					{
						// the Monte Carlo appears to have a lag of one day - compensate
						codeProbability[run] = periodSum.getStateProbability(day+1,code);
					}
					
					else if (code.equals("R"))
					{
						double infections = 0.0;
						if (day < periodSum.passOnDelays().length)
							infections = new Double(periodSum.passOnDelays()[day]).doubleValue();
						double infectors = new Double(periodSum.getNumberOfInfectors()).doubleValue();

						if (infectors > 0.0) codeProbability[run]= infections/infectors;
						else codeProbability[run] = 0.0;
						
						// normalise for probability of infection after exposure - FIXME - do it properly
						for (int q = 0; q < 4; q++) codeProbability[run] = codeProbability[run]*0.8;
					}

				}

				// combine the runs to make quartiles
				onePoint = makeQuartiles(codeProbability);

				pSum = pSum + onePoint[0]; // add the mean of the range
			}
			
			// summary row for diagnostics
			numberRow = numberRow + Factory.neat(onePoint[2])+ ",";
			
			resultNumbers.add(onePoint);
		}
		
		// SimUtil.message("Sum over days: " + pSum); // maybe should display pSum on the tab?
		
		return resultNumbers;
	}
	
	/**
	 * 
	 * @param tab
	 * @param plotType
	 * @return Vector of coordinates for plotting on the map view
	 * @throws Exception
	 */
	public Vector<double[]> getCoordinates(int tab,int plotType) throws Exception
	{
		Vector<double[]> coords = new Vector<double[]>();
		
		Hashtable<String,double[]> filteredCoords = new Hashtable<String,double[]>();
		Hashtable<String,Filterable> filteredThings = new Hashtable<String,Filterable>();
		
		if (plotType == SHOW_PEOPLE)
		{
			// the map view uses run 0, and uses the day taken from the day spinner on the map tab
			DaySummary daySummary = getDaySummary(getScenario(tab), 0, getMapDay());

			// get all people
			for (Enumeration<Person> en = factory.getPersons().elements(); en.hasMoreElements();)
			{
				Person person = en.nextElement();
				filteredThings.put(person.getFilterKey(),person);
			}

			// filter them  (by disease name in the scenario in run 0 on the selected day)
			String selName = getChosenDiseaseStateName(tab);
			int filterType = getStateFilterType(selName); // DISEASE_STATE or SOCIAL_STATE
			filteredThings = filter(selName,filterType,daySummary,filteredThings);
			
			// extract their grid references
			for (Enumeration<Filterable> en = filteredThings.elements();en.hasMoreElements();)
			{
				Person person = (Person)en.nextElement();
				String grid = person.getHousehold().getGridReference();
				double[] coord = makeCoord(grid);
				filteredCoords.put(person.getId(), coord);
			}
			
		}
		
		else if (plotType == SHOW_VENUES)
		{
			for (Enumeration<EncounterGroup> en = factory.getGroups().elements(); en.hasMoreElements();)
			{
				EncounterGroup group = en.nextElement();
				String grid = group.getGrid();
				double[] coord = makeCoord(grid);
				filteredCoords.put(group.getId(), coord);
			}
			String selCode = getChosenVenueType(tab);
			filteredCoords = filterVenuesByType(selCode,filteredCoords);
		}
		
		else if (plotType == SHOW_EVENTS)
		{
			
		}
		
		for (Enumeration<double[]> en = filteredCoords.elements();en.hasMoreElements();)
			coords.add(en.nextElement());
		
		return coords;
		
	}
	
	//------------------------------------------------------------------------------------------------------
	//                            Generic filtering of model objects
	//------------------------------------------------------------------------------------------------------
	
	/**
	 * all types of comparison required by any tab
	 */
	public static int DISEASE_STATE = 0;
	public static int AGE_RANGE = 1;
	public static int VENUE_TYPE = 2;
	public static int REGION = 3;
	public static int SCENARIO = 4;
	public static int DAY = 5;
	public static int SOCIAL_STATE = 6;
	
	/**
	 * 
	 * @param required
	 * @param actual
	 * @param filterType
	 * @return true if the actual value is eligible as a match to the required value
	 */
	private boolean isEligible(String required, String actual, int filterType)
	{
		// assume failure unless a reason to find otherwise
		boolean matches = false;
		
		// successes for all filter types
		if ("all".equalsIgnoreCase(required)) return true;
		if (actual.equals(required)) return true;
		
		// special case successes follow
		if (filterType == DISEASE_STATE)
		{
			
		}
		
		else if (filterType == AGE_RANGE)
		{
			
		}
		
		else if (filterType == VENUE_TYPE)
		{
			if ("all public".equalsIgnoreCase(required)) matches = !("home".equals(actual));
		}
		
		else if (filterType == REGION)
		{
			
		}
		
		return matches;
	}
	
	/**
	 * filter a set of filterable objects according to some criterion
	 * @param required
	 * @param filterType
	 * @param unfiltered
	 * @return
	 */
	private Hashtable<String,Filterable> filter(String required, int filterType, DaySummary daySummary, Hashtable<String,Filterable> unfiltered) throws Exception
	{
		Hashtable<String,Filterable> result = new Hashtable<String,Filterable>();
		
		for (Enumeration<String> en = unfiltered.keys();en.hasMoreElements();)
		{
			String key = en.nextElement();
			Filterable candidate = unfiltered.get(key);
			if (isEligible(required, candidate.getFilterValue(daySummary,filterType),filterType)) result.put(key, candidate);
		}
		
		return result;
	}
	
	
	
	/**
	 * 
	 * @param type
	 * @param unfiltered
	 * @return
	 */
	private Hashtable<String,double[]> filterVenuesByType(String type, Hashtable<String,double[]> unfiltered)
	{
		Hashtable<String,double[]> filtered = new Hashtable<String,double[]>();
		if ("all".equalsIgnoreCase(type)) return filtered;
		
		for (Enumeration<String> en = unfiltered.keys();en.hasMoreElements();)
		{
			String gid = en.nextElement();
			double[] coord = unfiltered.get(gid);
			EncounterGroup group = factory.getEncounterGroup(gid);
			if (group.getType().equals(type)) filtered.put(gid, coord);
		}		
		return filtered;		
	}

	/**
	 * 
	 * @param type
	 * @param unfiltered
	 * @return
	private Hashtable<String,?T> genericFilterVenuesByType(String type, Hashtable<String,?T> unfiltered)
	{
		Hashtable<String,?T> filtered = new Hashtable<String,?T>();
		if ("all".equalsIgnoreCase(type)) return filtered;
		
		for (Enumeration<String> en = unfiltered.keys();en.hasMoreElements();)
		{
			String gid = en.nextElement();
			?T coord = unfiltered.get(gid);
			EncounterGroup group = factory.getEncounterGroup(gid);
			if (group.getType().equals(type)) filtered.put(gid, coord);
		}		
		return filtered;		
	}
	*/

	
	/**
	 * convert a grid reference string like '6318_7426' to a pair of doubles in the range 0 - 1.0
	 * @param grid
	 * @return
	 */
	private double[] makeCoord(String grid)
	{
		double[] coord = new double[2];
		StringTokenizer st = new StringTokenizer(grid,"_");
		int i = 0;
		while (st.hasMoreTokens())
		{
			coord[i] = new Double(st.nextToken()).doubleValue()/10000.0;
			i++;
		}
		return coord;
	}
	
	/**
	 * expected number of encounters per person in public places
	 * @return
	 */
	private double encountersPerPerson()
	{
		// multiply by the number of encounters per  person on a random day
		DayEncounterSet dSet = factory.getDayEncounterSets().elements().nextElement();
		double encs = new Double(dSet.getEncounterNumber()).doubleValue();
		double pop = new Double(factory.getPersons().size()).doubleValue();
		return encs/pop;
	}

	
	/**
	 * 
	 * @param stateCode
	 * @param day
	 * @return
	 * @throws Exception
	 */
	private double getStateProbability(String stateCode, int day) throws Exception
	{
		double prob = 0.0;
		
		//  R stands for all infectious states,weighted as below
		if ("R".equals(stateCode))
		{
			for (String code: factory.getDiseaseStateCodes())
			{
				DiseaseState state = factory.getDiseaseState(code);
				if (state.isInfectious()) prob = prob + getStateProbability(code,day);
			}
			
			// multiply by the number of encounters per  person on a random day
			double perDay = encountersPerPerson();
			prob = prob*perDay;					
			// multiply by the probability of exposure to the virus in a meeting, and the probability of infection given exposure
			prob = prob*R_normalisationFactor();			
		}
		
		// what is the use of summing probabilities over all states? Must be 1?
		else if ("all".equalsIgnoreCase(stateCode))
		{
			prob = 1.0;
		}
		
		// specific state codes
		else
		{
			DiseaseState state = factory.getDiseaseState(stateCode);
			prob = state.getStateProbability(day);
		}
		
		return prob;
	}
	
	/**
	 * calculate quartiles and mean when there is no spread
	 * @param d
	 * @return
	 */
	private double[] noSpread(double d)
	{
		double[] onePoint = new double[4];
		for (int i = 0; i < 4; i++) onePoint[i] = d;
		return onePoint;
		
	}
	

	// -----------------------------------------------------------------------------------------------------
	//                                 Period Summaries
	// -----------------------------------------------------------------------------------------------------

	//  Vector = runs. index 1 = scenarios; index2 = periods
	// Vector<PeriodSummary[][]> periodSummaries

	
	/**
	 * 
	 * @param scenarioNo
	 * @param run
	 */
	public void newPeriodSummaries(int scenarioNo, int run, int lastRunDay) throws Exception
	{
		if (run > periodSummaries.size()) throw new Exception("Run " + run + " does not ascend by 1");
		if (run == periodSummaries.size()) periodSummaries.add(new PeriodSummary[maxScenarios][maxPeriods]);
		
		PeriodSummary[][] thisRun = periodSummaries.get(run);
		
		int nPeriods = factory.nPeriods(scenarioNo);		
		for (int pd = 0; pd < nPeriods; pd++)
		{
			Period period = factory.getPeriod(scenarioNo, pd);
			PeriodSummary ps = new PeriodSummary(this,scenarioNo,run, period,lastRunDay);
			thisRun[scenarioNo][pd] = ps;
		}
		
	}
	

}
