package com.openmapping.covid.display;

import java.awt.Component;

import javax.swing.JScrollPane;

public class MapCapturePlot extends JScrollPane{
	
	private static final long serialVersionUID = 1L;

	public MapCapturePlot(int x, int y, int width, int height, Component view)
	{
		super(view, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		setBounds(x, y, width, height);
	}

}
