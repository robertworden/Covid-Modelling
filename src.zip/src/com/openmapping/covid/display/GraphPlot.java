package com.openmapping.covid.display;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Enumeration;

import com.openmapping.covid.model.DiseaseState;

public class GraphPlot extends Plot{
	
	private int radius = 20;
	
	private int scaleX;
	
	private int scaleY;
	
	private int baseY;
	
	private int thickness = 3;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//----------------------------------------------------------------------------------------
	//                               Constructor
	//----------------------------------------------------------------------------------------

	/**
	 * 
	 * @param left
	 * @param top
	 * @param x
	 * @param y
	 * @param frame
	 */
	public GraphPlot(int left, int top, int x, int y,ViewFrame frame)
	{
		super(left,top,x,y,frame);
		
		setScales();
	}
	
	/**
	 *   
	 */
	private void setScales()
	  {
		  // find the limits of X and Y for any state
		  int minX = 1;
		  int maxX = 0;
		  int maxY = 0;
		  int minY = 0; // will be negative
		  
		  if (factory != null)
		  {
			  for (String code: factory.getDiseaseStateCodes())
			  {
				  DiseaseState state = factory.getDiseaseState(code);
				  if (state.getDrawX() > maxX) maxX = state.getDrawX();
				  if (state.getDrawY() > maxY) maxY = state.getDrawY();
				  if (state.getDrawY() < minY) minY = state.getDrawY();
			  }
		  }
		  
		  scaleX = xRight/(maxX - minX + 3);
		  scaleY = yBottom/(maxY - minY + 3);
		  
		  // (baseY - scaleY*(minY - 1)) = yBottom; a point (minY -1) would be on the bottom edge (minY is negative)
		  // (baseY - scaleY*(1 + maxY)) = 0      ; a point (maxY + 1) would be on the top edge
		  // so 2*baseY - scaleY*(maxY + minY) = yBottom (by adding the equations). Then allow for radii
		  baseY = yBottom/2 + scaleY*(maxY + minY)/2 + radius;
	  }
	  

	
	//----------------------------------------------------------------------------------------
	//                               Drawing the state graph
	//----------------------------------------------------------------------------------------

	
	  protected void drawGraphs(Graphics g)
	  {		  
		  try
		  {
			  for (String code: factory.getDiseaseStateCodes())
			  {
				  DiseaseState state = factory.getDiseaseState(code);
				  
				  /* as every state is drawn before the states it goes to,  transition lines can be drawn before the state,
				   * and will be covered by the state circle */
				  drawTransitionLines(g,state);
				  
				  int x = drawPos(code)[0];
				  int y = drawPos(code)[1];
				  
				  // coloured circle
				  g.setColor(Color.LIGHT_GRAY);
				  if (state.isInfectious()) g.setColor(Color.YELLOW);
				  g.fillOval(x-radius, y-radius, 2*radius, 2*radius);
				  g.setColor(Color.BLACK);
				  for (int t= 0; t < thickness; t++) g.drawOval(x-radius, y- radius, 2*radius + t, 2*radius + t);
				  
				  // code at the centre of the circle
				  bigBoldFont(g);
				  g.drawChars(code.toCharArray(), 0, 1, x - 5, y + 7);
				  boldFont(g);
				  
				  // state name below the circle
				  String name = state.getName();
				  g.drawChars(name.toCharArray(), 0, name.length(), x - 3*(name.length()), y + 16 + radius);
				  normalFont(g);
			  }
		  }
		  catch (Exception ex) {}
	  }
	  
	  /**
	   * 
	   * @param state
	   * @throws Exception
	   */
	  private void drawTransitionLines(Graphics g, DiseaseState state) throws Exception
	  {
		  int[] fromLine = drawPos(state.getCode());
		  
		  for (Enumeration<String> en = state.getTransitions().keys();en.hasMoreElements();)
		  {
			  String toCode = en.nextElement();
			  DiseaseState toState = factory.getDiseaseState(toCode);
			  int[] toLine = drawPos(toCode);
			  g.drawLine(fromLine[0], fromLine[1], toLine[0], toLine[1]);
		  }
	  }

	  
	  /**
	   * 
	   * @param code
	   * @return centre of circle to draw, or origin of transition lines
	   * @throws Exception
	   */
	  private int[] drawPos(String code) throws Exception
	  {

		  DiseaseState state = factory.getDiseaseState(code);
		  
		  int[] pos = new int[2];
		  pos[0] = state.getDrawX()*scaleX - radius;
		  pos[1] = baseY - scaleY*state.getDrawY() - radius;
		  return pos;
	  }

	

	  //------------------------------------------------------------------------------------------------------
	  //                        Irrelevant methods
	  //------------------------------------------------------------------------------------------------------

	  protected void drawAxes(Graphics g) throws Exception
	  {}

	@Override
	protected int[] drawDay(Graphics g, int day, double[] value, int[] yesterday, Color colour, String style) {
		return null;
		
	}

	@Override
	protected void drawVerticalAxisTicks(Graphics g, int logDecade) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void drawPeriodMarkers(Graphics g) {
		// TODO Auto-generated method stub
		
	}

	@Override
	int verticalTick() {
		// TODO Auto-generated method stub
		return 50;
	}

	@Override
	int dayInterval() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	protected int logDecade() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	protected void drawPopulationBar(Graphics g) {
		// TODO Auto-generated method stub
		
	}
	

}
