package com.openmapping.covid.display;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import com.openmapping.covid.WeightReader;
import com.openmapping.covid.model.ExposureEvent;
import com.openmapping.covid.model.Factory;
import com.openmapping.covid.model.GroupExposureEvent;
import com.openmapping.covid.model.Person;

public class DaySummary {
	
	public int getScenario() {return scenario;}
	private int scenario;
	
	public int getRun() {return run;}
	private int run;
	
	public int getDay() {return day;}
	private int day;
	
	private Factory factory;
	
	private WeightReader reader;
			
	// people with disease state code "C" (uninfected) are not stored, to keep these objects small
	private Hashtable<String,String> diseaseStateCodesByPid = new Hashtable<String,String>();
		
	// people with social sate code "F"(free) are not stored here for brevity
	private Hashtable<String,String> socialStateCodesByPid = new Hashtable<String,String>();
	
	private Hashtable<String,String[]> allExposureEvents = new Hashtable<String,String[]>(); 
	
	//---------------------------------------------------------------------------------------------------
	//                                        constructor
	//---------------------------------------------------------------------------------------------------
	
	public DaySummary(Factory factory, WeightReader reader, int scenario, int run, int day)
	{
		this.scenario = scenario;
		this.run = run;
		this.day = day;

		this.factory = factory;
		this.reader = reader;
	}
	
	/**
	 * 
	 */
	public void setState()
	{
		diseaseStateCodesByPid = new Hashtable<String,String>();
		socialStateCodesByPid = new Hashtable<String,String>();
		allExposureEvents = new Hashtable<String,String[]>();
		
		for (Enumeration<Person> en = factory.getPersons().elements();en.hasMoreElements();)
		{
			// store today's person states
			Person person = en.nextElement();

			storePersonStates(person);
			
			storeExposureEvents(person);
		}
		
	}
	
	/**
	 * 
	 * @param person
	 */
	private void storePersonStates(Person person)
	{
		String diseaseState = person.getCurrentDiseaseState();
		if (! diseaseState.equals("C")) diseaseStateCodesByPid.put(person.getId(), diseaseState);

		String socialState = person.getCurrentSocialState();
		if (! socialState.equals("F"))  socialStateCodesByPid.put(person.getId(), socialState);

	}
	
	/**
	 * store yesterday's exposure events for a person
	 * @param person
	 */
	private void storeExposureEvents(Person person)
	{
		GroupExposureEvent gExp = person.getGroupExposure(getDay()-1);
		ExposureEvent hExp = person.getHomeExposure(getDay()-1);
				
		if (hExp != null) allExposureEvents.put(hExp.getFilterKey(), hExp.getSummary());
		if (gExp != null) allExposureEvents.put(gExp.getFilterKey(), gExp.getSummary());		
	}

	
	/**
	 * 
	 * @param pid
	 * @return
	 * @throws Exception
	 */
	public String getDiseaseStateName(String pid) throws Exception
	{
		String state = diseaseStateCodesByPid.get(pid);
		if (state == null) state = "C";
		return reader.covidStateNameFromCode(state);
	}
	
	/**
	 * all exposure events on the day in the run in the scenario. key = filter key.
	 * @return
	 */
	public Hashtable<String,ExposureEvent> getAllExposureEvents() 
	{
		Hashtable<String,ExposureEvent> res = new Hashtable<String,ExposureEvent>();
		for (Enumeration<String> en = allExposureEvents.keys();en.hasMoreElements();)
		{
			String key = en.nextElement();
			res.put(key, ExposureEvent.makeExposureEvent(allExposureEvents.get(key), factory));
		}
		return res;
	}

	/**
	 * 
	 * @param pid
	 * @return
	 * @throws Exception
	 */
	public String getSocialStateName(String pid) throws Exception
	{
		String state = socialStateCodesByPid.get(pid);
		if (state == null) state = "F";
		return reader.socialStateNameFromCode(state);
	}

	
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public Vector<String> infectiousPeople() throws Exception
	{
		Vector<String> infectors = new Vector<String>();
		
		for (Enumeration<String> en = diseaseStateCodesByPid.keys(); en.hasMoreElements();)
		{
			String pid = en.nextElement();
			String stateCode = diseaseStateCodesByPid.get(pid);
			if (stateCode == null) stateCode = "C"; // not infectious
			if (reader.infectiousState(stateCode)) infectors.add(pid);
		}		
		return infectors;
	}
	

}
