package com.openmapping.covid.display;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Vector;

public class LinearPlot extends Plot{
	
	//  per day on horizontal axis
	protected int dayInterval = 20; 
	
	// Power of 10 which values must be multiplied by, to get the largest value in the range 1.0 to 9.0
	private int exponent = 0;
	
	/* rounded is in 1-9 inclusive. After scaling up or down by exponent, all values are in the range 0.. rounded,
	 * and the vertical scale has rounded decades with large ticks, each with 10 small ticks in it */
	private int rounded = 1;
	
	private int verticalPixels() {return (yBottom - 2*scaleInset);}
	
	// all numbers must be multiplied by scale to convert them to a number of pixels above the x axis of the plot
	private double scale = 1.0;
	
	private static final long serialVersionUID = 1L;
	
	//-----------------------------------------------------------------------------------------------------------------
	//                               constructor
	//-----------------------------------------------------------------------------------------------------------------

	public LinearPlot(int left, int top, int x, int y,ViewFrame frame)
	{
		super(left,top,x,y,frame);
	}
	
	//-----------------------------------------------------------------------------------------------------------------
	//                               constructor
	//-----------------------------------------------------------------------------------------------------------------

	
	/**
	 * Set a scale such that all points in all plots will fit into the vertical interval (y -2*scaleInset) pixels.
	 * Assumes all plotted values are zero or positive.
	 * 
	 * Reset the instance variables scale, rounded,and exponent
	 */
	private void setScale()
	{
		scale = 0.0;
		double maxVal = 0.0;
		
		// find the largest positive value
		for (int i = 0; i < plotValues.size(); i++)
		{
			Vector<double[]> onePlot  = plotValues.get(i);
			for (double[] oneValue: onePlot)
			{
				double upper = oneValue[3]; // upper quartile of any data point
				if (upper > maxVal) maxVal = upper;
			}
		}
		
		// round maxVal up to A*10^N, where A is an integer between 1 and 9. N may be positive or negative
		exponent = 0;
		boolean inRange = false;
		double scaledUp = maxVal; // will be maxVal multiplied by positive powers of 10 (exponent >= 1.0)
		double scaledDown = maxVal; // will be maxVal multiplied  by negative powers of 10 (exponent < 1.0)
		boolean isScaledUp = false;
		
		// keep increasing both the positive and negative powers of 10, until one of them fits in the range  q.0 to 9.0
		while (!inRange)
		{
			if (inRange(scaledUp)) // scaledUp between 0.9 and 9.0
			{
				inRange = true;
				isScaledUp = true;
				rounded = (int)scaledUp; // 0 to 9
				if (rounded == 0) rounded = 1;  // 1 to 9 
			}

			else if (inRange(scaledDown)) // scaledDown between 0.9 and 9.0
			{
				inRange = true;
				isScaledUp = false;
				rounded = (int)scaledDown; // 0 to 9
				if (rounded == 0) rounded = 1;  // 1 to 9 
			}
			
			// for next time round
			scaledUp = 10.0* scaledUp;
			scaledDown = scaledDown/10.0;
			exponent++;
		}
		
		exponent--; // compensate for the last factor 10
		if (!isScaledUp) exponent = -exponent;
		double exPower = Math.pow(10.0, new Double(exponent).doubleValue());	
		
		rounded++; // headroom above the highest point
		scale = exPower*(verticalPixels()/rounded);
		
	}
	
	boolean inRange(double d) { return ((d > 0.9) && (d < 10.0));}

	  /**
	   * 
	   * @param g
	   * @param day
	   * @param value
	   * @param colour
	   * @param style
	   */
	  protected int[] drawDay(Graphics g, int day,double[] value, int[] yesterday, Color colour, String style)
	  {
		  int xmin = scaleInset + day*dayInterval();

		  int top = (int)(value[3]*scale);
		  int middle = (int)(value[0]*scale);
		  int bottom = (int)(value[1]*scale);

		  int maxy = yBottom - scaleInset - top; // top of box = top quartile
		  int meany = yBottom - scaleInset - middle; // mean value if marked
		  int height = top - bottom; // top quartile - bottom quartile
		  if (height < 1) height = 2;
		  
		  int[] today = makeDay(xmin,maxy,meany,height, dayInterval());
		  drawBar(g, today, yesterday, colour, style);
		  
		  return today;
	  }

	/**
	 * 
	 */
	protected void drawVerticalAxisTicks(Graphics g, int logDecade) 
	{
		g.setColor(Color.BLACK);
		// only draw ticks on the vertical axis of there are some data
		if (plotValues.size() > 0)
		{
			//set the vertical scale from the current plot values
			setScale();
			
			// draw major ticks with labels and horizontal bars
			for (int major = 1; major < rounded + 1; major++)
			{
				int height = yBottom - scaleInset - (verticalPixels()*major)/rounded;
				
				// major ticks
				g.drawLine(scaleInset - longTick, height, scaleInset, height);
				
				// hoizintal gray lines
				g.setColor(Color.LIGHT_GRAY);
				g.drawLine(scaleInset, height, xRight - scaleInset, height);
				g.setColor(Color.BLACK);
				
				// labels
				boldFont(g);
				g.drawChars(tickLabel(major).toCharArray(), 0, tickLabel(major).length(), 15, height);
				normalFont(g);
				
				// minor ticks, down from the top
				for (int minor = 1; minor < 10;minor++)
				{
					int mHeight = height + (verticalPixels()*minor)/(rounded*10); // increasing y goes downwards
					int tick = shortTick;
					if (minor == 5) tick = (longTick + shortTick)/2;
					g.drawLine(scaleInset - tick, mHeight, scaleInset, mHeight);
				}

			}
		}
		
	}
	
	/**
	 * 
	 * @param major
	 * @param exponent
	 * @return
	 */
	private String tickLabel(int major)
	{
		String label = new Integer(major).toString();
		if (exponent == 0) label = label + ".0";
		else if (exponent == -1) label = label + "0.0";
		else if (exponent == -2) label = label + "00";
		else if (exponent == -3) label = label + "000";
		else if (exponent == 1) label = "0."+ label;
		else if (exponent == 2) label = "0.0"+ label;
		else if (exponent == 3) label = "0.00"+ label;
		else label = label + "*10^" + (- exponent);
		return label;
	}

	// no functionality needed - periods do not apply to disease state days
	protected void drawPeriodMarkers(Graphics g) {}

	// returned value is ignored by drawVerticalAxisTicks
	int verticalTick() {return 50;}

	// wider day interval for disease state charts - fewer days
	int dayInterval() {return dayInterval;}

	// return value not used
	protected int logDecade() {return 0;}

	@Override
	protected void drawPopulationBar(Graphics g) {
		// TODO Auto-generated method stub
		
	}


}
