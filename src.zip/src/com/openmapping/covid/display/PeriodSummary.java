package com.openmapping.covid.display;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import com.openmapping.covid.SimUtil;
import com.openmapping.covid.model.ExposureEvent;
import com.openmapping.covid.model.Factory;
import com.openmapping.covid.model.GroupExposureEvent;
import com.openmapping.covid.model.Period;
import com.openmapping.covid.model.Person;

public class PeriodSummary {
	
	private ResultAnalyser analyser;
	
	private Factory factory;
	
	private Period period;
	
	public int getScenario() {return scenario;}
	private int scenario;
	
	public int getRun() {return run;}
	private int run;
	
	private int lastRunDay;

	private int infectingDays = 30;
	
	/* Outer key = person id, for people who were not infected at the start of the period.
	 * Inner key = disease state. Integer = the first day that person had that state */
	private Hashtable<String,Hashtable<String,Integer>> personStateStarts = new Hashtable<String,Hashtable<String,Integer>>(); 
	
	/* key = person id, for people who were not infected at the start of the period 
	 * ExposureEvents = times that person passed on the infection. */
	private Hashtable<String,Vector<String[]>> passOnInfections = new Hashtable<String,Vector<String[]>>();
	
	/* key = person id, for people who were not infected at the start of the period, and immune at the end of it
	 * Integer = first day that person was infected  */
	private Hashtable<String,int[]> infectedDays = new Hashtable<String,int[]>();
	
	/**
	 * 
	 * @return number of people who were not infected at the start of the period, and immune at the end of it 
	 */
	public int getNumberOfInfectors() {return infectedDays.size();}
	
	//---------------------------------------------------------------------------------------------------------
	//                                       constructor
	//---------------------------------------------------------------------------------------------------------
	

	public PeriodSummary(ResultAnalyser analyser, int scenario, int run, Period period,int lastRunDay)
	{
		this.analyser = analyser;
		this.period = period;
		this.scenario = scenario;
		this.run = run;
		this.lastRunDay = lastRunDay;
		
		factory = analyser.getFactory();
		
		summariseTransmission();
	}
	
	
	/**
	 * 
	 */
	public void summariseTransmission()
	{
		int startDay = period.getStartDay();
		int endDay= period.getEndDay();
		if (lastRunDay < endDay) endDay = lastRunDay;

		// iterate over all people who were not infected at the start of the period
		for (Enumeration<Person> en = factory.getPersons().elements();en.hasMoreElements();)
		{
			Person person = en.nextElement();
			if (person.getDiseaseState(startDay).equals("C"))
			{
				infectedDays.put(person.getId(), person.daysInfectious());
				passOnInfections.put(person.getId(), person.getExposings());
				personStateStarts.put(person.getId(), person.getFirstDayOfState());
			}
		}
	}
	
	//-----------------------------------------------------------------------------------------------------------
	//                                             access methods
	//-----------------------------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param day
	 * @param state
	 * @return the probability that a person who was not infected (state C) at the start of the period
	 * was in some state dayAfterExposed days after they were first exposed (state A)
	 */
	public double getStateProbability(int dayAfterExposed, String state)
	{
		int people = 0;
		int inState = 0;
		// the last day on which a person could have been exposed, in order to be in the sample
		int lastExposableDay = lastRunDay - dayAfterExposed;
		
		for (Enumeration<String> en = personStateStarts.keys(); en.hasMoreElements();)
		{
			String pid = en.nextElement();
			Hashtable<String, Integer> stateStarts = personStateStarts.get(pid);
			Integer exposedDay = stateStarts.get("A");

			//check if the person is eligible to be in the sample
			if ((exposedDay != null) && (exposedDay.intValue() < lastExposableDay))
			{
				people++;
				int day = exposedDay.intValue() + dayAfterExposed;
				String theState = stateOnDay(day,stateStarts);
				if (state.equals(theState)) inState++;
			}
		}
		
		double prob = 0.0;
		if (people > 0) prob = new Double(inState).doubleValue()/new Double(people).doubleValue();
		return prob;
	}
	
	/**
	 * 
	 * @param day
	 * @param stateStarts
	 * @return a state which started before a day - the last such state
	 */
	private String stateOnDay(int day, Hashtable<String, Integer> stateStarts)
	{
		String state = null;
		int lastStartDay = -1;
		
		for (Enumeration<String> en = stateStarts.keys(); en.hasMoreElements();)
		{
			String st = en.nextElement();
			int startDay = stateStarts.get(st).intValue();
			if ((startDay < day) && (startDay > lastStartDay))
			{
				lastStartDay = startDay;
				state = st;
			}
		}
		
		return state;
	}
	
	/**
	 * 
	 * @return histogram of pass-on infections by all infectors, by day after the infector was infected
	 */
	public int[] passOnDelays()
	{
		int[] delay = new int[infectingDays];
		for (int d = 0; d < infectingDays; d++) delay[d] = 0;
		
		// iterate over eligible people who might have infected someone
		for (Enumeration<String> en = infectedDays.keys();en.hasMoreElements();)
		{
			String pid = en.nextElement();
			int[] iDay = infectedDays.get(pid);
			
			for (String[] eventSummary: passOnInfections.get(pid))
			{
				ExposureEvent event = ExposureEvent.makeExposureEvent(eventSummary, factory);
				if (event instanceof GroupExposureEvent)
				{
					int dayPassOn = event.getDay();
					int dayOfDis = dayPassOn - iDay[0];
					if ((dayOfDis < infectingDays) && (dayOfDis > -1))
						delay[dayOfDis]++;
				}
			}
		}
		
		return delay;
	}
	
	/**
	 * for all people who were not infected at the start of the period, and immune by the end, 
	 * write histograms of :
	 * 
	 * (a) the number of people they each exposed to the disease in public places
	 * (b) the first day after their own infection on which they infected someone
	 * (c) the last day after their own infection on which they infected someone
	 * (d) the span of days over which they infected other people
	 * (e) the span of days over which they could have infected other people
	 */
	public void writeInfectorHistogram() throws Exception
	{
		int[][] publicExpo = new int[30][5];
		for (int i = 0; i < publicExpo.length; i++) 
			for (int m = 0; m < 5 ; m++)
				publicExpo[i][m] = 0;

		int infections = 0;
		int potentialDays = 0;
		for (Enumeration<String> en = passOnInfections.keys();en.hasMoreElements();)
		{
			String pid = en.nextElement();
			Vector<String[]> passOns = passOnInfections.get(pid);
			int[] dayInfected  = infectedDays.get(pid);

			int[] publicPassOns = getPublic(passOns,dayInfected);
			for (int m = 0; m < 5; m++)
			{
				int bar = publicPassOns[m]; // bar of histogram to build up
				if (bar < 30) publicExpo[bar][m]++;
			}
			infections = infections + publicPassOns[0];
			potentialDays = potentialDays + publicPassOns[4];
		}
		double infectionsPerPerson = new Double(infections).doubleValue()/passOnInfections.size();
		double potentialDaysPerPerson = new Double(potentialDays).doubleValue()/passOnInfections.size();
		
		SimUtil.message("\nHistogram of infectors for scenario " + scenario + ", period " + period.getLabel()
				+ "\n" +  passOnInfections.size() + " infectors; " + potentialDays
				+ " potential days; " + potentialDaysPerPerson + " potential days per infector\n"
				+ infections  + " infections; "  + infectionsPerPerson + " infections  per infector: ");
		String[] row = {"Number infected,", "First day,","Last day,","Actual span,","Possible span,"};
		for (int m = 0; m < 5; m++)
		{
			for (int i = 0; i < publicExpo.length; i++) 
				row[m] = row[m] + publicExpo[i][m] + ",";
			SimUtil.message(row[m]);
		}
		
			
	}
	
	/**
	 * 
	 * @param passOns
	 * @return for one person:
	 * (a) the number of people they exposed to the disease in public places
	 * (b) the first day after their own infection on which they infected someone
	 * (c) the last day after their own infection on which they infected someone
	 * (d) the span of days over which they infected other people

	 */
	private int[] getPublic(Vector<String[]> passOns, int[] dayInfected) throws Exception
	{
		int[] pub= new int[5];
		for (int m = 0; m < 5; m++) pub[m] = 0;
		int firstDay = 1000;
		int lastDay = 0;

		//go over all the events where  this peron infected someone else in a public place
		for (String[] passOn: passOns) if (passOn.length == 4) 
		{
			pub[0]++;
			// days after their own infection at which they infected someone else
			int dayPassOn = new Integer(passOn[0]).intValue() - dayInfected[0];
			if (dayPassOn < firstDay) firstDay = dayPassOn;
			if (dayPassOn > lastDay) lastDay = dayPassOn;
		}
		
		// if they infected any other people
		if (pub[0] > 0)
		{
			pub[1] = firstDay;
			pub[2] = lastDay;
			pub[3] = lastDay - firstDay;
		}
		// the number of days when they might have infected someone (maybe zero if they were isolated)
		pub[4] = 0;
		if (dayInfected[2]  > -1) pub[4] = dayInfected[2] - dayInfected[1] + 1;
		
		for (int m = 0; m <5; m++) if (pub[m] < 0) Factory.debug("Negative bar");
		
		return pub;
	}

	
	/**
	 * 
	 */
	public void writeTransmission()
	{
		SimUtil.message("\nInfection delays for scenario " + period.getScenarioIndex() + " period " + period.getPeriodIndex());
		SimUtil.message("Day,Infections");
		int[] delays  = passOnDelays();
		int infections = 0;
		for (int d = 0; d < infectingDays; d++)
		{
			infections = infections + delays[d];
			SimUtil.message(d + "," + delays[d]);
		}
		
		int infectors = infectedDays.size();
		double r = new Double(infections).doubleValue()/new Double(infectors).doubleValue();
		SimUtil.message("\nInfectors:" + infectors + "\tR: " + r);
	}

}
