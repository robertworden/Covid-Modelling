package com.openmapping.covid.display;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Panel;
import java.util.Vector;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;

public class TableHolder extends Panel{
	
	private int x;
	private int y;
	private int width;
	private int height;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TableHolder(int x, int y, int width, int height)
	{
		super();
		setBounds(x,y,width,height);
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		
		// empty text area to show where  tables will go.
		JTextArea empty = new JTextArea();
		empty.setBounds(0,0,width, height);
		empty.setBackground(Color.WHITE);
		add(empty);
	}
	
	/**
	 * 
	 * @param tableData
	 */
	public void showTable(Vector<String[]> tableData)
	{
		int rows = tableData.size() - 1;
		int cols = tableData.get(0).length;
		
		Object[] header = new Object[cols];
		for (int c = 0; c < cols; c++) header[c] = tableData.get(0)[c];
		
		Object[][] content = new Object[rows][cols];
		for (int r = 0; r < rows; r++)
			for (int c = 0; c < cols; c++) 
				content[r][c] = tableData.get(r+1)[c];
		
		JTable table = new JTable(content,header);
		table.setBounds(0,0,width,height);
        table.setPreferredScrollableViewportSize(new Dimension(width, height));
        table.setFillsViewportHeight(true);

		
		// remove previous table, if there is any
		removeAll();
		
        //add the table to the frame
		// add(table);
        add(new JScrollPane(table));
        
        validate();
        table.setVisible(true);
        setVisible(true);

	}

}
