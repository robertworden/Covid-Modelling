package com.openmapping.covid.display;

public interface Filterable {
	
	/**
	 * a key which defines the model object uniquely, so it can be put in a hashtable for filtering
	 * @return
	 */
	public String getFilterKey();
	
	/**
	 * 
	 * @param filterIndex
	 * @return the value that is returned, for different types of comparison
	 * throw an exception if this comparison is not appropriate for this kind of object
	 */
	public String getFilterValue(DaySummary daySummary, int filterType) throws Exception;

}
