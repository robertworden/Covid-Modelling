package com.openmapping.covid.display;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.Timer;

import com.openmapping.covid.SimUtil;
import com.openmapping.covid.WeightReader;
import com.openmapping.covid.cMain;
import com.openmapping.covid.model.Factory;
import com.openmapping.covid.model.Region;

public class ViewFrame extends JFrame implements ActionListener{
	
	private Timer tm;
	
	private int frameWidth = 1650;
	private int frameDepth = 900;
	private int screenInset = 50;
	
	// maximum number of tabs in the UI
	public static int nTabs = 8;
	
	// maximum number of plots in one tab
	public static int maxPlots = 4;
	
	// maximum number of menu choices for a tab
	public static int maxChoices = 6;
	
	public void setFactory(Factory factory) {this.factory = factory;}
	public Factory getFactory() {return factory;}
	private Factory factory;
	
	public void setReader(WeightReader reader) {this.reader = reader;}
	public WeightReader getReader() {return reader;}
	private WeightReader reader;
	
	public cMain getMain() {return main;}
	private cMain main;
		
	public  void setAnalyser(ResultAnalyser analyser) {this.analyser = analyser;}
	private ResultAnalyser analyser;
	
	private static final long serialVersionUID = 1L;
	
	// spinners
	public JSpinner getDaySpinner() {return daySpinner;}
	private JSpinner daySpinner;
	public JSpinner getZoomSpinner() {return zoomSpinner;}
	private JSpinner zoomSpinner;
	
	public JSlider[] getPanZoomSlider() {return panZoomSlider;}
	private JSlider[] panZoomSlider = new JSlider[3];
	
	protected JButton[][] buttonArray = new JButton[nTabs][12];
	protected String[][] buttonLabel = 
		    {{"Make Model","Read Model","Run Model","Add Plot","Remove Plot"},
			{"Add Plot","Remove Plot"},
			{"Add Calculated","Add Simulated","Remove Plot",""},
			{"","","",""},
			{"","","",""},
			{"Show People","Show Venues","Show Events","Remove"},
			{"Import","Polygons","Export",""},
			{"","","",""}};
	
	/**
	 * buttons are denoted by {tab #,button #}.
	 * the first {x,y} is the enabling button; the following {x,y} are the buttons it enables
	 */
	protected int[][][] enablers = {
		{{0,1},{0,2},{2,0},{5,1}},  // you must read a model before you run it; and before you plot disease states or map venues
		{{0,2},{0,3},{1,0},{2,1},{5,0},{5,2}}, // you must run a model before various other plots and maps
		{{6,0},{6,1},{6,2}} // you must import a map before you can calculate polygons or export it
	};
	
	// positions of buttons for all tabbed panes  
	  private int buttonTop = 100;
	  private int buttonLeft = 30;
	  private int buttonVerticalSpace = 60; // vertical space between buttons
	  private int buttonHeight = 30;
	  private int buttonWidth = 120;

	  public JComboBox<String>[][] getDropDown() {return dropDown;}
	  protected JComboBox<String>[][] dropDown = new JComboBox[nTabs][maxChoices];
	  protected String[][] comboLabel = {
			  {"Scenario","Disease State","Age Range","Colour","Style"}, // person states tab
			  {"Scenario","Venue","Region","Colour","Style"},  // exposure events tab
			  {"Scenario/Period","Disease State","Venue","Colour","Style"}, // disease states
			  {"Folder","File"}, // person data
			  {"Demographic Data File"}, // demographic data
			  {"Scenario","Disease State","Venue","Colour","Symbol"}, // map view
			  {"Map Type","Resolution"},
			  {"",""},
			  };
	int comboBoxIndex = 0;
	
	/// for each button of each tab , defines which label parts (combo box choices) are used in the labels. 0 if no label needed
	public static int[][] useLabelParts = {
			{0,0,0,12,0}, // person states tab
			{123,0}, // exposure events tab
			{2,123,0},  // disease model tab
			{0}, // simulation data tab
			{0}, // demographic data tab
			{12,3,0,0,0},// map view tab
			{0}}; // capture maps tab
	
	private int comboTop = 40;
	private int comboRight = 1300; // left end of the right hand column of combo boxes (colour and style)
	private int comboHorizontalSpace = 200; // horizontal space between combo menus
	private int comboHeight = 30;
	private int comboWidth = 150;
	
	public static int TOP_ROW = 0; // top row of combo boxes
	public static int RIGHT_COL= 1; // right hand column of combo boxes (colour and style)
	public static int LEFT_COL= 2; // right hand column of combo boxes (colour and style)
	
	// coordinates of the graph area for people states and events  
	private int gridTop = 100;
	private int gridLeft = 200;
	private int gridWidth = 1000;
	private int gridDepth = 600;
	
	// tab labels for tabbed panes
	final static String PERSON_STATES = "Person States";
	final static String EXPOSURE_EVENTS = "Exposure Events";
	final static String DISEASE_MODEL = "Disease Model";
	final static String SIMULATION_DATA = "Simulation Data";
	final static String POPULATION_MODEL = "Population Model";
	final static String MAP_VIEW = "Map View";
	final static String CAPTURE_MAP = "Capture Maps";

	public TableHolder getPersonTable() {return personTable;}
	private TableHolder personTable;
	
	public TableHolder getDemographicTable() {return demographicTable;}
	private TableHolder demographicTable;
	
	private Plot[][] plot = new Plot[nTabs][maxPlots];
	public void setPlot(int tab, int plotNo, Plot newPlot) {plot[tab][plotNo] = newPlot;}
	public Plot getPlot(int tab, int plotNo) {return plot[tab][plotNo];}
	
	private JTextArea messageBox;
	public void showErrorMessage(String s) 
	{
        messageBox.setForeground(Color.RED);
		messageBox.setText(s);
        messageBox.setForeground(Color.BLACK);
        SimUtil.message(s);
	}
	
	private JTextArea simulationExplanationBox;
	private JTextArea demographicExplanationBox;

	
	public MapCanvas getCaptureMapCanvas() {return captureMapCanvas;}
	private MapCanvas captureMapCanvas;
	
	//-----------------------------------------------------------------------------------------------------------
	//                                          Constructor
	//-----------------------------------------------------------------------------------------------------------

	
	public ViewFrame(cMain main) throws Exception
	{
		this.main = main;
		factory = main.getFactory();
		reader = main.getReader();
		analyser = main.getAnalyser();
		
		tm = new Timer(500,this);
		
		frameSetup();
	}
	
	
	  // set up all the components in the frame
	  private void frameSetup() throws Exception
	  {
		  //set overall properties
		  setTitle("COVID Modelling Framework");
		  setBounds(screenInset, screenInset, frameWidth, frameDepth);
	      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  
		  // add tabbed panes
		  addToPane(getContentPane());		  
	  }
	  
	  /**
	   * 
	   * @param pane
	   */
	  private void addToPane(Container pane) throws Exception
	  {	        
	        // Create the tabbed pane that contains the tabs.
	        JTabbedPane tabbedPane = new JTabbedPane();
	        
	        // seven tabs and counting
	        tabbedPane.addTab(PERSON_STATES, personStatePanel());
	        tabbedPane.addTab(EXPOSURE_EVENTS, exposureEventPanel());
	        tabbedPane.addTab(DISEASE_MODEL,diseaseModelPanel());
	        tabbedPane.addTab(SIMULATION_DATA,simulationDataPanel(3));
	        tabbedPane.addTab(POPULATION_MODEL,simulationDataPanel(4));
	        tabbedPane.addTab(MAP_VIEW,mapView());
	        tabbedPane.addTab(CAPTURE_MAP,captureView());
	        
	        pane.add(tabbedPane, BorderLayout.CENTER);
	        
	  }
	  
	  //--------------------------------------------------------------------------------------------------
	  //                                              All tabs
	  //--------------------------------------------------------------------------------------------------
	  
	  
	 @SuppressWarnings("deprecation")
	private void setButton(JButton button, int tabIndex, int verticalOrder,  int buttonIndex)
	 {
		 button.setBounds(buttonLeft, buttonTop + verticalOrder*buttonVerticalSpace, buttonWidth, buttonHeight);
		 button.setLabel(buttonLabel[tabIndex][buttonIndex]);
		 button.setEnabled(startEnable(tabIndex,buttonIndex));
	      final int action = buttonIndex;
	      final int tab = tabIndex;
	      button.addActionListener(new ActionListener() {
	          public void actionPerformed(ActionEvent e) {
	            main.buttonAction(tab,action);
	            enableButtons(tab,action);
	          }});
	 }
	 
	 /**
	  * any button is initially disabled if it needs any other button to enable it
	  * @param tab
	  * @param buttonIndex
	  * @return
	  */
	 private boolean startEnable(int tab, int buttonIndex)
	 {
		 boolean enable = true;
		 // iterate over buttons that enable any other button
		 for (int b = 0; b < enablers.length; b++)
		 {
			 int[][] enabled = enablers[b];
			 for (int c = 1; c < enabled.length; c++) // the first in the list is the enabling button
			 {
				 int[] oneEnabled = enabled[c];
				 if ((tab == oneEnabled[0]) && (buttonIndex == oneEnabled[1])) enable = false;
			 }
		 }
		 
		 return enable;
	 }
	 
	 /**
	  * 
	  * @param tab
	  * @param action
	  */
	 private void enableButtons(int tab,int action)
	 {
		 for (int b = 0; b < enablers.length; b++)
		 {
			 int[][] enabled = enablers[b];
			 int[] enablerButton = enabled[0];
			 if ((tab == enablerButton[0]) && (action == enablerButton[1])) // if this is the enabling button
			 {
				 for (int c = 1; c < enabled.length; c++) // go over the buttons it enables
				 {
					 int[] oneEnabled = enabled[c];
					 int eTab = oneEnabled[0];
					 int eIndex = oneEnabled[1];
					 buttonArray[eTab][eIndex].setEnabled(true);					 
				 }
			 }
		 }
	 }
	  
	  
	 /**
	  * 
	  * @param combo combo box being set up
	  * @param tabIndex the tab it belongs in
	  * @param order either horizontal order (top row of boxes) or vertical order (right column of boxes)
	  * @param type can be TOP_ROW or RIGHT_COL or LEFT_COL
	  * @param items
	  * @return
	  */
	 private JLabel setCombo(JComboBox<String> combo, int tabIndex, int order, int type, String[] items) throws Exception
	 {
		 dropDown[tabIndex][order] = combo;
		 JLabel label = null;
		 try
		 {
			 final int index = comboBoxIndex;
		      final int tab = tabIndex;
			  label = new JLabel(comboLabel[tabIndex][comboBoxIndex]); 


			 if (type == TOP_ROW)
			 {
				 combo.setBounds(gridLeft + order*comboHorizontalSpace, comboTop, comboWidth, comboHeight);
				 label.setBounds(gridLeft + order*comboHorizontalSpace, comboTop - 30, comboWidth, comboHeight);
				 if (analyser != null) analyser.setLabelPart(tabIndex, order, items[0]);
			 }
			 else if (type == RIGHT_COL)
			 {
				 combo.setBounds(gridLeft + gridWidth + 50, gridTop + order*buttonVerticalSpace, comboWidth, comboHeight);
				 label.setBounds(gridLeft + gridWidth + 50, gridTop + order*buttonVerticalSpace - 30, comboWidth, comboHeight);
			 }
			 else if (type == LEFT_COL)
			 {
				 combo.setBounds(50, gridTop + order*buttonVerticalSpace, comboWidth, comboHeight);
				 label.setBounds(50, gridTop + order*buttonVerticalSpace - 30, comboWidth, comboHeight);
			 }
			 else throw new Exception("Invalid combo positioning type " + type);

		      comboBoxIndex++;
		      for (int i = 0; i < items.length; i++) combo.addItem(items[i]);
		      combo.addActionListener(new ActionListener() {
		          public void actionPerformed(ActionEvent e) {
		            main.comboAction(tab,index, type, combo.getSelectedItem(),combo.getSelectedIndex());
		          }});
		      
		 }
		 catch (Exception ex){SimUtil.message("Combo failure");ex.printStackTrace();}
	      return label;
	 }
	 
	 private String[] scenarioLabels()
	 {
		 String[] label = {""};
		 if (factory != null) // factory is null when the frame is  made just to show error messages, 
		 {
			 label = new String[factory.nScenarios()];
			 for (int i = 0; i < label.length;i++)
				 label[i] = factory.getScenarioName(i);
		 }
		 return label;
	 }
	 
	 /**
	  * set up a spinner in the same top row as the combo boxes
	  * @param spinner
	  * @param tabIndex
	  * @param order
	  * @return
	  */
	 private  JLabel setSpinner(JSpinner spinner,int tabIndex,int order,String labelName)
	 {
		 JLabel label = new JLabel(labelName);

		 spinner.setBounds(gridLeft + order*comboHorizontalSpace, comboTop, comboWidth, comboHeight);
		 label.setBounds(gridLeft + order*comboHorizontalSpace, comboTop - 30, comboWidth, comboHeight);

		 if (analyser != null) analyser.setLabelPart(tabIndex, order, "0");

		 return label;
	 }
 
	 /**
	  * set up a horizontal slider in the same top row as the combo boxes
	  * @param spinner
	  * @param tabIndex
	  * @param order
	  * @return
	  */
	 private  JLabel setSlider(JSlider slider,int tabIndex,int order,String labelName)
	 {
		 JLabel label = new JLabel(labelName);

		 slider.setBounds(gridLeft + order*comboHorizontalSpace, comboTop, comboWidth, comboHeight);
		 label.setBounds(gridLeft + order*comboHorizontalSpace, comboTop - 30, comboWidth, comboHeight);
		 return label;
	 }

	  //--------------------------------------------------------------------------------------------------
	  //                                              Person State tab (front tab)
	  //--------------------------------------------------------------------------------------------------
	 
	 private String[]  ageRanges = {"all","0-39","40-59","60-79","80-99"};
	 
	 private String[]  styles = {"Solid","Dashed","Bar","Line"};

	  /**
	   * 
	   * @return
	   */
	  private JPanel personStatePanel() throws Exception
	  {
		  int tabIndex = 0;
		  comboBoxIndex = 0;
		  
	        JPanel control = new JPanel();
	        control.setLayout(null);
	        
	        // make a population model
	        JButton genButton = new JButton();
	        setButton(genButton,tabIndex,0,0);
	        buttonArray[tabIndex][0] = genButton;
	        control.add(genButton);
	        
	        // read a population model
	        JButton readButton = new JButton();
	        setButton(readButton,tabIndex,1,1);
	        buttonArray[tabIndex][1] = readButton;
	        control.add(readButton);
	        	        	        
	        // run the simulation
	        JButton simButton = new JButton();
	        setButton(simButton,tabIndex,2,2);
	        buttonArray[tabIndex][2] = simButton;
	        control.add(simButton);
	        
	        // add the the stack of plots shown
	        JButton graphButton = new JButton();
	        setButton(graphButton,tabIndex,3,3);
	        buttonArray[tabIndex][3] = graphButton;
	        control.add(graphButton);
	        
	        // remove the top plot shown
	        JButton removeButton = new JButton();
	        setButton(removeButton,tabIndex,4,4);
	        buttonArray[tabIndex][4] = removeButton;
	        control.add(removeButton);
	        
	        // choice of scenarios
	        JComboBox<String> scenarioBox = new JComboBox<String>();
	        control.add(setCombo(scenarioBox,tabIndex,0,0,scenarioLabels()));
	        control.add(scenarioBox);
	        
	        // choice of disease states
	        JComboBox<String> diseaseStateBox = new JComboBox<String>();
	        control.add(setCombo(diseaseStateBox,tabIndex,1,0,diseaseAndSocialStates()));
	        control.add(diseaseStateBox);
	        
	        // choice of age ranges
	        JComboBox<String> PersonBox = new JComboBox<String>();
	        control.add(setCombo(PersonBox,tabIndex,2,0,ageRanges));
	        control.add(PersonBox);

	        // choice of colours
	        JComboBox<String> colourBox = new JComboBox<String>();
	        control.add(setCombo(colourBox,tabIndex,0,1,LogPlot.COLOUR_NAMES));
	        control.add(colourBox);
	        
	        // choice of styles
	        JComboBox<String> styleBox = new JComboBox<String>();
	        control.add(setCombo(styleBox,tabIndex,1,1,styles));
	        control.add(styleBox);

	        plot[tabIndex][0] = new LogPlot(gridLeft,gridTop,gridWidth,gridDepth,this);
	        control.add(plot[tabIndex][0]);
	        
	        messageBox = new JTextArea();
	        int spacing = 20;
	        int errorTop = gridTop + gridDepth + spacing;
	        int errorDepth = 80;
	        messageBox.setBounds(gridLeft, errorTop, gridWidth, errorDepth);
			Font font = new Font("Arial", Font.PLAIN, 24);
	        messageBox.setFont(font);
	        messageBox.setForeground(Color.BLACK);
	        messageBox.setLineWrap(true);
	        messageBox.setWrapStyleWord(true);
	        control.add(messageBox);
	        
	        
	        return control;
		  
	  }
	  
	  private String[] socialStates = {"S:free","S:isolated","S:confined"};
	  
	  /**
	   * 
	   * @return
	   */
	  private String[] diseaseAndSocialStates()
	  {
		  String[] state = {""};
		  if (factory != null) try
		  {
			  Vector<String[]> stateData = reader.getData("States");
			  state = new String[stateData.size() + socialStates.length + 1];// statedData file has a header row

			  // all disease states
			  state[0] = "all";
			  
			  // individual disease states
			  for (int i = 1; i < stateData.size(); i++) // ignore header row
				  state[i] = stateData.get(i)[1];
			  
			  // social states
			  for(int s  = 0; s < socialStates.length; s++) 
				  state[stateData.size() + s] = socialStates[s];
			  
			  // pseudo-state for transmission rate
			  state[stateData.size() + socialStates.length] = "R";
		  }
		  catch (Exception ex) {SimUtil.message("Failed to define disease state menu");}
		  
		  return state;
	  }
	  //--------------------------------------------------------------------------------------------------
	  //                                              Exposure Event tab
	  //--------------------------------------------------------------------------------------------------
	 

	  /**
	   * 
	   * @return
	   */
	  private JPanel exposureEventPanel()  throws Exception
	  {
		  int tabIndex = 1;
		  comboBoxIndex = 0;
	        JPanel exposure = new JPanel();
	        exposure.setLayout(null);
	        	        
	        // add graph of encounter events
	        JButton graphButton = new JButton();
	        setButton(graphButton,tabIndex,0,0);
	        buttonArray[tabIndex][0] = graphButton;
	        exposure.add(graphButton);
	        
	        // remove top graph of encounter events
	        JButton removeButton = new JButton();
	        setButton(removeButton,tabIndex,1,1);
	        buttonArray[tabIndex][1] = removeButton;
	        exposure.add(removeButton);
	        
	        // choice of scenarios
	        JComboBox<String> scenarioBox = new JComboBox<String>();
	        exposure.add(setCombo(scenarioBox,tabIndex,0,0,scenarioLabels()));
	        exposure.add(scenarioBox);
	        	        
	        // choice of venues (group types)
	        JComboBox<String> venueBox = new JComboBox<String>();
	        exposure.add(setCombo(venueBox,tabIndex,1,0,groupTypes()));
	        exposure.add(venueBox);
	        
	        // choice of Region
	        JComboBox<String> regionBox = new JComboBox<String>();
	        exposure.add(setCombo(regionBox,tabIndex,2,0,regionNames()));
	        exposure.add(regionBox);
	        
	        // colour of plot
	        JComboBox<String> colourBox = new JComboBox<String>();
	        exposure.add(setCombo(colourBox,tabIndex,0,1,LogPlot.COLOUR_NAMES));
	        exposure.add(colourBox);
	        
	        // style of bars
	        JComboBox<String> styleBox = new JComboBox<String>();
	        exposure.add(setCombo(styleBox,tabIndex,1,1,styles));
	        exposure.add(styleBox);

	        plot[tabIndex][0] = new LogPlot(gridLeft,gridTop,gridWidth,gridDepth,this);
	        exposure.add(plot[tabIndex][0]);
	        
	        
	        return exposure;
		  
	  }
	  
	  private String[] groupTypes()
	  {
		  String[] types = {""}; 
		  if (reader != null)
		  {
			  Vector<String[]> typeData = new Vector<String[]>();
			  try {typeData = reader.getData("EncounterGroups");}
			  catch (Exception ex) {ex.printStackTrace();}
			  types = new String[typeData.size() + 2]; // -1 for header; +3 for fixed elements
			  types[0] = "all";
			  types[1] = "home";
			  types[2] = "all public";
			  for (int i = 1; i < typeData.size();i++)
				  types[i+2] = typeData.get(i)[1];
		  }
		  return types;
	  }
	  
	  /**
	   * 
	   * @return
	   */
	  private String[] regionNames()
	  {
		  String[] names = {""};
		  if (factory != null)
		  {
			  Vector<Region> regions = factory.getRegions();
			  names = new String[regions.size() + 1];
			  names[0] = "all";
			  for (int r = 0; r <regions.size(); r++)
			  {
				  Region region = regions.get(r);
				  names[r+1] = region.getName();
			  }
		  }
		  return names;
	  }

	  
	  //--------------------------------------------------------------------------------------------------
	  //                                              Disease model tab
	  //--------------------------------------------------------------------------------------------------
	 

	  /**
	   * 
	   * @return
	   */
	  private JPanel diseaseModelPanel()  throws Exception
	  {
		  int tabIndex = 2;
		  comboBoxIndex = 0;
		  
	        JPanel diseaseModel = new JPanel();
	        diseaseModel.setLayout(null);
	        
	        // add graph of theoretical R values
	        JButton calculateButton = new JButton();
	        setButton(calculateButton,tabIndex,0,0);
	        buttonArray[tabIndex][0] = calculateButton;
	        diseaseModel.add(calculateButton);
	        
	        // add graph of R values from simulation
	        JButton simulationResultButton = new JButton();
	        setButton(simulationResultButton,tabIndex,1,1);
	        buttonArray[tabIndex][1] = simulationResultButton;
	        diseaseModel.add(simulationResultButton);
	        
	        // remove top graph 
	        JButton removeButton = new JButton();
	        setButton(removeButton,tabIndex,2,2);
	        buttonArray[tabIndex][2] = removeButton;
	        diseaseModel.add(removeButton);
	        
	     	// choice of scenario and period
	        JComboBox<String> scenarioBox = new JComboBox<String>();
	        diseaseModel.add(setCombo(scenarioBox,tabIndex,0,0,scenariosAndPeriods()));
	        diseaseModel.add(scenarioBox);
	        
	        // choice of disease states
	        JComboBox<String> diseaseStateBox = new JComboBox<String>();
	        diseaseModel.add(setCombo(diseaseStateBox,tabIndex,1,0,diseaseAndSocialStates()));
	        diseaseModel.add(diseaseStateBox);
	        
	        // choice of venues
	        JComboBox<String> venueBox = new JComboBox<String>();
	        diseaseModel.add(setCombo(venueBox,tabIndex,2,0,groupTypes()));
	        diseaseModel.add(venueBox);
	        
	        // colour of plot
	        JComboBox<String> colourBox = new JComboBox<String>();
	        diseaseModel.add(setCombo(colourBox,tabIndex,0,1,LogPlot.COLOUR_NAMES));
	        diseaseModel.add(colourBox);
	        
	        // style of bars
	        JComboBox<String> styleBox = new JComboBox<String>();
	        diseaseModel.add(setCombo(styleBox,tabIndex,1,1,styles));
	        diseaseModel.add(styleBox);

	        
	        plot[tabIndex][0] = new LinearPlot(gridLeft,gridTop,1000,300,this);
	        diseaseModel.add(plot[tabIndex][0]);
	        
	        plot[tabIndex][1] = new GraphPlot(gridLeft,450,1000,350,this);
	        diseaseModel.add(plot[tabIndex][1]);
	        	        
	        return diseaseModel;
		  
	  }
	  
	  private String[] scenariosAndPeriods()
	  {
		  String[] res = {""};
		  if (factory != null)
		  {
			  Vector<String> sp = new Vector<String>();
			  for (int s = 0; s < factory.nScenarios();s++)
			  {
				  String sName = factory.getScenarioName(s);
				  for (int p = 0; p< factory.nPeriods(s); p++)
				  {
					  String pName  = factory.getPeriod(s,p).getLabel();
					  String spName = sName + "," + pName;
					  sp.add(spName);
				  }
			  }
			  
			  res = new String[sp.size()];
			  for (int i = 0; i < sp.size(); i++) res[i] = sp.get(i);
		  }
		  return res;
	  }
	  
	  //--------------------------------------------------------------------------------------------------
	  //                               Simulation data  and demographic data tabs
	  //--------------------------------------------------------------------------------------------------
	 	  	  
	  private String[] empty = {"empty"};
	  
	  private String[] demographicFiles = {"households","persons","groups","dayEncounterSets"};

	  /**
	   * 
	   * @return
	   */
	  private JPanel simulationDataPanel(int tabIndex) throws Exception
	  {
		   comboBoxIndex = 0;
		   
	        JPanel simulationData = new JPanel();
	        simulationData.setLayout(null);
	        
	        int tableTop  = 100;
	        int tableLeft = 250;
	        int tableWidth = 1200;
	        int tableDepth = 300;
	        
	        JTextArea explanationBox = new JTextArea();
	        int spacing = 20;
	        explanationBox.setBounds(tableLeft, tableTop + tableDepth + 50, tableWidth, 350);
			Font font = new Font("Arial", Font.PLAIN, 16);
			explanationBox.setFont(font);
			explanationBox.setForeground(Color.BLACK);
			explanationBox.setLineWrap(true);
			explanationBox.setWrapStyleWord(true);
			// need to add scrolling
			simulationData.add(explanationBox);


	        if (tabIndex == 3)
	        {
		        JComboBox<String> folderChoice = new JComboBox<String>();
		        simulationData.add(setCombo(folderChoice,tabIndex,0,LEFT_COL,WeightReader.subFolderNames));
		        simulationData.add(folderChoice);

		        JComboBox<String> fileChoice = new JComboBox<String>();
		        simulationData.add(setCombo(fileChoice,tabIndex,1,LEFT_COL,empty));
		        simulationData.add(fileChoice);
		        
		        personTable = new TableHolder(tableLeft,tableTop,tableWidth,tableDepth);
		        simulationData.add(personTable);
		        
		        simulationExplanationBox = explanationBox;
	        }
	        	        	        
	        else if (tabIndex == 4)
	        {
		        JComboBox<String> fileChoice = new JComboBox<String>();
		        simulationData.add(setCombo(fileChoice,tabIndex,0,LEFT_COL,demographicFiles));
		        simulationData.add(fileChoice);
		        
		        demographicTable = new TableHolder(tableLeft,tableTop,tableWidth,tableDepth);
		        simulationData.add(demographicTable);
		        
		        demographicExplanationBox = explanationBox;
		        }
	        
	        
	        return simulationData;
		  
	  }
	  
	  /**
	   * 
	   * @param explanation
	   */
	  public void setExplanation(Vector<String> explanation,int tab)
	  {
		  String text = "";
		  if (explanation != null) for (String para: explanation)
			  text = text + para + "\n\n";
		  if (tab == 3)  simulationExplanationBox.setText(text);
		  if (tab == 4)  demographicExplanationBox.setText(text);
	  }
	  
	  
	  //--------------------------------------------------------------------------------------------------
	  //                                              Map tab
	  //--------------------------------------------------------------------------------------------------

	  private String[] symbols = {"Circle","Square","Triangle","Cross"};

	  /**
	   * 
	   * @return
	   */
	  private JPanel mapView()  throws Exception
	  {
		  int tabIndex= 5;
		  comboBoxIndex = 0;
		  
	        JPanel mapView = new JPanel();
	        mapView.setLayout(null);
	        	        
	        // show people
	        JButton addPeopleButton = new JButton();
	        setButton(addPeopleButton,tabIndex,0,0);
	        buttonArray[tabIndex][0] = addPeopleButton;
	        mapView.add(addPeopleButton);
	        
	        // show venues 
	        JButton showVenueButton = new JButton();
	        setButton(showVenueButton,tabIndex,1,1);
	        buttonArray[tabIndex][1] = showVenueButton;
	        mapView.add(showVenueButton);
	        
	        // show events 
	        JButton showEventButton = new JButton();
	        setButton(showEventButton,tabIndex,2,2);
	        buttonArray[tabIndex][2] = showEventButton;
	        mapView.add(showEventButton);
	        
	        // remove the top set of things 
	        JButton removeButton = new JButton();
	        setButton(removeButton,tabIndex,3,3);
	        buttonArray[tabIndex][3] = removeButton;
	        mapView.add(removeButton);
	        
	     	// choice of scenario
	        JComboBox<String> scenarioBox = new JComboBox<String>();
	        mapView.add(setCombo(scenarioBox,tabIndex,0,0,scenarioLabels()));
	        mapView.add(scenarioBox);
	        
	        // choice of disease states
	        JComboBox<String> diseaseStateBox = new JComboBox<String>();
	        mapView.add(setCombo(diseaseStateBox,tabIndex,1,0,diseaseAndSocialStates()));
	        mapView.add(diseaseStateBox);
	        
	        // choice of venues
	        JComboBox<String> venueBox = new JComboBox<String>();
	        mapView.add(setCombo(venueBox,tabIndex,2,0,groupTypes()));
	        mapView.add(venueBox);
	        
	        // spinner for days
	        daySpinner = new JSpinner();
	        mapView.add(setSpinner(daySpinner,tabIndex,3,"Day"));
	        mapView.add(daySpinner);
	        
	        // colour of plot
	        JComboBox<String> colourBox = new JComboBox<String>();
	        mapView.add(setCombo(colourBox,tabIndex,0,1,LogPlot.COLOUR_NAMES));
	        mapView.add(colourBox);
	        
	        // symbols
	        JComboBox<String> symbolBox = new JComboBox<String>();
	        mapView.add(setCombo(symbolBox,tabIndex,1,1,symbols));
	        mapView.add(symbolBox);
	        
	        // map area; 'true' means draw the map regions
	        plot[tabIndex][0] = new MapPlot(gridLeft,100,600,640,40, this,true);
	        mapView.add(plot[tabIndex][0]);
	        
	        return mapView;
		  
	  }
	  
	  
	  //--------------------------------------------------------------------------------------------------
	  //                                        Capturing maps tab
	  //--------------------------------------------------------------------------------------------------
	  
	  public static  String[] mapTypes = {"KML"};
	  
	  private String[] resolutions =  {"1 Km","2 Km","5 Km","10 Km","20 Km","50 Km"};

	  /**
	   * 
	   * @return
	   */
	  private JPanel  captureView()  throws Exception
	  {
		  int tabIndex= 6;
		  comboBoxIndex = 0;
		  
	        JPanel captureView = new JPanel();
	        captureView.setLayout(null);
	        	        
	        // types of map import
	        JComboBox<String> mapType = new JComboBox<String>();
	        captureView.add(setCombo(mapType,tabIndex,0,0,mapTypes));
	        captureView.add(mapType);
	        
	        // resolutions of polygons
	        JComboBox<String> resolution = new JComboBox<String>();
	        captureView.add(setCombo(resolution,tabIndex,1,0,resolutions));
	        captureView.add(resolution);
	        
	        /* zoom spinner
	        zoomSpinner = new JSpinner();
	      captureView.add(setSpinner(daySpinner,tabIndex,2,"Zoom"));
	        captureView.add(daySpinner); */
	        
	        // import a map file
	        JButton importButton = new JButton();
	        setButton(importButton,tabIndex,0,0);
	        buttonArray[tabIndex][0] = importButton;
	        captureView.add(importButton);
	        
	        // make polygons
	        JButton polygonButton = new JButton();
	        setButton(polygonButton,tabIndex,1,1);
	        buttonArray[tabIndex][1] = polygonButton;
	        captureView.add(polygonButton);	        

	        // export a polygon file
	        JButton exportButton = new JButton();
	        setButton(exportButton,tabIndex,2,2);
	        buttonArray[tabIndex][2] = exportButton;
	        captureView.add(exportButton);
	        
	        // zoom slider
	        panZoomSlider[0] = new JSlider(0,20,10);
		    captureView.add(setSlider(panZoomSlider[0],tabIndex,2,"Zoom"));

		    // horizontal pan slider
	        panZoomSlider[1] = new JSlider(0,100,50);
	        panZoomSlider[1].setBounds(gridLeft, 750, 600, 60);

	        // vertical pan slider
	        panZoomSlider[2] = new JSlider(JSlider.VERTICAL,0,100,50);
	        panZoomSlider[2].setBounds(gridLeft + 600, 100, 60, 600);
	        for (int i = 0; i< 3; i++) captureView.add(panZoomSlider[i]);
	        
	        // direct subclass of Canvas
	        captureMapCanvas = new MapCanvas(this,gridLeft,100,600,640);
	        captureView.add(captureMapCanvas);
	        
	        // MapCapturePlot thePlot = new MapCapturePlot(gridLeft,100,600,640,mapCanvas); // JScrollPane is bizarre
	        
	        return captureView;

	  }
		  
	  
	  //--------------------------------------------------------------------------------------------------
	  //                                  Odds and ends
	  //--------------------------------------------------------------------------------------------------

	  
	  
	  
	  
	  
	  
	@Override
	public void actionPerformed(ActionEvent arg0) {
		repaint();	}
	

	  
}
