package com.openmapping.covid.captureData;

import java.util.StringTokenizer;
import java.util.Vector;

import org.w3c.dom.Element;

import com.openmapping.covid.SimUtil;

public class RegionKML {
	
	public static double latitudeToKm = 110.574;
	public static double longitudeToKm = 111.32; // multiply by cos(latitude)
	
	public static int ID = 0;
	public static int LONG_ID = 1;
	public static int NAME = 2;
	public static int UNUSED = 3;
	public static int EASTING = 4;
	public static int NORTHING = 5;
	public static int LONGITUDE = 6;
	public static int LATITUDE = 7;
	public static int AREA = 8;
	public static int LENGTH = 9;
	
	public static String[] fieldCode = 
		{"objectid","ctyua16cd","ctyua16nm","ctyua16nmw","bng_e","bng_n",
				"long","lat","st_area(shape)","st_length(shape)"};
	
	private String[] simpleData = new String[10];
	
	public String getId() {return simpleData[ID];}
	
	public String getLongId() {return simpleData[LONG_ID];}
	
	public String getName() {return simpleData[NAME];}
	
	public double getArea() {return new Double(simpleData[AREA]).doubleValue();}
	
	// longitude from summary data
	public double getLongitude() {return new Double(simpleData[LONGITUDE]).doubleValue();}
	
	// latitude from summary data
	public double getLatitude() {return new Double(simpleData[LATITUDE]).doubleValue();}
	
	// raw polygon data to very fine resolution
	private Vector<double[]> fullPolygon = new Vector<double[]>();
	
	// number of sides in raw data polygon
	public int getFullSides() {return fullPolygon.size();}
	
	// polygon on a grid with a while number of kilometres
	private Vector<double[]> kmPolygon = new Vector<double[]>();
	
	// number of sides in the kilometre polygon
	public int getKmSides() {return kmPolygon.size();}
	
	// scale of the grid for the kilometre polygon
	public int getScale() {return scale;}
	private int scale = 5;
	
	// polygon on a km grid, with all points normalised into the range 0..100.0 with a biit to spare
	public Vector<double[]> getNormalPolygon() {return normalPolygon;}
	private Vector<double[]> normalPolygon = new Vector<double[]>();


    /**
     * @return smallest and largest E-W values in the kilometre grid
     */
	public double[] getEWBound(){return ewBound;}
    private double[] ewBound = new double[2];
    
    /**
     * @return smallest and largest N-S values in the kilometre grid
     */
	public double[] getNSBound(){return nsBound;}
    private double[] nsBound = new double[2];
    
    /**
     * 
     * @return
     */
    public int getPopulation() {return population;}
    public void setPopulation(int population) {this.population = population;}
    private int population= 0;
    
    /**
     * population density, normalised to make it usually above 1 for England
     * @return
     */
    public  double getPopulationDensity() {return 10000.0*(new Double(population).doubleValue())/getArea();}


	
	//-------------------------------------------------------------------------------------------
	//                                 Constructor
	//-------------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param placeMark
	 * @throws Exception
	 */
	public RegionKML(Element placeMark) throws Exception
	{
		Element briefData = SimUtil.firstNamedChild(placeMark, "ExtendedData");
		if (briefData == null) throw new Exception("ExtendedData element");
		Element polygon = SimUtil.firstNamedChild(placeMark, "Polygon");
		if (polygon == null)  // occasional variant - Norfolk, Cornwall,...
		{
			Element multiGeometry = SimUtil.firstNamedChild(placeMark, "MultiGeometry");
			polygon = SimUtil.firstNamedChild(multiGeometry, "Polygon");
		}			
		if (polygon == null) throw new Exception("No Polygon element");
		
		// set absurd limits to improve
		ewBound[0] = 10000.0;
		ewBound[1] = -10000.0;
		nsBound[0] = 10000.0;
		nsBound[1] = -10000.0;
		
		setBasicData(briefData);
		
		setFullPolygon(polygon);
		
		setKmPolygon();
	}
	
	
	/**
	 * read summary data for each region
	 * @param briefData
	 * @throws Exception
	 */
	private void setBasicData(Element briefData) throws Exception
	{
		Element schemaData = SimUtil.firstNamedChild(briefData, "SchemaData");
		if (schemaData == null) throw new Exception("No SchemaData element");
		Vector<Element> simpleBits = SimUtil.namedChildElements(schemaData, "SimpleData");
		if (simpleBits.size() < 10) throw new Exception("Only " + simpleBits.size() + " simpleData elements");
		
		for (Element simple: simpleBits)
		{
			for (int i = 0; i < 10; i++)
			{
				String attName = fieldCode[i];
				if (simple.getAttribute("name").equals(attName)) simpleData[i] = SimUtil.getText(simple);
			}
		}
	}
	
	/**
	 * 
	 * @param briefData
	 * @throws Exception
	 */
	private void setFullPolygon(Element polygon) throws Exception
	{
		Element outerBoundary = SimUtil.firstNamedChild(polygon, "outerBoundaryIs");
		if (outerBoundary == null) throw new Exception("No outerBoundary element");
		Element linearRing = SimUtil.firstNamedChild(outerBoundary, "LinearRing");
		if (linearRing == null) throw new Exception("No LinearRing element");
		Element coordinates = SimUtil.firstNamedChild(linearRing, "coordinates");
		if (coordinates == null) throw new Exception("No coordinates element");
		
		String coords = SimUtil.getText(coordinates);
		StringTokenizer st = new StringTokenizer(coords," ");
		while (st.hasMoreTokens())
		{
			String coord = st.nextToken();
			StringTokenizer su = new StringTokenizer(coord,",");
			if (su.countTokens() != 2) throw new Exception("Wrong dimensions " + su.countTokens());
			double[] point = new double[2];
			int i = 0;
			while (su.hasMoreTokens())
			{
				point[i] = new Double(su.nextToken()).doubleValue();
				i++;
			}
			fullPolygon.add(point);			
		}		
	}
	
	/**
	 * 
	 */
	private void setKmPolygon()
	{
		double[] previousKm= new double[2];	
		previousKm = latLongToKm(fullPolygon.get(0));
		double[] km= new double[2];		

		for (int p = 1; p < fullPolygon.size(); p++)
		{
			double[] point = fullPolygon.get(p);
			km = latLongToKm(point);
			if (crossesLine(previousKm,km,scale))
			{
				kmPolygon.add(km);
				updateBounds(km);
			}
			previousKm = km;
		}
		kmPolygon.add(kmPolygon.get(0));
	}
	
	/**
	 * if the line between  previousKm and km crosses a kilometre line, return true
	 * @param previousKm
	 * @param km
	 * @return
	 */
	public static boolean crossesLine(double[] previousKm,double[] km, int scale)
	{
		boolean crosses = false;		
		for (int i = 0; i < 2; i++)
		{
			int prev = (int)(previousKm[i]/scale);
			int now = (int)(km[i]/scale);
			if (prev != now) crosses = true;
		}
		
		return crosses;
	}
	
	
	/**
	 * 
	 * @param latLong
	 * @return
	 */
	public static double[] latLongToKm(double[] latLong)
	{
		double[] km= new double[2];		
		km[0] = latLong[0]*longitudeToKm*Math.cos(latLong[1]*Math.PI/180.0);
		km[1] = latLong[1]*latitudeToKm;
		return km;
	}


	/**
	 * 
	 * @param km
	 */
	private void updateBounds(double[] km)
	{
		if (km[0] > ewBound[1]) ewBound[1] = km[0]; // move ewBound[1] up from -10000.0, to make it as positive as possible
		if (km[0] < ewBound[0]) ewBound[0] = km[0]; // move ewBound[0] down from 10000.0

		if (km[1] > nsBound[1]) nsBound[1] = km[1]; // move nsBound[1] up from -10000.0 to make it as + as possible
		if (km[1] < nsBound[0]) nsBound[0] = km[1]; // move nsBound[0] down from 10000.0 to make it as - as possible
	}
	
	// set a scale so all northings and eastings will fit in a range 5..95
	// eastings  x are all between xmin = ewBound[0] and xmax = ewBound[1]
	// x' = 50 + scale*(x - x0)  
	// x'min = 50 + scale*(xmin - x0) = 5
	// x'max = 50 + scale*(xmax - x0) = 95
	// x'max - x'min = scale*(xmax - xmin) = 90
	// scale = 90/(xmax - xmin)
	// then (xmax - x0)= 45/scale; x0 = xmax - 45/scale
	// choose the smaller scale from x  and y directions
	/**
	 * normalise all points in all km polygons to fit into (5..95) (5..95)
	 * @param ewBound
	 * @param nsBound
	 */
	public void setNormalPolygon(double[] ewBound, double[] nsBound)
	{
		double scaleX = 90.0/(ewBound[1] - ewBound[0]);
		double  x0 = ewBound[1] - 45.0/scaleX;

		double scaleY = 90.0/(nsBound[1] - nsBound[0]);
		double  y0 = nsBound[1] - 45.0/scaleY;

		// make scaleX the smaller of the two scales and use it
		if (scaleY < scaleX) scaleX = scaleY;
		
		// apply x' = 50 + scale*(x - x0) and y' = 50 + scale*(y - y0) to all points in the polygon
		normalPolygon = new Vector<double[]>();
		for (int p = 0; p < kmPolygon.size();p++)
		{
			double[] km = kmPolygon.get(p);
			double[] normal = new double[2];
			normal[0] = 50.0 + scaleX*(km[0] - x0);
			normal[1] = 50.0 + scaleX*(km[1] - y0);
			
			normalPolygon.add(normal);
		}
	}

}
