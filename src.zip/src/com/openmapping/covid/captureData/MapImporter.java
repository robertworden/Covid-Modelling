package com.openmapping.covid.captureData;

import java.awt.Component;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.w3c.dom.Element;

import com.openmapping.covid.SimUtil;
import com.openmapping.covid.cMain;
import com.openmapping.covid.display.MapCanvas;
import com.openmapping.covid.display.ViewFrame;
import com.openmapping.covid.model.Factory;

public class MapImporter {
	
	private cMain main;
	
	private int resolutionKm;
	
	private String mapType;
	public void setMapType(String type) {mapType = type;}
	
	private JFileChooser polygonFileChooser;
	private JFileChooser populationFileChooser;
	private JFileChooser exportFileChooser;
	
	private Vector<RegionKML> regionDefs = new Vector<RegionKML>();
	
	private Hashtable<String,RegionKML> regionsById = new Hashtable<String,RegionKML>();
	
	private File polygonFile;
	private File populationFile;
	
    private double[] ewBound = new double[2];
    private double[] nsBound = new double[2];

	
	//--------------------------------------------------------------------------------------------------------
	//                                   Constructor
	//--------------------------------------------------------------------------------------------------------
	
	public MapImporter(cMain main)
	{
		this.main = main;
		mapType = ViewFrame.mapTypes[0]; // "KML"
		
		
		ewBound[0] = 10000.0;
		ewBound[1] = -10000.0;
		nsBound[0] = 10000.0;
		nsBound[1] = -10000.0;

	}
	
	public void setResolution(String resKm) throws Exception
	{
		StringTokenizer st = new StringTokenizer(resKm," ");
		resolutionKm = SimUtil.makeInteger(st.nextToken());
	}
	
	/**
	 * 
	 * @param parent
	 * @throws Exception
	 */
	public void chooseImportFile(Component parent) throws Exception
	{
		// read in KML polygon file
		polygonFileChooser = new JFileChooser();
		polygonFileChooser.setDialogTitle("Choose KML file of boundary polygons");
		   FileNameExtensionFilter filter = new FileNameExtensionFilter("kml","kml");
		   polygonFileChooser.setFileFilter(filter);
			    int returnVal = polygonFileChooser.showOpenDialog(parent);
			    if (returnVal == JFileChooser.APPROVE_OPTION) 
			    {
			    	polygonFile = polygonFileChooser.getSelectedFile();
			    	if (mapType.equals("KML")) readKMLFile();
			    }
			    
			    
	// read in CSV population file
	{
		populationFileChooser = new JFileChooser();
		populationFileChooser.setDialogTitle("Choose CSV file of region populations");
		   filter = new FileNameExtensionFilter("csv","csv");
		   populationFileChooser.setFileFilter(filter);
			    returnVal = populationFileChooser.showOpenDialog(parent);
			    if (returnVal == JFileChooser.APPROVE_OPTION) 
			    {
			    	populationFile = populationFileChooser.getSelectedFile();
			    	readPopulations();
			    }
	}
	
	}
	
	/**
	 * 
	 * @throws Exception
	 */
	private void readKMLFile() throws Exception
	{
		FileInputStream stream = new FileInputStream(polygonFile);
		Element rootElement = SimUtil.getRootElement(stream);
    	Vector<Element> first = SimUtil.childElements(rootElement);
    	Vector<Element> folders = SimUtil.namedChildElements(first.get(0), "Folder");

    	Vector<Element> placeMarks = SimUtil.namedChildElements(folders.get(0), "Placemark");
    	SimUtil.message("PlaceMarks: " + placeMarks.size());
    	
    	regionDefs = new Vector<RegionKML>();
    	
    	// read in each region and produce Km polygons and find upper and lower bounds
    	for (Element mark: placeMarks)
    	{
    		try
    		{
        		RegionKML regData = new RegionKML(mark);
        		regionDefs.add(regData);
        		regionsById.put(regData.getLongId(), regData);

        		// upper E-W value
        		if (regData.getEWBound()[1] > ewBound[1]) ewBound[1] = regData.getEWBound()[1]; // move ewBound[1] up from -10000.0
        		// lower E-W value
        		if (regData.getEWBound()[0] < ewBound[0]) ewBound[0] = regData.getEWBound()[0]; // move ewBound[0] down from 10000.0

        		// upper N-S value
        		if (regData.getNSBound()[1] > nsBound[1]) nsBound[1] = regData.getNSBound()[1]; // move nsBound[1] up from -10000.0
        		// lower N-S value
        		if (regData.getNSBound()[0] < nsBound[0]) nsBound[0] = regData.getNSBound()[0]; // move nsBound[0] down from 10000.0
        		
        		/* SimUtil.message("Id: " + regData.getId() + "; name: " + regData.getName()
        		+ "; full sides: " + regData.getFullSides() + " Km sides: " + regData.getKmSides()); */
    		}
    		catch (Exception ex) {SimUtil.message("Failure: " + ex.getMessage());}

    	}
    	
		SimUtil.message("\nE-W from " + ewBound[0] + " to " + ewBound[1]);
		SimUtil.message("N-S from " + nsBound[0] + " to " + nsBound[1]);
    	
    	// normalise all polygons to inside the range (5..95), (5..95)
    	for (RegionKML regData: regionDefs)
    		regData.setNormalPolygon(ewBound, nsBound);
	}
	
	/**
	 * 
	 * @return
	 */
	public Vector<Vector<double[]>> getNormalPolygons()
	{
		Vector<Vector<double[]>> normalPolygons = new Vector<Vector<double[]>>();
    	for (RegionKML regData: regionDefs)
    		normalPolygons.add(regData.getNormalPolygon());
		
		return normalPolygons;		
	}
	
	//----------------------------------------------------------------------------------------------
	//                            Read a csv file of populations
	//----------------------------------------------------------------------------------------------
	
	/**
	 * read a csv file of lines like
	 * 
	 * E06000002,Middlesbrough,Unitary Authority,"140,545",,,
	 * 
	 * @throws Exception
	 */
	private void readPopulations() throws Exception
	{
		FileInputStream fiz = new FileInputStream(populationFile);
		Vector<String> lines = SimUtil.getTextLines(fiz);
		
		for (int l = 1; l < lines.size(); l++)
		{
			String line = lines.get(l);
			StringTokenizer st = new StringTokenizer(line,"\",");
			String code = "";
			String name = "";
			try
			{
				code = st.nextToken();
				name = st.nextToken();
				String type = st.nextToken();
			}
			catch (Exception ex) {SimUtil.message("Population file failure in line " + line + "; " +  ex.getMessage());}

			int population = 0;
			while (st.hasMoreTokens())
			{
				try 
				{
					int pop = new Integer(st.nextToken()).intValue();
					population = 1000*population + pop;
				}
				catch (Exception e) {throw new Exception("Population number failure for region " + name);}
			}
			
			RegionKML region = regionsById.get(code);
			if (region != null)
			{
				region.setPopulation(population);
        		SimUtil.message("Long Id: " + region.getLongId() + "; name: " + region.getName()
        		+ "; population " + region.getPopulation() + " Density: " + region.getPopulationDensity()); 
			}
		}
	}
	
	//--------------------------------------------------------------------------------------------------
	//                                Export of region polygons
	//--------------------------------------------------------------------------------------------------
	
	/**
	 *  
	 * @param panZoomSetting
	 * @param zoomFactor
	 * @param parent
	 */
	public void exportRegionData(int[] panZoomSetting,Component parent) throws Exception
	 {
			exportFileChooser = new JFileChooser();
			exportFileChooser.setDialogTitle("Choose file to save region polygons");
				    int returnVal = exportFileChooser.showSaveDialog(parent);
				    if (returnVal == JFileChooser.APPROVE_OPTION) 
				    {
				    	File saveFile = exportFileChooser.getSelectedFile();
				    	writeRegionLines(saveFile,panZoomSetting);
				    }
 	 }
	
	private String exportHeader = "Name,Area,Population,Density,Polygon";
	
	/**
	 * 
	 * @param file
	 * @throws Exception
	 */
	private void writeRegionLines(File file, int[] panZoomSetting) throws Exception
	{
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		writer.write(exportHeader);
		writer.newLine();

		for (RegionKML region: regionDefs) if (inMap(region, panZoomSetting))
		{
			String name = SimUtil.replaceBy(region.getName(),",",";");
			String line = name + "," + (int)(region.getArea()/1000000.0) + "," 
					+ region.getPopulation() + "," + Factory.neat(region.getPopulationDensity()) + ",";

			String polygon = "";
			for (double[] point: region.getNormalPolygon())
			{
				double[] displaced = MapCanvas.panZoom(point, panZoomSetting);
				polygon = polygon + Factory.neat(displaced[0]) + "&" + Factory.neat(displaced[1]) + " ";
			}
			
			writer.write(line + polygon);
			writer.newLine();;
		}
		
		
		
		writer.close();
	}
	
	/**
	 * 
	 * @param region
	 * @param panZoomSetting
	 * @return
	 */
	private boolean inMap(RegionKML region, int[] panZoomSetting)
	{
		boolean inMap = false;
		
		for (double[] point: region.getNormalPolygon()) if (!inMap)
		{
			double[]  displaced = MapCanvas.panZoom(point, panZoomSetting);
			inMap = ((displaced[0] > 0.0) && (displaced[0] < 100.0) 
					&& (displaced[1] > 0.0) && (displaced[1] < 100.0));
		}
		
		return inMap;
	}



}
