package com.openmapping.covid;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.Reader;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

public class SimUtil {
	
	/**
	 * 
	 * @param inputFile
	 * @return the parsed rows of a csv file, including the header row
	 * @throws Exception
	 */
	public static Vector<String[]> getCSVRows(InputStream inputFile) throws Exception
	{
		Vector<String> lines = getLines(inputFile);
		if (lines.size() < 1) throw new Exception("No lines in csv file");
		StringTokenizer cols = new StringTokenizer(lines.get(0),",");
		
		Vector<String[]> csvRows = new Vector<String[]>();
		for (int i = 0; i < lines.size(); i++)
			csvRows.add(parseCSVLine(cols.countTokens(),lines.get(i)));
		
		return csvRows;
	}

	
	/**
	 * @param bufferedReader reader of a text file
	 * @return each line of the file as a String
	 * @throws Exception
	 */
	public static Vector<String> getLines(InputStream inputFile) throws Exception
	{
		Reader reader = new InputStreamReader(inputFile);
		BufferedReader bufferedReader = new BufferedReader(reader);
		Vector<String> lines = new Vector<String>();
		String line = "";
		while (line != null) try
		{
			line = bufferedReader.readLine();
			if (line != null) lines.add(line);
		}
		catch (IOException ex) {throw new Exception(ex.getMessage());}
		return lines;
	}

	
	/**
	 * 
	 * @param fileLocation
	 * @return the parsed rows of a csv file, including the header row
	 * @throws Exception
	 */
	public static Vector<String[]> getCSVRows(String fileLocation) throws Exception
	{
		Vector<String> lines = textLines(fileLocation);
		if (lines.size() < 1) throw new Exception("No lines in csv file");
		StringTokenizer cols = new StringTokenizer(lines.get(0),",");
		
		Vector<String[]> csvRows = new Vector<String[]>();
		for (int i = 0; i < lines.size(); i++)
			csvRows.add(parseCSVLine(cols.countTokens(),lines.get(i)));
		
		return csvRows;
	}
	
	/**
	 * read a line of a csv file, expected to have not more than columns separated fields,
	 * and return a string array of the fields, including "" for any initial ',' 
	 * or for final fields not supplied.
	 * Deals with commas and quotes in cells as handled by makeCSVLine
	 * @param columns max number of columns allowed
	 * @param line
	 * @return String array of field values
	 * @throws Exception
	 */
	public static String[] parseCSVLine(int columns, String line) throws Exception
	{
		String[] field = new String[columns];
		// break on either comma or quote, and retain them both as tokens
		StringTokenizer st = new StringTokenizer(line,",\"",true);
		int col = 0;
		field[0] = "";
		boolean evenQuotes = true;
		while (st.hasMoreTokens())
		{
			String val = st.nextToken();

			if (val.equals("\""))
			{
				evenQuotes = !evenQuotes;
				/* always consume a quote on its own without adding it to the cell contents */
				if (st.hasMoreTokens()) 
				{
					val = st.nextToken(); // may be '"' ','  or something else
					if (val.equals("\"")) evenQuotes = !evenQuotes;
				}
				else val = "";  // quote at the end of the line
			}

			// a comma after an even number of quotes marks a new cell
			if ((val.equals(",")) && evenQuotes) // no 'else' because the first condition may have fired and changed val
			{
				col++;					
				if (col > columns -1) throw new Exception("Too many columns, more than " + columns + "  in csv line '" + line + "'");
				field[col]="";
			}

			// at this point val can be '"'  ','  or something else; whatever it is, add it to the cell
			else field[col] = field[col] + val;
		}
		
		// trailing fields not even given ','
		if (col < columns - 1)
			for (int c = col + 1; c < columns; c++) field[c] = "";
		return field;
	}


	/**
	 * 
	 * @param location an absolute file location
	 * @return the lines of a text file at the location
	 * @throws Exception
	 */
	public static Vector<String> getTextLines(FileInputStream fiz) throws Exception
	{
		Vector<String> lines = new Vector<String>();
        InputStreamReader isr = new InputStreamReader(fiz);
        LineNumberReader lnr = new LineNumberReader(isr);
        try {
            String line = lnr.readLine();
            while (line != null)
            {
                lines.add(line);
                line = lnr.readLine();
            }
            lnr.close();        	
        }
		catch (Exception ex) {throw new Exception("Failure reading read text file: " + ex.getMessage());}

        return lines;
	}

	/**
	 * 
	 * @param location an absolute file location
	 * @return the lines of a text file at the location
	 * @throws Exception
	 */
	public static Vector<String> textLines(String location) throws Exception
	{
		Vector<String> lines = new Vector<String>();
		FileInputStream fiz = getTextFile(location);
        InputStreamReader isr = new InputStreamReader(fiz);

        LineNumberReader lnr = new LineNumberReader(isr);
        try {
            String line = lnr.readLine();
            while (line != null)
            {
                lines.add(line);
                line = lnr.readLine();
            }
            lnr.close();        	
        }
		catch (Exception ex) {throw new Exception("Failure reading read text file at '" + location + "': " + ex.getMessage());}

        return lines;
	}
	
	/**
	 * read a text file at an absolute file location
	 */
	public static FileInputStream getTextFile(String location) throws Exception
	{
		FileInputStream fi = null;
		try {
			fi = new FileInputStream(location);
		}
		catch (Exception ex) {throw new Exception("Cannot read text file at '" + location + "': " + ex.getMessage());}
		return fi;
	}
	
	
	public static void writeCSVFile(String location, Vector<String[]> csvRows) throws Exception
	{
		try
		{
	    	FileOutputStream fo = new FileOutputStream(location);
	    	for (int i = 0; i < csvRows.size(); i++)
	    	{
	    		String[] row = csvRows.get(i);
	    		String rowText = makeCSVLine(row);
	    		nl(rowText, fo);
	    	}
	    	fo.close();	
		}
		catch (Exception ex) {ex.printStackTrace();throw new Exception(ex.getMessage());}		
	}

	/**
	 * treats the contents of cells as follows:
	 * remove any new lines, which will screw up a csv file
	 * if there are no ',' or '"', no other change
	 * any '"' is doubled up
	 * if there are any ',', the whole cell contents are enclosed in two '"'
	 * This means ',' which occur after an odd number of '"' are there in the text;
	 * whereas ',' which occur after an even number of '"' are cell separators
	 * @param cells
	 * @return
	 */
	public static String makeCSVLine(String[] cells)
	{
		String line = "";
		for (int i = 0; i < cells.length; i++)
		{
			String cell = "";
			
			// double up any existing '"', and remove any new lines
			StringTokenizer st = new StringTokenizer(removeNewLines(cells[i]),"\"",true);
			while (st.hasMoreTokens())
			{
				String token = st.nextToken();
				cell = cell + token;
				if (token.equals("\"")) cell = cell + token;
			}
			
			// if the cell has any ',', enclose it all in two outer '"'
			int commas = new StringTokenizer(cell,",",true).countTokens() - 1;
			if (commas > 0) cell = "\"" + cell + "\"";
			
			// add the cell and a separator comma to the line
			line = line + cell;
			if (i < cells.length - 1) line = line + ",";
			
		}
		return line;
	}
	/**
	 * remove any new lines from a text String, replacing them by spaces
	 * @param text
	 * @return
	 */
	public static String removeNewLines(String text)
	{
		byte[] newLineChars = {13,10};
		byte[] rawBytes = text.getBytes();
		byte[] newBytes = new byte[rawBytes.length];
		
		for (int b = 0; b < rawBytes.length; b++)
		{
			byte raw = rawBytes[b];
			for (int i = 0; i < 2; i++) if (raw == newLineChars[i]) raw = ' ';
			newBytes[b] = raw;
		}		
		return new String(newBytes);		
	}
	
	public static byte[] newLine = {13,10};

    // write out a String followed by a new line
	public static  void nl(String s, OutputStream fo)
    {
        try{
        fo.write(s.getBytes());
        fo.write(newLine);
        }
        catch (IOException e)
            {message("Exception writing line '" + s + "': " + e.getMessage());}
    }

    // write out a String followed by no new line
    public static  void nnl(String s, OutputStream fo)
    {
        try{
        fo.write(s.getBytes());
        }
        catch (IOException e)
            {message("Exception writing line '" + s + "': " + e.getMessage());}
    }
    
    /**
     * change input as follows:
     * take out all occurrences of String takeOut, and replace them by putIn
     * @param input
     * @param takeOut single character to take out
     * @param putIn
     * @return
     */
    public static String replaceBy(String input, String takeOut, String putIn)
    {
    	StringTokenizer st = new StringTokenizer(input,takeOut);
    	String result = "";
    	while(st.hasMoreTokens())
    	{
    		String next = st.nextToken();
    		if (st.hasMoreTokens()) result = result + next + putIn;
    		else result = result + next;
    	}
    	if (input.endsWith(takeOut)) result = result + putIn;
    	return result;
    }

    

    /** return true if the string s is anywhere in the vector v of strings */
    public static boolean inVector(String s, Vector<String> v)
    {
        int i;
        boolean res = false;
        for (i = 0; i < v.size(); i++)
        {
            if (s.equals(v.elementAt(i))) res = true;
        }
        return res;
    }
    
    /**
     * 
     * @param s a string
     * @param v a Vector of strings
     * @return the number of occurrences of s in v
     */
    public static int countOccurrences(String s, Vector<String> v)
    {
    	int count = 0;
        for (int i = 0; i < v.size(); i++)
        {
            if (s.equals(v.elementAt(i))) count++;
        }
        return count;
    }
    

    /** check if a string is in an array of strings, checking all elements */
    public static boolean inArray(String arg, String[] array)
    {
        int i,len;
        boolean res = false;
        len = array.length;
        if (len > 0) for ( i = 0; i < len; i++)
            {if (arg.equals(array[i])) res = true;}
        return res;
    }
    
    /** return the position of a string in an array, or -1 if it is not in it */
    public static int positionInArray(String arg, String[] array)
    {
        int pos = -1; // result if not found
        for (int i = 0; i < array.length; i++)
            {if (arg.equals(array[i])) pos = i;}
        return pos;
    }

    
    /** return the position of a string in a vector, or -1 if it is not in it */
    public static int positionInVector(String arg, Vector<String> vect)
    {
        int pos = -1; // result if not found
        for (int i = 0; i < vect.size(); i++)
            {if (arg.equals(vect.get(i))) pos = i;}
        return pos;
    }
    
    //-------------------------------------------------------------------------------------------------------
    //                                 XML Handling
    //-------------------------------------------------------------------------------------------------------

	/**
	 * return the root Element of an XML file in a given inputStream
	 * @param location
	 * @return Element the root element, or null if there is any problem
	 */
	public static Element getRootElement(InputStream fi) throws Exception
	{
		return getDocument(fi).getDocumentElement();
	}
	
	/**
	 * return the Document of an XML file in a given inputStream
	 * @param location
	 * @return Element the root element, or null if there is any problem
	 */
	public static Document getDocument(InputStream fi) throws Exception
	{
		Document doc = null;
        try {
            DocumentBuilderFactory builderFac = DocumentBuilderFactory.newInstance();
            builderFac.setNamespaceAware(true);
            doc = builderFac.newDocumentBuilder().parse(fi);
        }
        catch (SAXException ex) {notify("Input Stream",ex);}
        catch (FileNotFoundException ex) {notify("Input Stream",ex);}
        catch (IOException ex) {notify("Input Stream",ex);}
        catch (ParserConfigurationException ex) {notify("Input Stream",ex);}
		return doc;
	}
	
	/**
	 * return the Document of an XML file in a given inputStream
	 * @param location
	 * @return Element the root element, or null if there is any problem
	 */
	public static Document getDocument(String location) throws Exception
	{
		try{
            FileInputStream fi = new FileInputStream(location);
            return getDocument(fi);
		}
        catch (IOException ex) {notify("Input Stream",ex);}
        return null;
	}


	private static void notify(String location, Exception ex) throws Exception
	{
		throw new Exception ("Exception getting XML root element from "
				+ location + "; " + ex.getMessage());
	}

	   
    /**
     * return the Vector of child Elements with given local name
     * @param el
     * @param name
     * @return
     */
    public static Vector<Element> namedChildElements(Element el, String lName)
    {
    	Vector<Element> nc = new Vector<Element>();
    	for (Iterator<Element> it = childElements(el).iterator(); it.hasNext();)
    	{
    		Element en = it.next();
    		if (getLocalName(en).equals(lName)) nc.addElement(en);
    	}
    	return nc;
    }
    
    /**
     * return the first child of the element with given name, or null if there are none
     * @param el
     * @param lName
     * @return
     */
    public static Element firstNamedChild(Element el, String lName)
    {
    	if (el == null) return null;
    	Element fc = null;
    	Vector<Element> children = namedChildElements(el,lName);
    	if (children.size() > 0) fc = children.elementAt(0);
    	return fc;
    }
    

    /**
     * Vector of child elements of an element
     */
    public static Vector<Element> childElements(Element el) {
        Vector<Element> res = new Vector<Element>();
        NodeList nodes = el.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++) {
            Node nd = nodes.item(i);
            if (nd instanceof Element) {
                Element eg = (Element) nd;
                res.addElement(eg);
            }
        }
        return res;
    }
    

    /**
	 * get the name of an XML element, with the namespace prefix stripped off
	 * @param el
	 * @return
	 */
	public static String getLocalName(Node el)
	{
		String locName = "";
		StringTokenizer st = new StringTokenizer(el.getNodeName(),":");
		while (st.hasMoreTokens()) locName = st.nextToken();
		return locName;
	}
	
	 
    /**
     * get the  text string in an element (eg interspersed between child elements), 
     * or "" if there is none or if the Element is null.
     * Tries to ignore white space text; but does not succeed.
     */
    public static String getText(Element el) {
        String res = "";
        if (el != null) try 
        {
        	el.normalize(); // does not help recognise white space
        	NodeList nodes = el.getChildNodes();
            for (int i = 0; i < nodes.getLength(); i++) 
            	if (nodes.item(i) instanceof Text)
            	{
            		Text text = (Text)nodes.item(i);
            		// this filter seems to make no difference
            		if (!text.isElementContentWhitespace())  
            		{
            			String tData = text.getData();
            			// this seems to be an effective way to catch pure white space
            			StringTokenizer nonWhiteSpace = new StringTokenizer(tData,"\n \t");
            			if (nonWhiteSpace.countTokens() > 0 )res = res + tData;
            		}
            	}
        }
        catch (Exception e) {System.out.println("Text failure: " + e.getMessage());}
        return res;
    }
    

   
    //-------------------------------------------------------------------------------------------------------
    //                                 Trivia
    //-------------------------------------------------------------------------------------------------------

    public static void message(String s) {System.out.println(s);}
    
    /**
     * 
     * @param s
     * @return
     * @throws Exception
     */
    public static int makeInteger(String s) throws Exception
    {
    	int x = 0;
    	try {x = new Integer(s).intValue();}
    	catch (Exception ex) {throw new Exception("Invalid integer value: '" + s + "'");}
    	return x;
    }
    
    /**
     * 
     * @param s
     * @return
     * @throws Exception
     */
    public static double makeReal(String s) throws Exception
    {
    	double x = 0;
    	try {x = new Double(s).doubleValue();}
    	catch (Exception ex) {throw new Exception("Invalid real number value: '" + s + "'");}
    	return x;
    }

}
